import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import type { OrgConfig, SponsorshipLevel } from "./org-config";

// ============================================================
// PATTERN: Query Client Setup
// ============================================================
// Default query function that auto-fetches from the API using queryKey as URL
//
// const queryClient = new QueryClient({
//   defaultOptions: {
//     queries: {
//       queryFn: async ({ queryKey }) => {
//         const res = await fetch(queryKey.join("/"), { credentials: "include" });
//         if (!res.ok) throw new Error(`${res.status}: ${await res.text()}`);
//         return res.json();
//       },
//       refetchInterval: false,
//       refetchOnWindowFocus: false,
//       staleTime: Infinity,
//       retry: false,
//     },
//   },
// });
//
// Usage: useQuery({ queryKey: ["/api/events"] }) -- no queryFn needed

// ============================================================
// PATTERN: apiRequest helper
// ============================================================
export async function apiRequest(method: string, url: string, data?: unknown): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });
  if (!res.ok) throw new Error(`${res.status}: ${(await res.text()) || res.statusText}`);
  return res;
}

// ============================================================
// PATTERN: Site Content Hook (CMS-lite via database key-value)
// ============================================================
export function useSiteContent(config: OrgConfig) {
  const DEFAULTS: Record<string, string> = {
    contact_address: config.address,
    contact_mailing_address: config.mailingAddress,
    contact_phone: config.phone,
    contact_alt_phone: config.altPhone || "",
    contact_email: config.email,
    contact_events_email: config.eventsEmail || "",
  };

  const { data: content, isLoading } = useQuery<Record<string, string>>({
    queryKey: ["/api/site-content"],
  });

  const get = (key: string) => content?.[key] ?? DEFAULTS[key] ?? "";
  return { content, isLoading, get };
}

// ============================================================
// PATTERN: Registration Status Hook
// ============================================================
export interface RegistrationStatus {
  vendorOpen: boolean;
  sponsorOpen: boolean;
  ticketSalesOpen: boolean;
  eventDate: string | null;
  isTicketed?: boolean;
  opensAt?: string;
  closesAt?: string;
  reason: "open" | "force-open" | "too-early" | "auto-closed" | "manually-closed" | "no-date-set";
}

export function useRegistrationStatus(eventType: string) {
  return useQuery<RegistrationStatus>({
    queryKey: ["/api/registration-status", eventType],
  });
}

// ============================================================
// PATTERN: Hero Section
// Hero with full-bleed background image, gradient overlay,
// org name, tagline, and CTA buttons
// ============================================================
export function HeroSection({ config }: { config: OrgConfig }) {
  return (
    <section className="relative overflow-hidden" data-testid="section-hero">
      {/* Background image with gradient overlay */}
      <div className="absolute inset-0">
        {/* <img src={heroImage} alt="..." className="w-full h-full object-cover" /> */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/55 to-black/30" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 py-24 md:py-36 lg:py-44">
        <div className="max-w-2xl">
          {/* Badge */}
          <span className="inline-flex items-center mb-4 px-3 py-1 rounded-full text-xs bg-primary/20 text-white border border-primary/30">
            Community Driven
          </span>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-2 font-serif leading-tight" data-testid="text-hero-title">
            Welcome to Downtown {config.location.city}
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-4 font-medium italic">
            {config.tagline}
          </p>

          <p className="text-base md:text-lg text-white/70 mb-8 leading-relaxed max-w-lg">
            The {config.shortName} brings our community together through vibrant events,
            local businesses, and community spirit.
          </p>

          <div className="flex flex-wrap gap-3">
            <Link href="/events">
              <button className="px-6 py-3 bg-primary text-white rounded-md font-medium" data-testid="button-explore-events">
                View Events
              </button>
            </Link>
            <Link href="/about">
              <button className="px-6 py-3 bg-white/10 text-white border border-white/20 rounded-md backdrop-blur-sm" data-testid="button-about">
                Learn About {config.shortName}
              </button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============================================================
// PATTERN: Stats Section
// 4-column grid of key numbers
// ============================================================
export function StatsSection({ config }: { config: OrgConfig }) {
  const stats = [
    { value: config.stats.annualEvents, label: "Annual Events" },
    { value: config.stats.annualAttendees, label: "Annual Attendees" },
    { value: config.stats.localBusinesses, label: "Local Businesses" },
    { value: config.stats.volunteerRun, label: "Volunteer Run" },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 py-16" data-testid="section-stats">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <div key={stat.label} className="p-6 text-center border rounded-lg bg-card">
            <p className="text-2xl md:text-3xl font-bold mb-1" data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, "-")}`}>
              {stat.value}
            </p>
            <p className="text-xs text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

// ============================================================
// PATTERN: Event Card Grid
// Card grid with image, badge, title, date/time/location
// Each card links to /events/{slug}
// ============================================================
interface EventData {
  id: number;
  title: string;
  slug: string | null;
  description: string;
  date: string;
  time: string;
  location: string;
  category: string;
  imageUrl: string | null;
  featured: boolean | null;
  externalLink: string | null;
}

export function EventCardGrid({ events }: { events: EventData[] }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {events.map((event) => {
        const href = event.slug ? `/events/${event.slug}` : "/events";
        return (
          <Link key={event.id} href={href}>
            <div className="border rounded-lg overflow-hidden bg-card cursor-pointer hover:shadow-md transition-shadow" data-testid={`card-event-${event.id}`}>
              {event.imageUrl && (
                <img src={event.imageUrl} alt={event.title} className="w-full h-48 object-cover" />
              )}
              <div className="p-5">
                <span className="inline-block px-2 py-1 text-xs rounded bg-secondary mb-3">{event.category}</span>
                <h3 className="font-semibold text-lg mb-2" data-testid={`text-event-title-${event.id}`}>{event.title}</h3>
                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{event.description}</p>
                <div className="flex flex-col gap-2 text-sm text-muted-foreground">
                  <span>📅 {event.date}</span>
                  <span>🕐 {event.time}</span>
                  <span>📍 {event.location}</span>
                </div>
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}

// ============================================================
// PATTERN: Event Detail Page Layout
// Individual event page with hero, about, highlights, schedule,
// ticket purchase, sponsors, and contact CTA
// ============================================================
export function EventDetailLayout({ event, config }: { event: EventData & { isTicketed?: boolean; ticketPrice?: string }; config: OrgConfig }) {
  return (
    <div className="min-h-screen">
      {/* 1. Hero */}
      <section className="relative overflow-hidden" data-testid="section-event-hero">
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/70" />
        <div className="relative max-w-7xl mx-auto px-4 py-24 md:py-36 text-center">
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs bg-primary/20 text-white border border-primary/30 mb-4">
            📅 {event.category}
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-3 font-serif" data-testid="text-event-detail-title">
            {event.title}
          </h1>
          <p className="text-lg text-white/80 mb-2">{event.date}</p>
          <p className="text-base text-white/60 mb-8">{event.time} &middot; {event.location}</p>
          <div className="flex flex-wrap justify-center gap-3">
            {event.isTicketed && (
              <a href="#ticket-purchase">
                <button className="px-6 py-3 bg-primary text-white rounded-md" data-testid="button-event-buy-tickets">
                  Buy Tickets 🎟️
                </button>
              </a>
            )}
          </div>
        </div>
      </section>

      {/* 2. About */}
      <section className="max-w-3xl mx-auto px-4 py-16" data-testid="section-event-about">
        <h2 className="text-2xl md:text-3xl font-bold font-serif text-center mb-4">About This Event</h2>
        <p className="text-muted-foreground text-center text-lg leading-relaxed">{event.description}</p>
        <div className="flex flex-wrap justify-center gap-6 mt-8 text-muted-foreground">
          <span>📅 {event.date}</span>
          <span>🕐 {event.time}</span>
          <span>📍 {event.location}</span>
        </div>
      </section>

      {/* 3. Ticket Purchase (if ticketed) */}
      {event.isTicketed && <TicketPurchaseSection eventSlug={event.slug || ""} eventTitle={event.title} />}

      {/* 4. Sponsors Section */}
      {/* 5. Contact CTA */}
      <section className="bg-card border-t">
        <div className="max-w-3xl mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold font-serif mb-2">Questions?</h2>
          <p className="text-muted-foreground mb-4">Contact us at {config.email}</p>
          <Link href="/contact">
            <button className="px-6 py-3 bg-primary text-white rounded-md">Get in Touch</button>
          </Link>
        </div>
      </section>
    </div>
  );
}

// ============================================================
// PATTERN: Ticket Purchase Section
// Quantity picker, price display, form fields, checkout redirect
// ============================================================
function TicketPurchaseSection({ eventSlug, eventTitle }: { eventSlug: string; eventTitle: string }) {
  const [buyerName, setBuyerName] = useState("");
  const [buyerEmail, setBuyerEmail] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: availability } = useQuery<{
    ticketPrice: string;
    capacity: number | null;
    sold: number;
    remaining: number | null;
    available: boolean;
  }>({
    queryKey: ["/api/events", eventSlug, "ticket-availability"],
    queryFn: async () => {
      const res = await fetch(`/api/events/${eventSlug}/ticket-availability`);
      if (!res.ok) throw new Error("Failed to load ticket info");
      return res.json();
    },
    enabled: !!eventSlug,
  });

  const price = availability ? parseFloat(availability.ticketPrice) : 0;
  const total = price * quantity;
  const maxQty = availability?.remaining != null ? Math.min(10, availability.remaining) : 10;
  const soldOut = availability?.available === false;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerName.trim() || !buyerEmail.trim()) return;
    setIsSubmitting(true);
    try {
      const res = await apiRequest("POST", `/api/events/${eventSlug}/ticket-checkout`, {
        buyerName: buyerName.trim(),
        buyerEmail: buyerEmail.trim(),
        quantity,
      });
      const data = await res.json();
      if (data.checkoutUrl) window.location.href = data.checkoutUrl;
    } catch (err) {
      console.error("Checkout error:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (soldOut) {
    return (
      <section id="ticket-purchase" className="bg-card border-y">
        <div className="max-w-lg mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl font-bold font-serif mb-2">Sold Out</h2>
          <p className="text-muted-foreground">All tickets for {eventTitle} have been sold.</p>
        </div>
      </section>
    );
  }

  return (
    <section id="ticket-purchase" className="bg-card border-y" data-testid="section-ticket-purchase">
      <div className="max-w-lg mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold font-serif text-center mb-2">Get Your Tickets</h2>
        <p className="text-muted-foreground text-center mb-8">{eventTitle}</p>

        <form onSubmit={handleSubmit} className="space-y-4" data-testid="form-ticket-purchase">
          <div>
            <label className="block text-sm font-medium mb-1">Full Name</label>
            <input
              type="text"
              value={buyerName}
              onChange={(e) => setBuyerName(e.target.value)}
              required
              className="w-full px-3 py-2 border rounded-md bg-background"
              data-testid="input-ticket-buyer-name"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              value={buyerEmail}
              onChange={(e) => setBuyerEmail(e.target.value)}
              required
              className="w-full px-3 py-2 border rounded-md bg-background"
              data-testid="input-ticket-buyer-email"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Quantity</label>
            <div className="flex items-center gap-3">
              <button type="button" onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-10 h-10 border rounded-md" data-testid="button-ticket-minus">-</button>
              <span className="text-xl font-bold w-8 text-center" data-testid="text-ticket-quantity">{quantity}</span>
              <button type="button" onClick={() => setQuantity(Math.min(maxQty, quantity + 1))} className="w-10 h-10 border rounded-md" data-testid="button-ticket-plus">+</button>
            </div>
          </div>

          <div className="flex justify-between items-center p-4 bg-muted rounded-md">
            <span className="text-sm text-muted-foreground">{quantity} x ${price.toFixed(2)}</span>
            <span className="text-xl font-bold" data-testid="text-ticket-total">${total.toFixed(2)}</span>
          </div>

          {availability?.remaining != null && (
            <p className="text-sm text-muted-foreground text-center" data-testid="text-tickets-remaining">
              {availability.remaining} tickets remaining
            </p>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 bg-primary text-white rounded-md font-medium disabled:opacity-50"
            data-testid="button-ticket-checkout"
          >
            {isSubmitting ? "Processing..." : `Purchase - $${total.toFixed(2)}`}
          </button>
        </form>
      </div>
    </section>
  );
}

// ============================================================
// PATTERN: Sponsorship Tiers Display
// Card grid with tier name, price, perks list, and checkout button
// ============================================================
export function SponsorshipTiers({ levels, onCheckout }: { levels: SponsorshipLevel[]; onCheckout: (level: SponsorshipLevel) => void }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {levels.map((level) => (
        <div
          key={level.name}
          className={`p-6 border rounded-lg relative ${level.tag === "Best Value" ? "border-primary" : ""}`}
          data-testid={`card-sponsor-level-${level.name.toLowerCase().replace(/\s/g, "-")}`}
        >
          {level.tag && (
            <span className="absolute -top-2.5 left-4 px-2 py-0.5 text-xs bg-primary text-white rounded-full">
              {level.tag}
            </span>
          )}
          <h3 className="font-bold text-lg mb-1">{level.name}</h3>
          <p className="text-2xl font-bold mb-4">
            ${level.price}
            <span className="text-sm text-muted-foreground font-normal"> per event</span>
          </p>
          <ul className="space-y-2 mb-4">
            {level.perks.map((perk, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <span className="text-primary mt-0.5">✓</span>
                <span className="text-muted-foreground">{perk}</span>
              </li>
            ))}
          </ul>
          <button
            className="w-full py-2 border rounded-md text-sm font-medium hover:bg-muted transition-colors"
            onClick={() => onCheckout(level)}
            data-testid={`button-sponsor-pay-${level.name.toLowerCase().replace(/\s/g, "-")}`}
          >
            Pay via Checkout
          </button>
        </div>
      ))}
    </div>
  );
}

// ============================================================
// PATTERN: Newsletter Signup
// Email + optional first name, honeypot + timing bot protection
// ============================================================
export function NewsletterSignup({ config }: { config: OrgConfig }) {
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [honeypot, setHoneypot] = useState("");
  const [formLoadedAt] = useState(Date.now());

  const subscribe = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/newsletter/subscribe", {
        email,
        firstName,
        website: honeypot,
        formTiming: Date.now() - formLoadedAt,
      });
      return res.json();
    },
    onSuccess: () => {
      setEmail("");
      setFirstName("");
    },
  });

  return (
    <section className="bg-card border-y" data-testid="section-newsletter">
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl md:text-3xl font-bold font-serif mb-2">Stay Connected</h2>
        <p className="text-sm text-muted-foreground mb-6 max-w-md mx-auto">
          Get the latest news about {config.location.city} events and community updates.
        </p>
        <form
          onSubmit={(e) => { e.preventDefault(); if (email.trim()) subscribe.mutate(); }}
          className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-lg mx-auto"
          data-testid="form-newsletter-signup"
        >
          {/* Honeypot - hidden from real users */}
          <div className="absolute opacity-0 h-0 w-0 overflow-hidden" aria-hidden="true" tabIndex={-1}>
            <input type="text" name="website" value={honeypot} onChange={(e) => setHoneypot(e.target.value)} tabIndex={-1} autoComplete="off" />
          </div>

          <input
            type="text"
            placeholder="First name (optional)"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="px-3 py-2 border rounded-md sm:w-40 bg-background"
            data-testid="input-newsletter-firstname"
          />
          <input
            type="email"
            placeholder="Your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="px-3 py-2 border rounded-md sm:flex-1 bg-background"
            data-testid="input-newsletter-email"
          />
          <button
            type="submit"
            disabled={subscribe.isPending}
            className="px-4 py-2 bg-primary text-white rounded-md disabled:opacity-50"
            data-testid="button-newsletter-subscribe"
          >
            {subscribe.isPending ? "..." : "Subscribe"}
          </button>
        </form>
        <p className="text-xs text-muted-foreground mt-3">Unsubscribe anytime.</p>
      </div>
    </section>
  );
}

// ============================================================
// PATTERN: Contact Form
// With honeypot + timing bot protection, Zod validation
// ============================================================
export function ContactForm({ config }: { config: OrgConfig }) {
  const [submitted, setSubmitted] = useState(false);
  const [honeypot, setHoneypot] = useState("");
  const [formLoadedAt] = useState(Date.now());
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const mutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/contact", {
        name, email, subject, message,
        website: honeypot,
        formTiming: Date.now() - formLoadedAt,
      });
      return res.json();
    },
    onSuccess: () => setSubmitted(true),
  });

  if (submitted) {
    return (
      <div className="p-8 text-center border rounded-lg" data-testid="card-contact-success">
        <p className="text-xl font-bold mb-2">Message Sent!</p>
        <p className="text-muted-foreground mb-4">We'll get back to you soon.</p>
        <button className="px-4 py-2 border rounded-md" onClick={() => { setSubmitted(false); setName(""); setEmail(""); setSubject(""); setMessage(""); }} data-testid="button-send-another">
          Send Another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={(e) => { e.preventDefault(); mutation.mutate(); }} className="space-y-6" data-testid="form-contact">
      <div className="absolute opacity-0 h-0 w-0 overflow-hidden" aria-hidden="true" tabIndex={-1}>
        <input type="text" name="website" value={honeypot} onChange={(e) => setHoneypot(e.target.value)} tabIndex={-1} autoComplete="off" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Name</label>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required className="w-full px-3 py-2 border rounded-md bg-background" data-testid="input-contact-name" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full px-3 py-2 border rounded-md bg-background" data-testid="input-contact-email" />
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Subject</label>
        <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} required className="w-full px-3 py-2 border rounded-md bg-background" data-testid="input-contact-subject" />
      </div>
      <div>
        <label className="block text-sm font-medium mb-1">Message</label>
        <textarea value={message} onChange={(e) => setMessage(e.target.value)} required rows={6} className="w-full px-3 py-2 border rounded-md bg-background resize-none" data-testid="textarea-contact-message" />
      </div>
      <button type="submit" disabled={mutation.isPending} className="px-6 py-3 bg-primary text-white rounded-md font-medium disabled:opacity-50" data-testid="button-send-message">
        {mutation.isPending ? "Sending..." : "Send Message"}
      </button>
    </form>
  );
}

// ============================================================
// PATTERN: Photo Gallery with Lightbox
// Album grid + click-to-open viewer + arrow navigation
// ============================================================
interface PhotoAlbum {
  id: number;
  title: string;
  description: string | null;
  coverPhotoUrl: string | null;
}

interface AlbumPhoto {
  id: number;
  url: string;
  caption: string | null;
}

export function PhotoGallery({ albums, onSelectAlbum }: { albums: PhotoAlbum[]; onSelectAlbum: (album: PhotoAlbum) => void }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {albums.map((album) => (
        <div
          key={album.id}
          className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => onSelectAlbum(album)}
          data-testid={`card-album-${album.id}`}
        >
          {album.coverPhotoUrl ? (
            <div className="relative">
              <img src={album.coverPhotoUrl} alt={album.title} className="w-full h-52 object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="font-semibold text-lg text-white">{album.title}</h3>
              </div>
            </div>
          ) : (
            <div className="p-6">
              <h3 className="font-semibold text-lg">{album.title}</h3>
              {album.description && <p className="text-sm text-muted-foreground mt-1">{album.description}</p>}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ============================================================
// PATTERN: Blog / News List Page (conditional — only if blog enabled)
// Grid of published posts with cover image, title, excerpt, date
// Content Studio connection: Press Releases, Event Recaps,
// Blog Posts, Spotlights all publish here
// ============================================================
interface BlogPostData {
  id: number;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  coverImageUrl: string | null;
  category: string | null;
  author: string | null;
  publishedAt: string | null;
}

export function BlogListPage() {
  const { data: posts, isLoading } = useQuery<BlogPostData[]>({
    queryKey: ["/api/blog"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-16" data-testid="page-blog">
      <h1 className="text-3xl md:text-4xl font-bold font-serif mb-2">News & Updates</h1>
      <p className="text-muted-foreground mb-8">Latest announcements, event recaps, and community stories.</p>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="border rounded-lg overflow-hidden">
              <div className="h-48 bg-muted animate-pulse" />
              <div className="p-5 space-y-2">
                <div className="h-5 w-2/3 bg-muted animate-pulse rounded" />
                <div className="h-4 w-full bg-muted animate-pulse rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : posts && posts.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {posts.map((post) => (
            <Link key={post.id} href={`/blog/${post.slug}`}>
              <div className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow bg-card" data-testid={`card-blog-${post.id}`}>
                {post.coverImageUrl && (
                  <img src={post.coverImageUrl} alt={post.title} className="w-full h-48 object-cover" />
                )}
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-3">
                    {post.category && (
                      <span className="inline-block px-2 py-1 text-xs rounded bg-secondary">{post.category}</span>
                    )}
                    {post.publishedAt && (
                      <span className="text-xs text-muted-foreground">
                        {new Date(post.publishedAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
                      </span>
                    )}
                  </div>
                  <h2 className="font-semibold text-lg mb-2" data-testid={`text-blog-title-${post.id}`}>{post.title}</h2>
                  {post.excerpt && (
                    <p className="text-sm text-muted-foreground line-clamp-3">{post.excerpt}</p>
                  )}
                  {post.author && (
                    <p className="text-xs text-muted-foreground mt-3">By {post.author}</p>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <div className="p-8 text-center border rounded-lg">
          <p className="text-muted-foreground">No posts yet. Check back soon!</p>
        </div>
      )}
    </div>
  );
}

// ============================================================
// PATTERN: Blog Post Detail Page (conditional — only if blog enabled)
// Full post with cover image, title, author, date, rich content
// ============================================================
export function BlogPostDetail({ slug }: { slug: string }) {
  const { data: post, isLoading } = useQuery<BlogPostData>({
    queryKey: ["/api/blog", slug],
    queryFn: async () => {
      const res = await fetch(`/api/blog/${slug}`);
      if (!res.ok) throw new Error("Post not found");
      return res.json();
    },
    enabled: !!slug,
  });

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 space-y-4">
        <div className="h-8 w-2/3 bg-muted animate-pulse rounded" />
        <div className="h-4 w-1/3 bg-muted animate-pulse rounded" />
        <div className="h-64 bg-muted animate-pulse rounded" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-2">Post Not Found</h1>
        <Link href="/blog">
          <button className="px-4 py-2 border rounded-md mt-4">Back to Blog</button>
        </Link>
      </div>
    );
  }

  return (
    <article className="max-w-3xl mx-auto px-4 py-16" data-testid="page-blog-post">
      <Link href="/blog">
        <button className="text-sm text-muted-foreground mb-6 hover:text-foreground transition-colors" data-testid="link-back-to-blog">
          &larr; Back to News
        </button>
      </Link>

      <div className="flex items-center gap-3 mb-4">
        {post.category && (
          <span className="inline-block px-2 py-1 text-xs rounded bg-secondary">{post.category}</span>
        )}
        {post.publishedAt && (
          <span className="text-sm text-muted-foreground">
            {new Date(post.publishedAt).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
          </span>
        )}
      </div>

      <h1 className="text-3xl md:text-4xl font-bold font-serif mb-4" data-testid="text-blog-post-title">{post.title}</h1>

      {post.author && (
        <p className="text-muted-foreground mb-6">By {post.author}</p>
      )}

      {post.coverImageUrl && (
        <img src={post.coverImageUrl} alt={post.title} className="w-full rounded-lg mb-8 max-h-96 object-cover" />
      )}

      <div
        className="prose prose-lg max-w-none dark:prose-invert"
        dangerouslySetInnerHTML={{ __html: post.content }}
        data-testid="blog-post-content"
      />
    </article>
  );
}

// ============================================================
// PATTERN: Recent Posts Section (for homepage — conditional)
// Shows 3 most recent blog posts as cards
// ============================================================
export function RecentPostsSection() {
  const { data: posts } = useQuery<BlogPostData[]>({
    queryKey: ["/api/blog"],
  });

  const recent = posts?.slice(0, 3) || [];
  if (recent.length === 0) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 py-16" data-testid="section-recent-posts">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold font-serif">Latest News</h2>
          <p className="text-sm text-muted-foreground mt-1">Updates from our organization</p>
        </div>
        <Link href="/blog">
          <button className="px-4 py-2 border rounded-md text-sm" data-testid="button-view-all-posts">
            View All
          </button>
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {recent.map((post) => (
          <Link key={post.id} href={`/blog/${post.slug}`}>
            <div className="border rounded-lg overflow-hidden cursor-pointer hover:shadow-md transition-shadow bg-card" data-testid={`card-recent-post-${post.id}`}>
              {post.coverImageUrl && (
                <img src={post.coverImageUrl} alt={post.title} className="w-full h-40 object-cover" />
              )}
              <div className="p-4">
                {post.publishedAt && (
                  <span className="text-xs text-muted-foreground">
                    {new Date(post.publishedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </span>
                )}
                <h3 className="font-semibold mt-1 mb-1">{post.title}</h3>
                {post.excerpt && (
                  <p className="text-sm text-muted-foreground line-clamp-2">{post.excerpt}</p>
                )}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}

// ============================================================
// PATTERN: Navigation Bar
// Sticky nav with logo, page links, event dropdown, social icons, mobile sheet
// ============================================================
export function NavigationPattern({ config }: { config: OrgConfig }) {
  return (
    <header className="sticky top-0 z-50 bg-background/90 backdrop-blur-md border-b">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 px-4 py-3">
        <Link href="/" data-testid="link-home-logo">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-md bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm font-serif">
                {config.branding.logoInitials}
              </span>
            </div>
            <div className="hidden sm:block">
              <p className="font-bold text-sm leading-tight">Discover</p>
              <p className="text-xs text-muted-foreground leading-tight">{config.location.city}, {config.location.stateAbbrev}</p>
            </div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-1" data-testid="nav-desktop">
          {/* Home, Events (with dropdown for event programs), Directory, About, Contact */}
        </nav>

        {/* Social icons + mobile menu trigger */}
      </div>
    </header>
  );
}

// ============================================================
// PATTERN: Footer
// 3-column: branding + tagline, quick links, contact info
// ============================================================
export function FooterPattern({ config }: { config: OrgConfig }) {
  return (
    <footer className="bg-card border-t mt-auto">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-xs font-serif">{config.branding.logoInitials}</span>
              </div>
              <div>
                <p className="font-bold text-sm">Downtown {config.location.city}</p>
                <p className="text-xs text-muted-foreground">{config.location.state}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">{config.tagline}</p>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-4">Quick Links</h4>
            <nav className="flex flex-col gap-2">
              <Link href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Home</Link>
              <Link href="/events" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Events</Link>
              <Link href="/businesses" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Directory</Link>
              <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">About</Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Contact</Link>
            </nav>
          </div>

          <div>
            <h4 className="font-semibold text-sm mb-4">Contact</h4>
            <div className="flex flex-col gap-3 text-sm text-muted-foreground">
              <span>📍 {config.address}</span>
              <span>📞 {config.phone}</span>
              <a href={`mailto:${config.email}`} className="hover:text-foreground transition-colors">✉️ {config.email}</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

// ============================================================
// PATTERN: App Router Structure
// ============================================================
// <Switch>
//   <Route path="/" component={Home} />
//   <Route path="/events" component={Events} />
//   <Route path="/events/:slug" component={EventDetail} />
//   <Route path="/businesses" component={Businesses} />         {/* conditional: business orgs only */}
//   <Route path="/blog" component={BlogList} />                 {/* conditional: blog enabled */}
//   <Route path="/blog/:slug" component={BlogPostDetail} />     {/* conditional: blog enabled */}
//   <Route path="/about" component={About} />
//   <Route path="/contact" component={Contact} />
//   <Route path="/gallery" component={Gallery} />
//   <Route path="/payment-success" component={PaymentSuccess} /> {/* conditional: ticketed events */}
//   <Route path="/admin/login" component={AdminLogin} />
//   <Route path="/admin" component={Admin} />
//   <Route component={NotFound} />
// </Switch>
//
// Layout: Navigation at top, main content, Footer at bottom
// Admin pages: no nav/footer
//
// Homepage section order (include/skip per Feature Decision Matrix):
//   HeroSection (always)
//   StatsSection (always)
//   UpcomingEventsSection (always)
//   RecentPostsSection (if blog enabled)
//   BusinessHighlights (if business directory enabled)
//   NewsletterSignup (if newsletter enabled)
//   PartnersSection (if partners provided)
