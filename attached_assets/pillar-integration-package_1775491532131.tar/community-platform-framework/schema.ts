import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug"),
  description: text("description").notNull(),
  date: text("date").notNull(),
  time: text("time").notNull(),
  location: text("location").notNull(),
  category: text("category").notNull(),
  featured: boolean("featured").default(false),
  showInNav: boolean("show_in_nav").default(false),
  hasRegistration: boolean("has_registration").default(false),
  imageUrl: text("image_url"),
  posterImageUrl: text("poster_image_url"),
  externalLink: text("external_link"),
  isActive: boolean("is_active").default(true),
  isTicketed: boolean("is_ticketed").default(false),
  ticketPrice: text("ticket_price"),
  ticketCapacity: integer("ticket_capacity"),
});

export const sponsors = pgTable("sponsors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  level: text("level").notNull(),
  logoUrl: text("logo_url"),
  websiteUrl: text("website_url"),
  eventType: text("event_type").default("general"),
  sponsorImageUrl: text("sponsor_image_url"),
});

export const businesses = pgTable("businesses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  address: text("address").notNull(),
  phone: text("phone"),
  website: text("website"),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
});

export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const photoAlbums = pgTable("photo_albums", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  coverPhotoUrl: text("cover_photo_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const albumPhotos = pgTable("album_photos", {
  id: serial("id").primaryKey(),
  albumId: integer("album_id").notNull(),
  url: text("url").notNull(),
  caption: text("caption"),
  sortOrder: integer("sort_order").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vendorRegistrations = pgTable("vendor_registrations", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(),
  businessName: text("business_name").notNull(),
  contactName: text("contact_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  vendorCategory: text("vendor_category").notNull(),
  description: text("description"),
  specialRequests: text("special_requests"),
  status: text("status").default("pending").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sponsorshipInquiries = pgTable("sponsorship_inquiries", {
  id: serial("id").primaryKey(),
  businessName: text("business_name").notNull(),
  contactName: text("contact_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  level: text("level").notNull(),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const siteContent = pgTable("site_content", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const registrationSettings = pgTable("registration_settings", {
  eventType: text("event_type").primaryKey(),
  eventDate: text("event_date"),
  vendorRegistrationClosed: boolean("vendor_registration_closed").default(false),
  sponsorRegistrationClosed: boolean("sponsor_registration_closed").default(false),
  vendorRegistrationForceOpen: boolean("vendor_registration_force_open").default(false),
  sponsorRegistrationForceOpen: boolean("sponsor_registration_force_open").default(false),
  ticketSalesClosed: boolean("ticket_sales_closed").default(false),
  ticketSalesForceOpen: boolean("ticket_sales_force_open").default(false),
});

export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firstName: text("first_name"),
  status: text("status").notNull().default("active"),
  unsubscribeToken: text("unsubscribe_token").notNull(),
  subscribedAt: timestamp("subscribed_at").defaultNow(),
  unsubscribedAt: timestamp("unsubscribed_at"),
});

export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  subject: text("subject").notNull(),
  introHtml: text("intro_html").notNull(),
  imageUrls: text("image_urls").default("[]"),
  scheduledAt: timestamp("scheduled_at"),
  status: text("status").notNull().default("draft"),
  recipientCount: integer("recipient_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  sentAt: timestamp("sent_at"),
});

export const newsletterBatches = pgTable("newsletter_batches", {
  id: serial("id").primaryKey(),
  newsletterId: integer("newsletter_id").notNull(),
  batchNumber: integer("batch_number").notNull(),
  scheduledSendAt: timestamp("scheduled_send_at").notNull(),
  status: text("status").notNull().default("pending"),
  recipientCount: integer("recipient_count").default(0),
  recipientEmails: text("recipient_emails").default("[]"),
  sentAt: timestamp("sent_at"),
});

export const eventPrograms = pgTable("event_programs", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  eventType: text("event_type").notNull().unique(),
  description: text("description"),
  date: text("date"),
  time: text("time"),
  location: text("location"),
  heroBackgroundType: text("hero_background_type").default("gradient"),
  heroBackgroundColor: text("hero_background_color"),
  heroBackgroundImageUrl: text("hero_background_image_url"),
  showLogo: boolean("show_logo").default(false),
  highlights: text("highlights").default("[]"),
  vendorFormEmbedUrl: text("vendor_form_embed_url"),
  sponsorPaymentLinks: text("sponsor_payment_links").default("{}"),
  hasVendorRegistration: boolean("has_vendor_registration").default(true),
  hasSponsorSection: boolean("has_sponsor_section").default(true),
  sortOrder: integer("sort_order").default(0),
  isActive: boolean("is_active").default(true),
  externalLink: text("external_link"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sponsorCandidates = pgTable("sponsor_candidates", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(),
  tier: text("tier").notNull(),
  companyName: text("company_name").notNull(),
  logoUrl: text("logo_url"),
  logoThumbUrl: text("logo_thumb_url"),
  websiteUrl: text("website_url"),
  contactEmail: text("contact_email"),
  approved: text("approved").default("pending"),
  sponsoringEvent: text("sponsoring_event"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  excerpt: text("excerpt"),
  content: text("content").notNull(),
  coverImageUrl: text("cover_image_url"),
  category: text("category").default("News"),
  author: text("author"),
  published: boolean("published").default(false),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const ticketPurchases = pgTable("ticket_purchases", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  buyerName: text("buyer_name").notNull(),
  buyerEmail: text("buyer_email").notNull(),
  quantity: integer("quantity").notNull(),
  totalAmount: integer("total_amount").notNull(),
  paymentOrderId: text("payment_order_id"),
  confirmationNumber: text("confirmation_number").notNull(),
  status: text("status").notNull().default("pending"),
  purchasedAt: timestamp("purchased_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({ username: true, password: true });
export const insertEventSchema = createInsertSchema(events).omit({ id: true });
export const insertSponsorSchema = createInsertSchema(sponsors).omit({ id: true });
export const insertBusinessSchema = createInsertSchema(businesses).omit({ id: true });
export const insertContactMessageSchema = createInsertSchema(contactMessages).omit({ id: true, createdAt: true });
export const insertPhotoAlbumSchema = createInsertSchema(photoAlbums).omit({ id: true, createdAt: true });
export const insertAlbumPhotoSchema = createInsertSchema(albumPhotos).omit({ id: true, createdAt: true });
export const insertVendorRegistrationSchema = createInsertSchema(vendorRegistrations).omit({ id: true, createdAt: true });
export const insertSponsorshipInquirySchema = createInsertSchema(sponsorshipInquiries).omit({ id: true, createdAt: true });
export const insertRegistrationSettingsSchema = createInsertSchema(registrationSettings);
export const insertNewsletterSubscriberSchema = createInsertSchema(newsletterSubscribers).omit({ id: true, subscribedAt: true, unsubscribedAt: true });
export const insertNewsletterSchema = createInsertSchema(newsletters).omit({ id: true, createdAt: true, sentAt: true });
export const insertEventProgramSchema = createInsertSchema(eventPrograms).omit({ id: true, createdAt: true });
export const insertSponsorCandidateSchema = createInsertSchema(sponsorCandidates).omit({ id: true, createdAt: true });
export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({ id: true, createdAt: true, updatedAt: true });
export const insertTicketPurchaseSchema = createInsertSchema(ticketPurchases).omit({ id: true, purchasedAt: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Sponsor = typeof sponsors.$inferSelect;
export type InsertSponsor = z.infer<typeof insertSponsorSchema>;
export type Business = typeof businesses.$inferSelect;
export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;
export type PhotoAlbum = typeof photoAlbums.$inferSelect;
export type InsertPhotoAlbum = z.infer<typeof insertPhotoAlbumSchema>;
export type AlbumPhoto = typeof albumPhotos.$inferSelect;
export type InsertAlbumPhoto = z.infer<typeof insertAlbumPhotoSchema>;
export type VendorRegistration = typeof vendorRegistrations.$inferSelect;
export type InsertVendorRegistration = z.infer<typeof insertVendorRegistrationSchema>;
export type SponsorshipInquiry = typeof sponsorshipInquiries.$inferSelect;
export type InsertSponsorshipInquiry = z.infer<typeof insertSponsorshipInquirySchema>;
export type SiteContent = typeof siteContent.$inferSelect;
export type RegistrationSettings = typeof registrationSettings.$inferSelect;
export type InsertRegistrationSettings = z.infer<typeof insertRegistrationSettingsSchema>;
export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;
export type InsertNewsletterSubscriber = z.infer<typeof insertNewsletterSubscriberSchema>;
export type Newsletter = typeof newsletters.$inferSelect;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;
export type NewsletterBatch = typeof newsletterBatches.$inferSelect;
export type EventProgram = typeof eventPrograms.$inferSelect;
export type InsertEventProgram = z.infer<typeof insertEventProgramSchema>;
export type SponsorCandidate = typeof sponsorCandidates.$inferSelect;
export type InsertSponsorCandidate = z.infer<typeof insertSponsorCandidateSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type TicketPurchase = typeof ticketPurchases.$inferSelect;
export type InsertTicketPurchase = z.infer<typeof insertTicketPurchaseSchema>;
