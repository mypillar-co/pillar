import type { OrgConfig } from "./org-config";

export type ContentHookEvent =
  | "event.activated"
  | "event.updated"
  | "ticket_sales.opened"
  | "ticket.purchased"
  | "ticket_sales.sold_out"
  | "ticket_sales.milestone"
  | "blog.published"
  | "vendor.registered"
  | "sponsor.added";

export type ContentPriority = "urgent" | "high" | "normal" | "low";
export type ContentCategory = "announcement" | "promotion" | "update" | "milestone" | "recognition" | "internal";
export type SuggestedPlatform = "x" | "facebook" | "instagram";

export interface StrategyHints {
  priority: ContentPriority;
  category: ContentCategory;
  suggestedPlatforms: SuggestedPlatform[];
  postImmediately: boolean;
  cadenceKey?: string;
  cadenceLimitPerDay?: number;
  suggestedTone?: string;
  includeImage: boolean;
  includeLink: boolean;
  threadWorthy: boolean;
}

export interface ContentHookPayload {
  event: ContentHookEvent;
  orgName: string;
  orgWebsite: string;
  timestamp: string;
  strategy: StrategyHints;
  data: Record<string, any>;
}

const MILESTONE_THRESHOLDS = [10, 25, 50, 75, 100, 150, 200, 250, 500];

const STRATEGY: Record<ContentHookEvent, StrategyHints> = {
  "event.activated": {
    priority: "high",
    category: "announcement",
    suggestedPlatforms: ["x", "facebook", "instagram"],
    postImmediately: false,
    suggestedTone: "excited, inviting",
    includeImage: true,
    includeLink: true,
    threadWorthy: false,
  },
  "event.updated": {
    priority: "normal",
    category: "update",
    suggestedPlatforms: ["x", "facebook"],
    postImmediately: true,
    suggestedTone: "informative, clear",
    includeImage: false,
    includeLink: true,
    threadWorthy: false,
  },
  "ticket_sales.opened": {
    priority: "high",
    category: "promotion",
    suggestedPlatforms: ["x", "facebook", "instagram"],
    postImmediately: false,
    suggestedTone: "exciting, urgency without pressure",
    includeImage: true,
    includeLink: true,
    threadWorthy: false,
  },
  "ticket.purchased": {
    priority: "low",
    category: "internal",
    suggestedPlatforms: [],
    postImmediately: false,
    includeImage: false,
    includeLink: false,
    threadWorthy: false,
  },
  "ticket_sales.sold_out": {
    priority: "urgent",
    category: "announcement",
    suggestedPlatforms: ["x", "facebook", "instagram"],
    postImmediately: true,
    suggestedTone: "celebratory, fomo-inducing for future events",
    includeImage: true,
    includeLink: true,
    threadWorthy: false,
  },
  "ticket_sales.milestone": {
    priority: "normal",
    category: "milestone",
    suggestedPlatforms: ["x", "facebook"],
    postImmediately: false,
    cadenceKey: "ticket_milestone",
    cadenceLimitPerDay: 1,
    suggestedTone: "momentum, social proof",
    includeImage: false,
    includeLink: true,
    threadWorthy: false,
  },
  "blog.published": {
    priority: "high",
    category: "announcement",
    suggestedPlatforms: ["x", "facebook", "instagram"],
    postImmediately: false,
    suggestedTone: "match the blog post tone — recap=reflective, news=informative, spotlight=warm",
    includeImage: true,
    includeLink: true,
    threadWorthy: true,
  },
  "vendor.registered": {
    priority: "low",
    category: "internal",
    suggestedPlatforms: [],
    postImmediately: false,
    includeImage: false,
    includeLink: false,
    threadWorthy: false,
  },
  "sponsor.added": {
    priority: "normal",
    category: "recognition",
    suggestedPlatforms: ["x", "facebook"],
    postImmediately: false,
    cadenceKey: "sponsor_recognition",
    cadenceLimitPerDay: 2,
    suggestedTone: "grateful, professional, tag the sponsor if possible",
    includeImage: true,
    includeLink: false,
    threadWorthy: false,
  },
};

export function createContentHook(config: OrgConfig) {
  const webhookUrl = config.pillarWebhookUrl;

  async function fire(event: ContentHookEvent, data: Record<string, any>, strategyOverrides?: Partial<StrategyHints>): Promise<void> {
    if (!webhookUrl) return;

    const strategy = { ...STRATEGY[event], ...strategyOverrides };

    const payload: ContentHookPayload = {
      event,
      orgName: config.name,
      orgWebsite: config.website,
      timestamp: new Date().toISOString(),
      strategy,
      data,
    };

    try {
      const res = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Content-Hook": event,
          "X-Content-Priority": strategy.priority,
          "X-Content-Category": strategy.category,
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(5000),
      });
      if (!res.ok) {
        console.error(`Content hook ${event} failed: ${res.status}`);
      }
    } catch (err) {
      console.error(`Content hook ${event} error (non-blocking):`, err);
    }
  }

  return {
    eventActivated(event: { title: string; slug: string; date: string; time: string; location: string; category: string; description: string; isTicketed?: boolean; ticketPrice?: string | null; imageUrl?: string | null }) {
      fire("event.activated", {
        title: event.title,
        slug: event.slug,
        date: event.date,
        time: event.time,
        location: event.location,
        category: event.category,
        description: event.description,
        isTicketed: event.isTicketed || false,
        ticketPrice: event.ticketPrice || null,
        imageUrl: event.imageUrl || null,
        url: `https://${config.website}/events/${event.slug}`,
      });
    },

    eventUpdated(event: { title: string; slug: string; date: string; time: string; location: string }, changedFields: string[]) {
      const dateChanged = changedFields.includes("date") || changedFields.includes("time");
      fire("event.updated", {
        title: event.title,
        slug: event.slug,
        date: event.date,
        time: event.time,
        location: event.location,
        changedFields,
        url: `https://${config.website}/events/${event.slug}`,
      }, dateChanged ? { priority: "high", postImmediately: true } : undefined);
    },

    ticketSalesOpened(event: { title: string; slug: string; date: string; ticketPrice: string | null; ticketCapacity: number | null; imageUrl?: string | null }) {
      fire("ticket_sales.opened", {
        title: event.title,
        slug: event.slug,
        date: event.date,
        ticketPrice: event.ticketPrice,
        capacity: event.ticketCapacity,
        imageUrl: event.imageUrl || null,
        url: `https://${config.website}/events/${event.slug}`,
      });
    },

    ticketPurchased(event: { title: string; slug: string; date: string }, sold: number, capacity: number | null) {
      fire("ticket.purchased", {
        eventTitle: event.title,
        eventSlug: event.slug,
        eventDate: event.date,
        totalSold: sold,
        capacity,
        remaining: capacity ? capacity - sold : null,
        percentSold: capacity ? Math.round((sold / capacity) * 100) : null,
        url: `https://${config.website}/events/${event.slug}`,
      });

      if (capacity && sold >= capacity) {
        fire("ticket_sales.sold_out", {
          eventTitle: event.title,
          eventSlug: event.slug,
          eventDate: event.date,
          totalSold: sold,
          url: `https://${config.website}/events/${event.slug}`,
        });
      } else {
        const milestone = MILESTONE_THRESHOLDS.find(t => sold >= t && sold - 1 < t);
        if (milestone) {
          const urgency = capacity && sold / capacity >= 0.8;
          fire("ticket_sales.milestone", {
            eventTitle: event.title,
            eventSlug: event.slug,
            eventDate: event.date,
            milestone,
            totalSold: sold,
            capacity,
            percentSold: capacity ? Math.round((sold / capacity) * 100) : null,
            url: `https://${config.website}/events/${event.slug}`,
          }, urgency ? {
            priority: "high",
            suggestedTone: "urgency, scarcity — almost sold out",
            suggestedPlatforms: ["x", "facebook", "instagram"],
          } : undefined);
        }
      }
    },

    blogPublished(post: { title: string; slug: string; excerpt: string | null; category: string | null; author: string | null; coverImageUrl: string | null }) {
      const category = (post.category || "").toLowerCase();
      let tone = "informative, community-focused";
      if (category.includes("recap")) tone = "reflective, celebratory";
      if (category.includes("spotlight") || category.includes("profile")) tone = "warm, appreciative";
      if (category.includes("press") || category.includes("release")) tone = "professional, newsworthy";
      if (category.includes("announcement")) tone = "exciting, forward-looking";

      fire("blog.published", {
        title: post.title,
        slug: post.slug,
        excerpt: post.excerpt,
        category: post.category,
        author: post.author,
        coverImageUrl: post.coverImageUrl,
        url: `https://${config.website}/blog/${post.slug}`,
      }, {
        suggestedTone: tone,
        includeImage: !!post.coverImageUrl,
        threadWorthy: (post.excerpt?.length || 0) > 200,
      });
    },

    vendorRegistered(vendor: { businessName: string; vendorCategory: string; eventType: string }) {
      fire("vendor.registered", {
        businessName: vendor.businessName,
        vendorCategory: vendor.vendorCategory,
        eventType: vendor.eventType,
      });
    },

    sponsorAdded(sponsor: { name: string; level: string; eventType?: string }) {
      const isPremium = sponsor.level.toLowerCase().includes("presenting") || sponsor.level.toLowerCase().includes("gold");
      fire("sponsor.added", {
        name: sponsor.name,
        level: sponsor.level,
        eventType: sponsor.eventType,
      }, isPremium ? {
        priority: "high",
        suggestedPlatforms: ["x", "facebook", "instagram"],
        suggestedTone: "grateful, spotlight — this is a major sponsor, give them a dedicated post",
      } : undefined);
    },
  };
}
