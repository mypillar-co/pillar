export interface OrgConfig {
  name: string;
  shortName: string;
  tagline: string;
  address: string;
  mailingAddress: string;
  phone: string;
  altPhone?: string;
  email: string;
  eventsEmail?: string;
  meetingDay?: string;
  meetingTime?: string;
  meetingLocation?: string;
  website: string;
  social: {
    facebook?: string;
    instagram?: string;
  };
  branding: {
    logoInitials: string;
    primaryColor: string;
    accentColor: string;
    fontSans: string;
    fontSerif: string;
  };
  location: {
    city: string;
    state: string;
    stateAbbrev: string;
  };
  stats: {
    annualEvents: string;
    annualAttendees: string;
    localBusinesses: string;
    volunteerRun: string;
  };
  partners: { name: string; description: string; website?: string }[];
  sponsorshipLevels: SponsorshipLevel[];
  vendorCategories: string[];
  eventCategories: string[];
  paymentProvider: "square" | "stripe";
  emailProvider: "sendgrid";
  pillarWebhookUrl?: string;
}

export interface SponsorshipLevel {
  name: string;
  price: number;
  tag: string;
  perks: string[];
}

export const EXAMPLE_CONFIG: OrgConfig = {
  name: "Irwin Business & Professional Association",
  shortName: "IBPA",
  tagline: "Promoting the health and vitality of Downtown Irwin",
  address: "424 Main St, Irwin, PA 15642",
  mailingAddress: "PO Box 222, Irwin, PA 15642",
  phone: "(724) 864-3100",
  altPhone: "(724) 216-6200",
  email: "ibpasecretary@outlook.com",
  eventsEmail: "irwinbpa@gmail.com",
  meetingDay: "Every Thursday",
  meetingTime: "8:00 - 9:00 AM",
  meetingLocation: "Colonial Grille Taproom, Main Street, Downtown Irwin",
  website: "downtownirwin.com",
  social: {
    facebook: "https://www.facebook.com/discoverdowntownirwin",
  },
  branding: {
    logoInitials: "DI",
    primaryColor: "15 80% 45%",
    accentColor: "210 60% 45%",
    fontSans: "Montserrat, sans-serif",
    fontSerif: "Libre Baskerville, serif",
  },
  location: {
    city: "Irwin",
    state: "Pennsylvania",
    stateAbbrev: "PA",
  },
  stats: {
    annualEvents: "15+",
    annualAttendees: "1,000+",
    localBusinesses: "50+",
    volunteerRun: "100%",
  },
  partners: [
    { name: "Borough of Irwin", description: "Local government partner" },
    { name: "The Irwin Project", description: "Nonprofit focused on community revitalization" },
    { name: "Norwin Chamber of Commerce", description: "Regional business advocacy" },
    { name: "Norwin Rotary", description: "Community service organization" },
  ],
  sponsorshipLevels: [
    {
      name: "Presenting Sponsor",
      price: 600,
      tag: "Exclusive",
      perks: [
        'Event listed as "presented by [Business Name]"',
        "Name or logo on flyers and key promotions",
        "Print media recognition when applicable",
        "Dedicated sponsor spotlight on social media",
        "Website sponsor recognition with link",
        "Verbal recognition when applicable",
        "Post-event social media thank-you",
      ],
    },
    {
      name: "Gold Sponsor",
      price: 400,
      tag: "Best Value",
      perks: [
        "Name or logo on event flyers",
        "Recognition in print media when applicable",
        "Group sponsor recognition on social media",
        "Website sponsor recognition or link",
        "Verbal recognition when announcements are part of the event",
        "Inclusion in post-event social media thank-you",
      ],
    },
    {
      name: "Silver Sponsor",
      price: 200,
      tag: "",
      perks: [
        "Business name listed on event flyers",
        "Group sponsor recognition on social media",
        "Website sponsor shout-out or link",
        "Inclusion in post-event social media thank-you",
      ],
    },
    {
      name: "Supporting Sponsor",
      price: 100,
      tag: "",
      perks: [
        "Business name included in group sponsor recognition on social media",
        "Inclusion in post-event social media thank-you",
      ],
    },
  ],
  vendorCategories: [
    "Food & Beverage",
    "Arts & Crafts",
    "Jewelry & Accessories",
    "Home & Garden",
    "Health & Wellness",
    "Clothing & Apparel",
    "Local Produce",
    "Baked Goods",
    "Non-Profit / Community",
    "Other",
  ],
  eventCategories: ["All", "Festival", "Shopping", "Holiday", "Car Show", "Community"],
  paymentProvider: "square",
  emailProvider: "sendgrid",
};
