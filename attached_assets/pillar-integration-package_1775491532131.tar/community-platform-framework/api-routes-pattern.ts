import type { Express, Request, Response, NextFunction } from "express";
import type { IStorage } from "./storage-interface";
import type { OrgConfig } from "./org-config";
import { z } from "zod";
import bcrypt from "bcrypt";
import crypto from "crypto";
import {
  insertEventSchema,
  insertSponsorSchema,
  insertBusinessSchema,
  insertContactMessageSchema,
  insertPhotoAlbumSchema,
  insertVendorRegistrationSchema,
  insertSponsorshipInquirySchema,
  insertBlogPostSchema,
} from "./schema";
import { computeRegistrationWindow } from "./registration-window-engine";
import { createContentHook } from "./content-hooks";

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!(req.session as any).userId) {
    return res.status(401).json({ error: "Not authenticated" });
  }
  next();
}

export function registerPublicRoutes(app: Express, storage: IStorage, config: OrgConfig) {
  const hooks = createContentHook(config);

  app.get("/api/events", async (req, res) => {
    res.set("Cache-Control", "no-cache, no-store, must-revalidate");
    const events = await storage.getEvents();
    const includeAll = req.query.all === "true";
    res.json(includeAll ? events : events.filter(e => e.isActive !== false));
  });

  app.get("/api/events/slug/:slug", async (req, res) => {
    res.set("Cache-Control", "no-cache, no-store, must-revalidate");
    const event = await storage.getEventBySlug(req.params.slug);
    if (!event) return res.status(404).json({ error: "Event not found" });
    res.json(event);
  });

  app.get("/api/businesses", async (_req, res) => {
    res.json(await storage.getBusinesses());
  });

  app.get("/api/sponsors", async (_req, res) => {
    res.json(await storage.getSponsors());
  });

  app.get("/api/sponsors/event/:eventType", async (req, res) => {
    const sponsors = await storage.getSponsorsByEvent(req.params.eventType);
    res.json(sponsors);
  });

  app.post("/api/contact", async (req, res) => {
    try {
      const { website, formTiming, ...formData } = req.body;
      if (website) return res.json({ success: true });
      if (typeof formTiming === "number" && formTiming < 3000) return res.json({ success: true });

      const data = insertContactMessageSchema.parse(formData);
      const message = await storage.createContactMessage(data);
      res.status(201).json(message);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  app.get("/api/photo-albums", async (_req, res) => {
    res.json(await storage.getPhotoAlbums());
  });

  app.get("/api/photo-albums/:id", async (req, res) => {
    const album = await storage.getPhotoAlbum(parseInt(req.params.id));
    if (!album) return res.status(404).json({ error: "Album not found" });
    res.json(album);
  });

  app.get("/api/photo-albums/:id/photos", async (req, res) => {
    res.json(await storage.getAlbumPhotos(parseInt(req.params.id)));
  });

  app.get("/api/site-content", async (_req, res) => {
    const content = await storage.getAllSiteContent();
    const map: Record<string, string> = {};
    for (const row of content) map[row.key] = row.value;
    res.json(map);
  });

  app.get("/api/registration-status/:eventType", async (req, res) => {
    try {
      const { eventType } = req.params;
      const settings = await storage.getRegistrationSettings(eventType);
      const event = await storage.getEventBySlug(eventType);
      const isTicketed = event?.isTicketed || false;
      const status = computeRegistrationWindow(settings || null, isTicketed);
      res.json(status);
    } catch {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/vendor-registrations", async (req, res) => {
    try {
      const data = insertVendorRegistrationSchema.parse(req.body);
      if (data.eventType) {
        const settings = await storage.getRegistrationSettings(data.eventType);
        const event = await storage.getEventBySlug(data.eventType);
        const status = computeRegistrationWindow(settings || null, event?.isTicketed || false);
        if (!status.vendorOpen) {
          return res.status(403).json({ error: "Vendor registration is currently closed" });
        }
      }
      const registration = await storage.createVendorRegistration(data);
      hooks.vendorRegistered({ businessName: data.businessName, vendorCategory: data.vendorCategory, eventType: data.eventType });
      res.status(201).json(registration);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  app.post("/api/sponsorship-inquiries", async (req, res) => {
    try {
      const data = insertSponsorshipInquirySchema.parse(req.body);
      const inquiry = await storage.createSponsorshipInquiry(data);
      res.status(201).json(inquiry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  // ============================================================
  // BLOG / NEWS (conditional — only if blog enabled)
  // ============================================================
  app.get("/api/blog", async (_req, res) => {
    const posts = await storage.getBlogPosts(true);
    res.json(posts);
  });

  app.get("/api/blog/:slug", async (req, res) => {
    const post = await storage.getBlogPostBySlug(req.params.slug);
    if (!post || !post.published) return res.status(404).json({ error: "Post not found" });
    res.json(post);
  });

  app.get("/api/events/:slug/ticket-availability", async (req, res) => {
    try {
      const event = await storage.getEventBySlug(req.params.slug);
      if (!event || !event.isTicketed) return res.status(404).json({ error: "Not a ticketed event" });
      const sold = await storage.getTicketsSoldForEvent(event.id);
      const remaining = event.ticketCapacity ? event.ticketCapacity - sold : null;
      res.json({
        ticketPrice: event.ticketPrice || "0",
        capacity: event.ticketCapacity,
        sold,
        remaining,
        available: remaining === null || remaining > 0,
      });
    } catch {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/events/:slug/ticket-checkout", async (req, res) => {
    try {
      const event = await storage.getEventBySlug(req.params.slug);
      if (!event || !event.isTicketed) return res.status(404).json({ error: "Not a ticketed event" });

      const { buyerName, buyerEmail, quantity } = req.body;
      if (!buyerName || !buyerEmail || !quantity || quantity < 1 || quantity > 10) {
        return res.status(400).json({ error: "Invalid purchase data" });
      }

      const price = parseFloat(event.ticketPrice || "0");
      const amountCents = Math.round(price * quantity * 100);

      if (event.ticketCapacity) {
        const sold = await storage.getTicketsSoldForEvent(event.id);
        if (sold + quantity > event.ticketCapacity) {
          return res.status(400).json({ error: "Not enough tickets available" });
        }
      }

      const confirmationNumber = `TIX-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

      const purchase = await storage.createTicketPurchase({
        eventId: event.id,
        buyerName,
        buyerEmail,
        quantity,
        totalAmount: amountCents,
        confirmationNumber,
        status: "pending",
      });

      // --- PAYMENT PROVIDER INTEGRATION POINT ---
      // Replace with Square or Stripe checkout link creation
      // Square: use Square Checkout API to create payment link
      // Stripe: use Stripe Checkout Session API
      //
      // const checkoutUrl = await createCheckoutLink({
      //   amount: amountCents,
      //   currency: "USD",
      //   description: `${quantity}x ticket - ${event.title}`,
      //   metadata: { purchaseId: purchase.id, eventSlug: event.slug },
      //   successUrl: `${baseUrl}/payment-success?confirmation=${confirmationNumber}`,
      //   cancelUrl: `${baseUrl}/events/${event.slug}`,
      // });
      //
      // res.json({ checkoutUrl });

      const sold = await storage.getTicketsSoldForEvent(event.id);
      hooks.ticketPurchased(
        { title: event.title, slug: event.slug || "", date: event.date },
        sold,
        event.ticketCapacity
      );

      res.json({ checkoutUrl: "/payment-success?confirmation=" + confirmationNumber, purchaseId: purchase.id });
    } catch (err) {
      console.error("Ticket checkout error:", err);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { email, firstName, website, formTiming } = req.body;
      if (website) return res.json({ message: "Subscribed!" });
      if (typeof formTiming === "number" && formTiming < 2000) return res.json({ message: "Subscribed!" });

      if (!email || typeof email !== "string") {
        return res.status(400).json({ error: "Valid email required" });
      }

      const existing = await storage.getSubscriberByEmail(email.toLowerCase().trim());
      if (existing) {
        if (existing.status === "active") return res.json({ message: "You're already subscribed!" });
        await storage.updateSubscriber(existing.id, { status: "active", unsubscribedAt: null });
        return res.json({ message: "Welcome back! You've been re-subscribed." });
      }

      const unsubscribeToken = crypto.randomBytes(32).toString("hex");
      await storage.createSubscriber({
        email: email.toLowerCase().trim(),
        firstName: firstName?.trim() || null,
        status: "active",
        unsubscribeToken,
      });

      res.json({ message: "Thanks for subscribing!" });
    } catch {
      res.status(500).json({ error: "Failed to subscribe" });
    }
  });
}

export function registerAuthRoutes(app: Express, storage: IStorage) {
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) return res.status(400).json({ error: "Username and password required" });
      const user = await storage.getUserByUsername(username);
      if (!user) return res.status(401).json({ error: "Invalid credentials" });
      const valid = await bcrypt.compare(password, user.password);
      if (!valid) return res.status(401).json({ error: "Invalid credentials" });
      (req.session as any).userId = user.id;
      res.json({ id: user.id, username: user.username });
    } catch {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ error: "Logout failed" });
      res.clearCookie("connect.sid");
      res.json({ ok: true });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!(req.session as any).userId) return res.status(401).json({ error: "Not authenticated" });
    const user = await storage.getUser((req.session as any).userId);
    if (!user) return res.status(401).json({ error: "User not found" });
    res.json({ id: user.id, username: user.username });
  });
}

export function registerAdminRoutes(app: Express, storage: IStorage, config: OrgConfig) {
  const hooks = createContentHook(config);

  app.post("/api/admin/events", requireAuth, async (req, res) => {
    try {
      const body = { ...req.body };
      if (body.ticketCapacity === null || body.ticketCapacity === "") body.ticketCapacity = undefined;
      if (body.ticketPrice === "") body.ticketPrice = null;
      if (body.posterImageUrl === "") body.posterImageUrl = null;
      if (body.imageUrl === "") body.imageUrl = null;
      if (body.externalLink === "") body.externalLink = null;
      const data = insertEventSchema.parse(body);
      if (!data.slug) data.slug = generateSlug(data.title);
      const event = await storage.createEvent(data);
      if (event.isActive !== false) {
        hooks.eventActivated({
          title: event.title, slug: event.slug || "", date: event.date, time: event.time,
          location: event.location, category: event.category, description: event.description,
          isTicketed: event.isTicketed || false, ticketPrice: event.ticketPrice,
        });
        if (event.isTicketed) {
          hooks.ticketSalesOpened({
            title: event.title, slug: event.slug || "", date: event.date,
            ticketPrice: event.ticketPrice || null, ticketCapacity: event.ticketCapacity || null,
          });
        }
      }
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid data", details: error.errors });
      } else {
        res.status(500).json({ error: "Internal server error" });
      }
    }
  });

  app.patch("/api/admin/events/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const before = await storage.getEvent(id);
      const body = { ...req.body };
      if (body.ticketCapacity === null || body.ticketCapacity === "") body.ticketCapacity = undefined;
      if (body.ticketPrice === "") body.ticketPrice = null;
      const data = insertEventSchema.partial().parse(body);
      if (data.title && !data.slug) data.slug = generateSlug(data.title);
      const updated = await storage.updateEvent(id, data);
      if (!updated) return res.status(404).json({ error: "Event not found" });

      if (before && updated.isActive !== false) {
        const wasInactive = before.isActive === false;
        if (wasInactive) {
          hooks.eventActivated({
            title: updated.title, slug: updated.slug || "", date: updated.date, time: updated.time,
            location: updated.location, category: updated.category, description: updated.description,
            isTicketed: updated.isTicketed || false, ticketPrice: updated.ticketPrice,
          });
        } else {
          const changed: string[] = [];
          if (before.date !== updated.date) changed.push("date");
          if (before.time !== updated.time) changed.push("time");
          if (before.location !== updated.location) changed.push("location");
          if (before.title !== updated.title) changed.push("title");
          if (changed.length > 0) {
            hooks.eventUpdated(
              { title: updated.title, slug: updated.slug || "", date: updated.date, time: updated.time, location: updated.location },
              changed
            );
          }
        }
        if (updated.isTicketed && !before.isTicketed) {
          hooks.ticketSalesOpened({
            title: updated.title, slug: updated.slug || "", date: updated.date,
            ticketPrice: updated.ticketPrice || null, ticketCapacity: updated.ticketCapacity || null,
          });
        }
      }

      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ error: "Invalid data", details: error.errors });
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/admin/events/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteEvent(id);
      if (!deleted) return res.status(404).json({ error: "Event not found" });
      res.json({ ok: true });
    } catch {
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.post("/api/admin/businesses", requireAuth, async (req, res) => {
    try {
      const data = insertBusinessSchema.parse(req.body);
      res.status(201).json(await storage.createBusiness(data));
    } catch (error) {
      if (error instanceof z.ZodError) res.status(400).json({ error: "Invalid data", details: error.errors });
      else res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/admin/businesses/:id", requireAuth, async (req, res) => {
    try {
      const data = insertBusinessSchema.partial().parse(req.body);
      const updated = await storage.updateBusiness(parseInt(req.params.id), data);
      if (!updated) return res.status(404).json({ error: "Business not found" });
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ error: "Invalid data", details: error.errors });
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/admin/businesses/:id", requireAuth, async (req, res) => {
    try {
      const deleted = await storage.deleteBusiness(parseInt(req.params.id));
      if (!deleted) return res.status(404).json({ error: "Business not found" });
      res.json({ ok: true });
    } catch { res.status(500).json({ error: "Internal server error" }); }
  });

  app.post("/api/admin/sponsors", requireAuth, async (req, res) => {
    try {
      const data = insertSponsorSchema.parse(req.body);
      const sponsor = await storage.createSponsor(data);
      hooks.sponsorAdded({ name: sponsor.name, level: sponsor.level, eventType: sponsor.eventType || undefined });
      res.status(201).json(sponsor);
    } catch (error) {
      if (error instanceof z.ZodError) res.status(400).json({ error: "Invalid data", details: error.errors });
      else res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/admin/sponsors/:id", requireAuth, async (req, res) => {
    try {
      const data = insertSponsorSchema.partial().parse(req.body);
      const updated = await storage.updateSponsor(parseInt(req.params.id), data);
      if (!updated) return res.status(404).json({ error: "Sponsor not found" });
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ error: "Invalid data", details: error.errors });
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/admin/sponsors/:id", requireAuth, async (req, res) => {
    try {
      const deleted = await storage.deleteSponsor(parseInt(req.params.id));
      if (!deleted) return res.status(404).json({ error: "Sponsor not found" });
      res.json({ ok: true });
    } catch { res.status(500).json({ error: "Internal server error" }); }
  });

  app.put("/api/admin/site-content", requireAuth, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key || typeof key !== "string" || typeof value !== "string") {
        return res.status(400).json({ error: "Key and value are required strings" });
      }
      res.json(await storage.upsertSiteContent(key, value));
    } catch { res.status(500).json({ error: "Internal server error" }); }
  });

  app.get("/api/admin/contact-messages", requireAuth, async (_req, res) => {
    res.json(await storage.getContactMessages());
  });

  app.get("/api/admin/vendor-registrations", requireAuth, async (req, res) => {
    const eventType = req.query.eventType as string | undefined;
    res.json(await storage.getVendorRegistrations(eventType));
  });

  app.get("/api/admin/sponsorship-inquiries", requireAuth, async (_req, res) => {
    res.json(await storage.getSponsorshipInquiries());
  });

  app.get("/api/admin/ticket-purchases/:eventId", requireAuth, async (req, res) => {
    res.json(await storage.getTicketPurchasesByEvent(parseInt(req.params.eventId)));
  });

  // ============================================================
  // ADMIN: BLOG / NEWS (conditional — only if blog enabled)
  // ============================================================
  app.get("/api/admin/blog", requireAuth, async (_req, res) => {
    res.json(await storage.getBlogPosts(false));
  });

  app.post("/api/admin/blog", requireAuth, async (req, res) => {
    try {
      const body = { ...req.body };
      if (!body.slug && body.title) body.slug = generateSlug(body.title);
      if (body.published && !body.publishedAt) body.publishedAt = new Date();
      const data = insertBlogPostSchema.parse(body);
      const post = await storage.createBlogPost(data);
      if (post.published) {
        hooks.blogPublished({
          title: post.title, slug: post.slug, excerpt: post.excerpt,
          category: post.category, author: post.author, coverImageUrl: post.coverImageUrl,
        });
      }
      res.status(201).json(post);
    } catch (error) {
      if (error instanceof z.ZodError) res.status(400).json({ error: "Invalid data", details: error.errors });
      else res.status(500).json({ error: "Internal server error" });
    }
  });

  app.patch("/api/admin/blog/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const before = await storage.getBlogPost(id);
      const body = { ...req.body };
      if (body.title && !body.slug) body.slug = generateSlug(body.title);
      if (body.published === true) {
        if (before && !before.publishedAt) body.publishedAt = new Date();
      }
      body.updatedAt = new Date();
      const data = insertBlogPostSchema.partial().parse(body);
      const updated = await storage.updateBlogPost(id, data);
      if (!updated) return res.status(404).json({ error: "Post not found" });

      if (updated.published && before && !before.published) {
        hooks.blogPublished({
          title: updated.title, slug: updated.slug, excerpt: updated.excerpt,
          category: updated.category, author: updated.author, coverImageUrl: updated.coverImageUrl,
        });
      }

      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ error: "Invalid data", details: error.errors });
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.delete("/api/admin/blog/:id", requireAuth, async (req, res) => {
    try {
      const deleted = await storage.deleteBlogPost(parseInt(req.params.id));
      if (!deleted) return res.status(404).json({ error: "Post not found" });
      res.json({ ok: true });
    } catch { res.status(500).json({ error: "Internal server error" }); }
  });
}
