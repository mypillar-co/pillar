export interface RegistrationWindowConfig {
  openDaysBefore: number;
  closeDaysBefore: number;
}

export const DEFAULT_WINDOW: RegistrationWindowConfig = {
  openDaysBefore: 90,
  closeDaysBefore: 7,
};

export interface RegistrationStatus {
  vendorOpen: boolean;
  sponsorOpen: boolean;
  ticketSalesOpen: boolean;
  eventDate: string | null;
  vendorManuallyClosed: boolean;
  sponsorManuallyClosed: boolean;
  ticketSalesClosed: boolean;
  vendorForceOpen?: boolean;
  sponsorForceOpen?: boolean;
  ticketSalesForceOpen?: boolean;
  isTicketed?: boolean;
  opensAt?: string;
  closesAt?: string;
  reason: "open" | "force-open" | "too-early" | "auto-closed" | "manually-closed" | "no-date-set";
}

export function computeRegistrationWindow(
  settings: {
    eventDate?: string | null;
    vendorRegistrationClosed?: boolean;
    sponsorRegistrationClosed?: boolean;
    vendorRegistrationForceOpen?: boolean;
    sponsorRegistrationForceOpen?: boolean;
    ticketSalesClosed?: boolean;
    ticketSalesForceOpen?: boolean;
  } | null,
  isTicketed: boolean,
  window: RegistrationWindowConfig = DEFAULT_WINDOW,
): RegistrationStatus {
  if (!settings || !settings.eventDate) {
    const vendorForceOpen = settings?.vendorRegistrationForceOpen || false;
    const sponsorForceOpen = settings?.sponsorRegistrationForceOpen || false;
    const ticketSalesForceOpen = settings?.ticketSalesForceOpen || false;
    return {
      vendorOpen: vendorForceOpen,
      sponsorOpen: sponsorForceOpen,
      ticketSalesOpen: ticketSalesForceOpen,
      eventDate: null,
      vendorManuallyClosed: settings?.vendorRegistrationClosed || false,
      sponsorManuallyClosed: settings?.sponsorRegistrationClosed || false,
      ticketSalesClosed: settings?.ticketSalesClosed || false,
      vendorForceOpen,
      sponsorForceOpen,
      ticketSalesForceOpen,
      isTicketed,
      reason: (vendorForceOpen || sponsorForceOpen || ticketSalesForceOpen) ? "force-open" : "no-date-set",
    };
  }

  const vendorForceOpen = settings.vendorRegistrationForceOpen || false;
  const sponsorForceOpen = settings.sponsorRegistrationForceOpen || false;
  const ticketSalesForceOpen = settings.ticketSalesForceOpen || false;

  const now = new Date();
  const eventDate = new Date(settings.eventDate + "T00:00:00");
  const openDate = new Date(eventDate);
  openDate.setDate(openDate.getDate() - window.openDaysBefore);
  const closeDate = new Date(eventDate);
  closeDate.setDate(closeDate.getDate() - window.closeDaysBefore);

  const inWindow = now >= openDate && now <= closeDate;

  const vendorOpen = isTicketed
    ? vendorForceOpen
    : vendorForceOpen || (inWindow && !settings.vendorRegistrationClosed);
  const sponsorOpen = isTicketed
    ? sponsorForceOpen
    : sponsorForceOpen || (inWindow && !settings.sponsorRegistrationClosed);
  const ticketSalesOpen = ticketSalesForceOpen || (inWindow && !settings.ticketSalesClosed);

  let reason: RegistrationStatus["reason"] = "open";
  if (vendorForceOpen || sponsorForceOpen || ticketSalesForceOpen) {
    reason = "force-open";
  } else if (now < openDate) reason = "too-early";
  else if (now > closeDate) reason = "auto-closed";
  else if (isTicketed && settings.ticketSalesClosed) reason = "manually-closed";
  else if (settings.vendorRegistrationClosed && settings.sponsorRegistrationClosed) reason = "manually-closed";

  return {
    vendorOpen,
    sponsorOpen,
    ticketSalesOpen,
    eventDate: settings.eventDate,
    vendorManuallyClosed: settings.vendorRegistrationClosed || false,
    sponsorManuallyClosed: settings.sponsorRegistrationClosed || false,
    ticketSalesClosed: settings.ticketSalesClosed || false,
    vendorForceOpen,
    sponsorForceOpen,
    ticketSalesForceOpen,
    isTicketed,
    opensAt: openDate.toISOString(),
    closesAt: closeDate.toISOString(),
    reason,
  };
}
