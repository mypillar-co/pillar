import type {
  User, InsertUser,
  Event, InsertEvent,
  Sponsor, InsertSponsor,
  Business, InsertBusiness,
  ContactMessage, InsertContactMessage,
  PhotoAlbum, InsertPhotoAlbum,
  AlbumPhoto, InsertAlbumPhoto,
  VendorRegistration, InsertVendorRegistration,
  SponsorshipInquiry, InsertSponsorshipInquiry,
  SiteContent,
  RegistrationSettings,
  NewsletterSubscriber, InsertNewsletterSubscriber,
  Newsletter, InsertNewsletter,
  NewsletterBatch,
  EventProgram, InsertEventProgram,
  SponsorCandidate, InsertSponsorCandidate,
  BlogPost, InsertBlogPost,
  TicketPurchase, InsertTicketPurchase,
} from "./schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  getEventBySlug(slug: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;

  getSponsors(): Promise<Sponsor[]>;
  getSponsorsByEvent(eventType: string): Promise<Sponsor[]>;
  createSponsor(sponsor: InsertSponsor): Promise<Sponsor>;
  updateSponsor(id: number, sponsor: Partial<InsertSponsor>): Promise<Sponsor | undefined>;
  deleteSponsor(id: number): Promise<boolean>;

  getBusinesses(): Promise<Business[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: number, business: Partial<InsertBusiness>): Promise<Business | undefined>;
  deleteBusiness(id: number): Promise<boolean>;

  getContactMessages(): Promise<ContactMessage[]>;
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;

  getPhotoAlbums(): Promise<PhotoAlbum[]>;
  getPhotoAlbum(id: number): Promise<PhotoAlbum | undefined>;
  createPhotoAlbum(album: InsertPhotoAlbum): Promise<PhotoAlbum>;
  updatePhotoAlbum(id: number, album: Partial<InsertPhotoAlbum>): Promise<PhotoAlbum | undefined>;
  deletePhotoAlbum(id: number): Promise<boolean>;

  getAlbumPhotos(albumId: number): Promise<AlbumPhoto[]>;
  createAlbumPhoto(photo: InsertAlbumPhoto): Promise<AlbumPhoto>;
  deleteAlbumPhoto(id: number): Promise<boolean>;

  getVendorRegistrations(eventType?: string): Promise<VendorRegistration[]>;
  createVendorRegistration(reg: InsertVendorRegistration): Promise<VendorRegistration>;
  updateVendorRegistration(id: number, reg: Partial<InsertVendorRegistration>): Promise<VendorRegistration | undefined>;
  deleteVendorRegistration(id: number): Promise<boolean>;

  getSponsorshipInquiries(): Promise<SponsorshipInquiry[]>;
  createSponsorshipInquiry(inquiry: InsertSponsorshipInquiry): Promise<SponsorshipInquiry>;

  getSiteContent(key: string): Promise<SiteContent | undefined>;
  getAllSiteContent(): Promise<SiteContent[]>;
  upsertSiteContent(key: string, value: string): Promise<SiteContent>;

  getRegistrationSettings(eventType: string): Promise<RegistrationSettings | undefined>;
  getAllRegistrationSettings(): Promise<RegistrationSettings[]>;
  upsertRegistrationSettings(settings: RegistrationSettings): Promise<RegistrationSettings>;
  deleteRegistrationSettings(eventType: string): Promise<boolean>;

  getNewsletterSubscribers(): Promise<NewsletterSubscriber[]>;
  getActiveSubscribers(): Promise<NewsletterSubscriber[]>;
  getSubscriberByEmail(email: string): Promise<NewsletterSubscriber | undefined>;
  getSubscriberByToken(token: string): Promise<NewsletterSubscriber | undefined>;
  createSubscriber(sub: InsertNewsletterSubscriber): Promise<NewsletterSubscriber>;
  updateSubscriber(id: number, sub: Partial<NewsletterSubscriber>): Promise<NewsletterSubscriber | undefined>;
  deleteSubscriber(id: number): Promise<boolean>;

  getNewsletters(): Promise<Newsletter[]>;
  getNewsletter(id: number): Promise<Newsletter | undefined>;
  getDueScheduledNewsletters(): Promise<Newsletter[]>;
  createNewsletter(nl: InsertNewsletter): Promise<Newsletter>;
  updateNewsletter(id: number, nl: Partial<Newsletter>): Promise<Newsletter | undefined>;
  deleteNewsletter(id: number): Promise<boolean>;

  getNewsletterBatches(newsletterId: number): Promise<NewsletterBatch[]>;
  getPendingBatches(): Promise<NewsletterBatch[]>;
  createNewsletterBatch(batch: Omit<NewsletterBatch, "id">): Promise<NewsletterBatch>;
  updateNewsletterBatch(id: number, batch: Partial<NewsletterBatch>): Promise<NewsletterBatch | undefined>;

  getEventPrograms(): Promise<EventProgram[]>;
  getEventProgram(id: number): Promise<EventProgram | undefined>;
  getEventProgramBySlug(slug: string): Promise<EventProgram | undefined>;
  getEventProgramByEventType(eventType: string): Promise<EventProgram | undefined>;
  createEventProgram(program: InsertEventProgram): Promise<EventProgram>;
  updateEventProgram(id: number, program: Partial<InsertEventProgram>): Promise<EventProgram | undefined>;
  deleteEventProgram(id: number): Promise<boolean>;

  getSponsorCandidates(eventType?: string): Promise<SponsorCandidate[]>;
  getSponsorCandidate(id: number): Promise<SponsorCandidate | undefined>;
  createSponsorCandidate(candidate: InsertSponsorCandidate): Promise<SponsorCandidate>;
  updateSponsorCandidate(id: number, candidate: Partial<InsertSponsorCandidate>): Promise<SponsorCandidate | undefined>;
  deleteSponsorCandidate(id: number): Promise<boolean>;

  getBlogPosts(publishedOnly?: boolean): Promise<BlogPost[]>;
  getBlogPost(id: number): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: number): Promise<boolean>;

  createTicketPurchase(purchase: InsertTicketPurchase): Promise<TicketPurchase>;
  getTicketPurchase(id: number): Promise<TicketPurchase | undefined>;
  getTicketPurchasesByEvent(eventId: number): Promise<TicketPurchase[]>;
  getTicketsSoldForEvent(eventId: number): Promise<number>;
  getTicketPurchaseByPaymentOrderId(orderId: string): Promise<TicketPurchase | undefined>;
  updateTicketPurchase(id: number, purchase: Partial<InsertTicketPurchase>): Promise<TicketPurchase | undefined>;
  deleteTicketPurchase(id: number): Promise<boolean>;
}
