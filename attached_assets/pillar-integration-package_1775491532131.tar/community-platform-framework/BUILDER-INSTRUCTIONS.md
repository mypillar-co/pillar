# Community Platform Framework — Builder Instructions

This framework contains actual working code extracted from a live community organization website (discoverirwin.com). An AI site builder uses this to generate fully functional sites for any community organization.

**CRITICAL RULES:**
1. Every file in this framework is real, working code. Copy and adapt — never summarize or blueprint.
2. The AI fills in CONFIG VARIABLES and DECIDES WHICH FEATURES TO INCLUDE based on the org type and intake answers.
3. All included pages follow the exact component patterns shown here. Never invent new patterns.

---

## How It Works

1. Ask: "Do you have an existing website?" If yes → crawl it using the crawl spec from `/api/pillar/architecture`, extract content, pre-fill intake questions. Only ask what the crawl missed.
2. Ask remaining questions from `INTAKE-QUESTIONS.ts`
3. Generate an `org-config.ts` from their answers (using `EXAMPLE_CONFIG` as template)
4. Use the org type to select a color palette from `ORG_TYPE_COLOR_PALETTES`
5. **Apply the Feature Decision Matrix below** — include or exclude features based on org type and answers
6. Copy only the relevant code files and sections, replacing org-specific values with the new config values
7. Deploy

---

## Feature Decision Matrix

**This is the AI logic layer.** The framework has every possible feature. You do NOT build all of them for every org. Based on the org type and intake answers, decide what to include.

### Pages — Always Include
These pages are on EVERY site regardless of org type:

| Route | Page | Always included because... |
|-------|------|---------------------------|
| `/` | Home | Every org needs a homepage |
| `/events` | Events List | Every org has events |
| `/events/:slug` | Event Detail | Every event needs its own page |
| `/about` | About | Every org needs to explain who they are |
| `/contact` | Contact | Every org needs a way to be reached |
| `/gallery` | Photo Gallery | Every org has event photos |
| `/admin/login` | Admin Login | Every site needs admin access |
| `/admin` | Admin Dashboard | CRUD for whatever features are enabled |

### Pages — Conditional
Include ONLY when the condition is met:

| Route | Page | Include when... | Skip when... |
|-------|------|-----------------|--------------|
| `/businesses` | Business Directory | Org type is: Main Street org, Downtown Association, Chamber of Commerce, Neighborhood Association | Org type is: Rotary, Lions, VFW, Legion, PTA, Lodge, Arts Council, or any non-business-focused org |
| `/blog` | Blog / News List | Blog = Yes | Blog = No |
| `/blog/:slug` | Blog Post Detail | Blog = Yes | Blog = No |
| `/payment-success` | Payment Confirmation | Ticketed events = Yes | Ticketed events = No |

### Homepage Sections — Conditional
The homepage is assembled from sections. Include or skip based on answers:

| Section | Include when... | Skip when... |
|---------|-----------------|--------------|
| Hero (full-bleed image + tagline) | Always | Never skip |
| Stats (4 number cards) | Always — use whatever stats they provided | Never skip |
| Upcoming Events (3 featured cards) | Always | Never skip |
| Business Highlights (4 business cards) | Business Directory page exists | No directory page |
| Recent Posts (3 latest blog cards) | Blog = Yes | Blog = No |
| Newsletter Signup | Newsletter = Yes | Newsletter = No |
| Partners | They listed partners in intake | No partners listed |

### Event Detail Sections — Conditional
Each event detail page is assembled from sections:

| Section | Include when... | Skip when... |
|---------|-----------------|--------------|
| EventHero (title, date, time, location) | Always | Never skip |
| EventAbout (description) | Always | Never skip |
| EventHighlights (feature cards) | Data exists in site_content | No highlights data |
| EventSchedule (timeline) | Data exists in site_content | No schedule data |
| EventPoster (image) | Event has posterImageUrl | No poster |
| TicketPurchaseSection | Event.isTicketed = true AND ticket sales open | Not ticketed or sales closed |
| VendorRegistration | Vendors = Yes AND (not ticketed OR force-open) AND registration window open | Vendors = No |
| SponsorshipSection | Sponsors = Yes | Sponsors = No |
| ContactCTA | Always | Never skip |

### Features — Conditional

| Feature | Include when... | Skip when... | What to remove if skipped |
|---------|-----------------|--------------|---------------------------|
| Vendor Registration | Intake answer: vendors = Yes | Vendors = No | Remove vendor routes, vendor form components, vendor admin tab, `vendorRegistrations` table can stay but routes/UI excluded |
| Sponsorship Tiers | Intake answer: sponsors = Yes | Sponsors = No | Remove sponsorship routes, tier display components, sponsorship admin tab |
| Ticket Purchase | Intake answer: ticketed events = Yes | Ticketed = No | Remove ticket routes, TicketPurchaseSection component, payment provider integration, reconciler |
| Payment Provider Integration | Ticketed events = Yes | Ticketed = No | No Stripe/Square setup needed |
| Blog / News | Intake answer: blog = Yes | Blog = No | Remove blog routes, BlogListPage, BlogPostDetail, RecentPostsSection, blog admin tab, `blogPosts` table |
| Newsletter Signup | Intake answer: newsletter = Yes | Newsletter = No | Remove newsletter routes, signup component, SendGrid integration, newsletter admin tab |
| Registration Window Engine | Vendors = Yes OR Sponsors = Yes | Both No | Remove registration-window-engine, registration settings routes |

### Stats Section — Adaptive
Use whatever numbers the org provided. If they didn't mention one category, replace it with something relevant:

| If org has... | Show stat as... |
|---------------|-----------------|
| Local businesses | "50+ Local Businesses" |
| NO businesses (not a business org) | "25+ Members" or "10 Years Active" or similar |
| Volunteers | "100% Volunteer Run" |
| NO volunteer info | Skip that stat card or use "X Programs" |

The stats section always shows exactly 4 cards. Fill all 4 with whatever makes sense for the org.

### Navigation — Adaptive
Only show links for pages that exist:

```
Always: Home, Events, About, Contact, Gallery
Conditional: Directory (only if business directory enabled)
Conditional: News (only if blog enabled)
Event Programs dropdown: only if events have showInNav=true
```

### Admin Dashboard — Adaptive
Only show admin tabs for enabled features:

```
Always: Events, Site Content
Conditional: Businesses (if directory enabled), Sponsors (if sponsors enabled),
             Vendor Registrations (if vendors enabled), Blog / News (if blog enabled),
             Newsletter (if newsletter enabled), Ticket Sales (if ticketed events enabled)
```

---

## Crawl-First Workflow

When a customer provides an existing website URL:

1. Crawl it using the crawl spec from `/api/pillar/architecture`
2. Extract: org name, tagline, address, phone, email, social links, about text, event listings, business listings (if any), staff/leadership names
3. Pre-fill intake questions with whatever the crawl found
4. Only ask the customer questions the crawl couldn't answer (org type, payment provider, sponsors yes/no, ticketed events yes/no, stats numbers, partners)
5. Build using the framework

When NO existing website:
- Ask all intake questions from `INTAKE-QUESTIONS.ts`
- Then build

---

## File Map — What Each File Does

| File | Purpose |
|------|---------|
| `org-config.ts` | OrgConfig interface + example. Every org-specific value lives here. |
| `INTAKE-QUESTIONS.ts` | Questions to ask + which config field each answer maps to. |
| `schema.ts` | Full Drizzle ORM database schema. Uses `paymentOrderId` (not provider-specific). |
| `storage-interface.ts` | Complete IStorage interface — every CRUD method the app needs. |
| `api-routes-pattern.ts` | All Express routes: public, auth, admin. Copy directly. |
| `registration-window-engine.ts` | Registration window logic: opens 90 days before event, closes 7 days before. |
| `content-hooks.ts` | Webhook notification system for Pillar autopilot. Fires events on blog publish, event activation, ticket sales, milestones, sold out, sponsor added. |
| `frontend-patterns.tsx` | Every major UI component pattern: Hero, Stats, EventCard, EventDetail, TicketPurchase, Sponsorship, BlogList, BlogPostDetail, RecentPosts, Newsletter, Contact, PhotoGallery, Navigation, Footer. |
| `theme-variables.css` | CSS custom properties for light/dark mode. Replace primary/accent colors per org. |

---

## What Gets Customized Per Organization

### 1. Constants File (`constants.ts`)
Replace with the org's actual data:
```typescript
export const ORG_INFO = {
  name: config.name,
  shortName: config.shortName,
  tagline: config.tagline,
  address: config.address,
  mailingAddress: config.mailingAddress,
  phone: config.phone,
  email: config.email,
  eventsEmail: config.eventsEmail,
  website: config.website,
};
```

### 2. Theme Colors (`theme-variables.css`)
Replace `--primary` and `--accent` with the org's colors from `ORG_TYPE_COLOR_PALETTES`:
```css
--primary: 15 80% 45%;    /* ← from org type lookup */
--accent: 210 60% 45%;    /* ← from org type lookup */
```

### 3. Logo Badge
The nav and footer show a small colored square with the org's initials:
```tsx
<div className="w-9 h-9 rounded-md bg-primary flex items-center justify-center">
  <span className="text-primary-foreground font-bold text-sm font-serif">
    {config.branding.logoInitials}
  </span>
</div>
```

### 4. Page Title Hook
```typescript
export function usePageTitle(title: string, description?: string) {
  useEffect(() => {
    document.title = title
      ? `${title} | ${config.name}`
      : config.name;
  }, [title, description]);
}
```

### 5. Stats Section
Uses `config.stats` values directly — adapt labels based on org type (see Stats Section — Adaptive above).

### 6. Partners Section
Uses `config.partners[]` array directly. Only show if partners were provided.

### 7. Site Content (CMS-lite)
The `site_content` database table is a key-value store. The `useSiteContent()` hook reads it and falls back to constants. This lets the org edit text through the admin panel without code changes. Keys used:
- `contact_address`, `contact_phone`, `contact_email`, `contact_events_email`
- `social_facebook`, `social_instagram`
- `home_tagline`, `home_intro`, `home_subtitle`
- `about_hero_subtitle`, `about_funding_note`
- `community_partners` (JSON array)
- `image_home_hero` (URL)

---

## Security Patterns (Always Include — NO EXCEPTIONS)

### Bot Protection on All Public Forms
Every form that accepts user input uses TWO protections:
1. **Honeypot field** — hidden `website` field, if filled → silently accept (bot thinks it submitted)
2. **Timing check** — record `Date.now()` on form mount, reject if submitted in < 3 seconds (bots submit instantly)

```tsx
// Frontend
const [honeypot, setHoneypot] = useState("");
const [formLoadedAt] = useState(Date.now());

// In submit:
{ website: honeypot, formTiming: Date.now() - formLoadedAt }

// Hidden field:
<div className="absolute opacity-0 h-0 w-0 overflow-hidden" aria-hidden="true" tabIndex={-1}>
  <input type="text" name="website" value={honeypot} onChange={...} tabIndex={-1} autoComplete="off" />
</div>
```

```typescript
// Backend
if (req.body.website) return res.json({ success: true }); // honeypot triggered
if (typeof req.body.formTiming === "number" && req.body.formTiming < 3000) return res.json({ success: true });
```

### Session Auth (Admin)
- Express session with 30-minute timeout
- bcrypt password hashing
- `requireAuth` middleware on all `/api/admin/*` routes

---

## Registration Window Logic

Events have automatic vendor/sponsor registration windows:
- **Opens**: 90 days before event date
- **Closes**: 7 days before event date
- **Force-open override**: Admin can force any registration open regardless of window
- **Manual close**: Admin can close early
- **Ticketed events**: Vendor/sponsor auto-windows are disabled; only force-open works

Only include if vendors OR sponsors are enabled. See `registration-window-engine.ts` for the complete implementation.

---

## Content Hooks (Pillar Autopilot)

When `config.pillarWebhookUrl` is set, the site automatically fires webhook notifications to Pillar when key things happen. Pillar's AI uses these to generate and post social media content without any human involvement.

### Hook Events

| Event | Fires when... | What Pillar does with it |
|-------|---------------|------------------------|
| `event.activated` | New event created as active, or inactive event toggled active | Announce the event on social media |
| `event.updated` | Event date, time, location, or title changes | Post an update ("Date change! [Event] is now on [new date]") |
| `ticket_sales.opened` | Event becomes ticketed (new or updated) | "Tickets are now on sale for [event]!" |
| `ticket.purchased` | Ticket purchase completed | Internal tracking (not necessarily posted) |
| `ticket_sales.milestone` | Total sold crosses 10, 25, 50, 75, 100, 150, 200, 250, or 500 | "50 tickets sold for [event]! Grab yours before they're gone" |
| `ticket_sales.sold_out` | Sold count reaches capacity | "SOLD OUT! [Event] tickets are gone" |
| `blog.published` | Blog post published (new or draft→published) | Summarize and post to social with link |
| `vendor.registered` | New vendor registration submitted | Internal tracking |
| `sponsor.added` | New sponsor created in admin | "Welcome [sponsor] as a [level] sponsor for [event]!" |

### Payload Format

Every webhook POST includes a `strategy` object that tells Pillar's automation engine how to handle it:

```json
{
  "event": "blog.published",
  "orgName": "Norwin Rotary Club",
  "orgWebsite": "norwinrotary.org",
  "timestamp": "2026-04-04T14:30:00.000Z",
  "strategy": {
    "priority": "high",
    "category": "announcement",
    "suggestedPlatforms": ["x", "facebook", "instagram"],
    "postImmediately": false,
    "suggestedTone": "reflective, celebratory",
    "includeImage": true,
    "includeLink": true,
    "threadWorthy": true,
    "cadenceKey": null,
    "cadenceLimitPerDay": null
  },
  "data": {
    "title": "Spring Carnival Recap",
    "slug": "spring-carnival-recap",
    "excerpt": "What a night! Over 500 people...",
    "coverImageUrl": "https://...",
    "url": "https://norwinrotary.org/blog/spring-carnival-recap"
  }
}
```

Headers: `Content-Type: application/json`, `X-Content-Hook: <event_type>`, `X-Content-Priority: <priority>`, `X-Content-Category: <category>`

### Strategy Fields

| Field | Purpose |
|-------|---------|
| `priority` | `urgent` (post now — sold out), `high` (queue next — new event), `normal` (schedule — milestone), `low` (internal only — purchases) |
| `category` | `announcement`, `promotion`, `update`, `milestone`, `recognition`, `internal` — maps to Pillar's content type rules |
| `suggestedPlatforms` | Which platforms this type of content fits. Empty array = don't post publicly |
| `postImmediately` | `true` = skip the scheduling queue, post right away (date changes, sold out) |
| `cadenceKey` | Group ID for rate-limiting. e.g. `ticket_milestone` — don't flood with milestone posts |
| `cadenceLimitPerDay` | Max posts per day for this cadence group. `1` for milestones, `2` for sponsor shout-outs |
| `suggestedTone` | Tone hint for AI copy generation. Adapts per context (recap=reflective, press=professional) |
| `includeImage` | Whether the post should include an image (cover photo, event image, sponsor logo) |
| `includeLink` | Whether to include a link back to the website |
| `threadWorthy` | Whether the content is substantial enough for a thread (X) or long-form post (Facebook) |

### Smart Strategy Behavior

The hooks adapt their strategy hints based on context:

- **Blog tone adapts to category**: "recap" → reflective, "spotlight" → warm, "press release" → professional, "announcement" → exciting
- **Date/time changes escalate**: `event.updated` normally gets `normal` priority, but if date or time changed it escalates to `high` with `postImmediately: true`
- **Ticket milestones get urgent at 80%+ capacity**: Milestone at 50/100 tickets is normal. Milestone at 80/100 escalates to `high` with scarcity tone
- **Presenting/Gold sponsors get premium treatment**: Elevated to `high` priority with all platforms + dedicated post tone
- **Blog thread detection**: Posts with excerpts > 200 chars are flagged `threadWorthy` for X threads

### Integration Rules
- All hooks are **fire-and-forget** with a 5-second timeout — they never block the API response
- If `pillarWebhookUrl` is not set, all hooks are silently skipped (zero overhead)
- Pillar's automation rules are the final authority — strategy hints are suggestions, not commands
- The `category` field maps directly to Pillar's posting strategy rules for each org
- `cadenceKey` + `cadenceLimitPerDay` prevent flooding (Pillar should track and enforce)
- Include content hooks if the org is on a Pillar plan; skip if self-hosted with no Pillar connection

### What Pillar Should NOT Auto-Post
- `vendor.registered` (category: `internal`) — internal tracking only
- `ticket.purchased` (category: `internal`) — individual purchases are private
- Any hook where `suggestedPlatforms` is empty — the framework already filtered it

---

## Payment Integration Points

Only include if ticketed events are enabled.

The schema uses `paymentOrderId` (generic). The routes file has a clearly marked integration point:

```typescript
// --- PAYMENT PROVIDER INTEGRATION POINT ---
// Square: use Square Checkout API to create payment link
// Stripe: use Stripe Checkout Session API
```

### For Square:
- Use Square Checkout API to create payment links
- Webhook endpoint at `POST /api/square/webhook`
- Verify webhook signature with `SQUARE_WEBHOOK_SIGNATURE_KEY`
- On `payment.completed`, update ticket purchase status to "completed"

### For Stripe:
- Use Stripe Checkout Session API
- Webhook endpoint at `POST /api/stripe/webhook`
- Verify webhook with `STRIPE_WEBHOOK_SECRET`
- On `checkout.session.completed`, update ticket purchase status

---

## Required Environment Variables

Always required:

| Variable | Purpose |
|----------|---------|
| `DATABASE_URL` | PostgreSQL connection string |
| `SESSION_SECRET` | Express session encryption key (generate random) |

Conditional:

| Variable | Purpose | When needed |
|----------|---------|-------------|
| `SENDGRID_API_KEY` | Email delivery | Newsletter = Yes OR Ticketed events = Yes |
| `SQUARE_ACCESS_TOKEN` | Square payment API | Payment provider = Square |
| `SQUARE_LOCATION_ID` | Square location | Payment provider = Square |
| `SQUARE_WEBHOOK_SIGNATURE_KEY` | Square webhook verification | Payment provider = Square |
| `STRIPE_SECRET_KEY` | Stripe API key | Payment provider = Stripe |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook verification | Payment provider = Stripe |

---

## Tech Stack (Do Not Change)

- **Runtime**: Node.js with Express
- **Frontend**: React + TypeScript + Vite
- **Routing**: wouter (client), Express (server)
- **Database**: PostgreSQL with Drizzle ORM
- **Styling**: Tailwind CSS + shadcn/ui components
- **Data fetching**: TanStack Query v5
- **Forms**: react-hook-form + zod validation
- **Icons**: lucide-react (UI icons) + react-icons/si (brand logos)
- **Email**: SendGrid (only if newsletter or ticketed events)
- **Payments**: Square or Stripe (only if ticketed events)

---

## What the AI Must NOT Do

1. Do NOT invent new page layouts — use exactly what's in `frontend-patterns.tsx`
2. Do NOT redesign components — change only text, colors, and config values
3. Do NOT add frameworks, libraries, or dependencies beyond the tech stack above
4. Do NOT create "blueprint" or "documentation-only" files — every file must be runnable code
5. Do NOT skip bot protection on any public form
6. Do NOT hardcode org-specific text — always use constants or site_content
7. Do NOT include features the org doesn't need — follow the Feature Decision Matrix
8. Do NOT include a Business Directory for non-business orgs (Rotary, VFW, PTA, Lodge, etc.)
9. Do NOT include payment integration if the org has no ticketed events
10. Do NOT ask intake questions that the website crawl already answered
