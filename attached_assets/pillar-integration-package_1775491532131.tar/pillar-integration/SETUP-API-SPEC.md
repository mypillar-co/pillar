# Pillar Setup API — Integration Spec

## Endpoint

```
POST /api/pillar/setup
```

## Authentication

Header: `X-Pillar-Key: <PILLAR_SERVICE_KEY>`

The service key is set as an environment variable on the deployed site. Pillar must send this exact key in the header.

## Request Body

JSON object with org configuration + optional seed data.

### Org Config Fields (all optional except orgName)

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `orgName` | string | Yes | "My Organization" | Full legal/display name |
| `shortName` | string | No | Auto-generated initials | Short name (e.g. "IBPA", "Rotary") |
| `orgType` | string | No | "community" | Organization type |
| `tagline` | string | No | null | One-line tagline |
| `mission` | string | No | null | Mission statement paragraph |
| `location` | string | No | null | e.g. "Downtown Irwin, PA" |
| `primaryColor` | string | No | "#c25038" | Hex color for primary theme |
| `accentColor` | string | No | "#2563eb" | Hex color for accent theme |
| `logoUrl` | string | No | null | URL to org logo image |
| `heroImageUrl` | string | No | null | URL to homepage hero image |
| `contactEmail` | string | No | null | Public contact email |
| `contactPhone` | string | No | null | Public phone number |
| `contactAddress` | string | No | null | Physical address |
| `mailingAddress` | string | No | null | Mailing/PO Box address |
| `website` | string | No | null | Org website URL |
| `socialFacebook` | string | No | null | Facebook page URL |
| `socialInstagram` | string | No | null | Instagram profile URL |
| `socialTwitter` | string | No | null | Twitter/X profile URL |
| `socialLinkedin` | string | No | null | LinkedIn page URL |
| `meetingDay` | string | No | null | e.g. "Every Thursday" |
| `meetingTime` | string | No | null | e.g. "8:00 - 9:00 AM" |
| `meetingLocation` | string | No | null | e.g. "Main Street Cafe" |
| `footerText` | string | No | null | Custom footer description |
| `metaDescription` | string | No | null | SEO meta description |

### JSON Array Fields (passed as arrays, stored as JSON strings)

| Field | Type | Description |
|-------|------|-------------|
| `stats` | `{value: string, label: string}[]` | Exactly 4 stat cards for homepage |
| `programs` | `{icon: string, title: string, description: string}[]` | Org programs |
| `partners` | `{name: string, description: string, website?: string}[]` | Community partners |
| `sponsorshipLevels` | `{name: string, price: string, benefits: string[]}[]` | Sponsorship tiers |

### Seed Data (optional arrays)

#### `events[]` — Seed initial events

```json
{
  "title": "Annual Gala",
  "description": "Our biggest fundraiser of the year",
  "date": "Saturday, June 14, 2026",
  "time": "6:00 PM - 10:00 PM",
  "location": "Community Center",
  "category": "Fundraiser",
  "featured": true,
  "showInNav": false,
  "hasRegistration": false,
  "imageUrl": null,
  "posterImageUrl": null,
  "externalLink": null,
  "isTicketed": true,
  "ticketPrice": "50.00",
  "ticketCapacity": 200
}
```

#### `sponsors[]` — Seed initial sponsors

```json
{
  "name": "Local Bank",
  "level": "Gold Sponsor",
  "logoUrl": "https://...",
  "websiteUrl": "https://...",
  "eventType": "general"
}
```

#### `businesses[]` — Seed business directory entries

```json
{
  "name": "Main Street Cafe",
  "description": "Local coffee shop and bakery",
  "address": "123 Main St",
  "phone": "(555) 123-4567",
  "website": "https://...",
  "category": "Restaurant",
  "imageUrl": null
}
```

#### `siteContent` — Key-value pairs for CMS content

```json
{
  "home_tagline": "Building community together",
  "home_intro": "We are dedicated to...",
  "home_subtitle": "Civic Organization",
  "about_mission": "Full mission statement here...",
  "contact_address": "123 Main St",
  "contact_phone": "(555) 123-4567",
  "contact_email": "info@example.org",
  "social_facebook": "https://facebook.com/...",
  "social_instagram": "https://instagram.com/..."
}
```

## Response

### Success (200)

```json
{
  "ok": true,
  "orgConfig": {
    "id": 1,
    "orgName": "Norwin Rotary Club",
    "shortName": "NRC"
  },
  "seeded": {
    "siteContent": 5,
    "events": 3,
    "sponsors": 2,
    "businesses": 8
  }
}
```

### Error (401)

```json
{ "error": "Invalid or missing service key" }
```

### Error (400)

```json
{ "error": "Request body must be a JSON object" }
```

### Error (500)

```json
{ "error": "Setup failed" }
```

## Reading Config Back

```
GET /api/org-config
```

No authentication required (public endpoint). Returns the current org config. If no config has been set via setup, returns DI defaults with `_default: true`.

## Behavior Notes

1. **Upsert**: Calling setup multiple times overwrites the org config (single-row design). Events, sponsors, and businesses are additive (new records created each call).
2. **Color theming**: `primaryColor` and `accentColor` are applied as CSS custom properties on the frontend automatically. No CSS file editing needed.
3. **Logo**: If `logoUrl` is provided, it replaces the initials badge in nav and footer. If null, the first 2 characters of `shortName` are shown.
4. **Stats**: Always provide exactly 4 stat objects. The homepage shows exactly 4 cards.
5. **Backward compatibility**: When no org config exists, the site shows Discover Irwin defaults. Setting up a config replaces all branding site-wide.
