# Interview Question → Setup API Payload Map

This maps each intake question answer to the corresponding field in the `POST /api/pillar/setup` payload.

## Direct Mappings

| Interview Question | Payload Field | Type | Notes |
|-------------------|---------------|------|-------|
| Full org name | `orgName` | string | Required |
| Short name / abbreviation | `shortName` | string | Falls back to initials of orgName |
| Tagline / mission (one sentence) | `tagline` | string | |
| Org type | `orgType` | string | e.g. "civic", "community", "business" |
| City + State | `location` | string | Combine: "Downtown Irwin, PA" |
| Physical address | `contactAddress` | string | |
| Mailing address | `mailingAddress` | string | |
| Phone number | `contactPhone` | string | |
| Contact email | `contactEmail` | string | |
| Facebook URL | `socialFacebook` | string | |
| Instagram URL | `socialInstagram` | string | |
| Website URL | `website` | string | |
| Meeting day | `meetingDay` | string | e.g. "Every Thursday" |
| Meeting time | `meetingTime` | string | e.g. "8:00 - 9:00 AM" |
| Meeting location | `meetingLocation` | string | |

## Color Selection

After getting `org_type`, look up colors from `ORG_TYPE_COLOR_PALETTES` in `INTAKE-QUESTIONS.ts`. Convert from HSL to hex for the payload:

| Org Type | `primaryColor` | `accentColor` |
|----------|---------------|---------------|
| Main Street / Downtown Association | `#c25038` | `#2b7ab5` |
| Chamber of Commerce | `#1a4a8a` | `#d4a017` |
| Rotary Club | `#003DA5` | `#d4a017` |
| Lions Club | `#d4a017` | `#1a4a8a` |
| VFW / American Legion | `#8b1a1a` | `#2b5797` |
| PTA / PTO | `#339966` | `#7a3d9e` |
| Community Foundation | `#2d8a57` | `#2b7ab5` |
| Neighborhood Association | `#c26a17` | `#338899` |
| Arts Council | `#7a3d9e` | `#cc3366` |

The org can override these if they have brand colors.

## Stats (Always 4)

Construct the `stats` array from interview answers:

```json
"stats": [
  { "value": "<annual_events answer>", "label": "Annual Events" },
  { "value": "<annual_attendees answer>", "label": "Annual Attendees" },
  { "value": "<local_businesses answer>", "label": "Local Businesses" },
  { "value": "100%", "label": "Volunteer Run" }
]
```

Adapt labels for non-business orgs:
- No business directory → replace "Local Businesses" with "Active Members" or "Years Active"
- Not volunteer-run → replace "Volunteer Run" with "Programs Offered" or similar

## Partners

Convert the partners answer into the `partners` array:

```json
"partners": [
  { "name": "Borough of Irwin", "description": "Local government partner", "website": "https://..." },
  { "name": "The Irwin Project", "description": "Community revitalization nonprofit" }
]
```

## Derived Fields

These aren't directly asked but should be generated from interview answers:

| Payload Field | How To Generate |
|---------------|----------------|
| `mission` | Expand the tagline into 1-2 sentences about the org's purpose |
| `footerText` | Short description for footer, e.g. "[OrgName] is a volunteer organization serving [location]." |
| `metaDescription` | SEO description: "[OrgName] - [tagline]. Community events, [features] in [location]." |
| `logoUrl` | If org provides a logo image URL, include it. Otherwise null (initials badge is used). |
| `heroImageUrl` | If org provides a hero image URL, include it. Otherwise null (default image is used). |

## Site Content (CMS Keys)

Map interview answers to `siteContent` key-value pairs:

```json
"siteContent": {
  "home_tagline": "<tagline>",
  "home_intro": "<mission or expanded intro text>",
  "home_subtitle": "<org_type label, e.g. 'Civic Organization'>",
  "contact_address": "<address>",
  "contact_phone": "<phone>",
  "contact_email": "<email>",
  "meeting_contact_email": "<events_email or email>",
  "social_facebook": "<facebook_url>",
  "social_instagram": "<instagram_url>",
  "about_mission": "<longer mission statement, 2-3 paragraphs>",
  "community_partners": "<JSON string of partners array>"
}
```

## Seed Events

If the org mentions specific upcoming events during the interview, seed them:

```json
"events": [
  {
    "title": "Annual Charity Golf Outing",
    "description": "Join us for a day of golf and fundraising.",
    "date": "Saturday, August 16, 2026",
    "time": "8:00 AM - 4:00 PM",
    "location": "Country Club",
    "category": "Fundraiser",
    "featured": true,
    "isTicketed": true,
    "ticketPrice": "125.00",
    "ticketCapacity": 120
  }
]
```

## Feature Flags → What To Seed

| Interview Answer | What To Include In Payload |
|-----------------|---------------------------|
| has_sponsors = Yes | Include `sponsors` array if they named any |
| has_vendors = Yes | No payload field needed — admin manages vendors |
| has_ticketed_events = Yes | Set `isTicketed: true` + `ticketPrice` + `ticketCapacity` on relevant events |
| has_blog = Yes | No payload field needed — admin manages blog posts |
| has_newsletter = Yes | No payload field needed — frontend section auto-shows |
