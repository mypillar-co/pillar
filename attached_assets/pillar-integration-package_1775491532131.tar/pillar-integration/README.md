# Discover Irwin Community Platform — Pillar Integration Package

## What This Is

This package gives Pillar everything it needs to provision fully functional community organization websites. Each site is a React + Vite + Express + PostgreSQL app built from the same codebase as discoverirwin.com.

## How It Works (Two Approaches)

### Approach A: Provision an Existing Deployment (Setup API)

If you've already deployed a copy of the Discover Irwin codebase for a new org, Pillar can configure it remotely by calling the setup API:

1. Run the AI interview (see `INTAKE-QUESTIONS.ts` in `community-platform-framework/`)
2. Map the answers to the setup API payload format (see `SETUP-API-SPEC.md`)
3. POST to `/api/pillar/setup` with the `X-Pillar-Key` header
4. The site instantly rebrands: colors, name, logo, stats, partners, events, sponsors, businesses, and CMS content all update

**This does NOT require any code changes.** The frontend reads from `/api/org-config` and applies branding dynamically (colors via CSS custom properties, org name/logo in nav/footer/hero).

### Approach B: Build a New Site From Scratch

If Pillar is generating a brand new codebase for an org:

1. Run the AI interview
2. Use `community-platform-framework/BUILDER-INSTRUCTIONS.md` as the master guide
3. Copy the code patterns from the framework files
4. Apply the Feature Decision Matrix to include/exclude features based on org type
5. Deploy

## File Map

### This folder (`pillar-integration/`)

| File | What It Does |
|------|-------------|
| `README.md` | This file — the master guide |
| `SETUP-API-SPEC.md` | Full API spec for `POST /api/pillar/setup` — endpoint, auth, payload shape, response format |
| `example-payload.json` | Complete example payload (Norwin Rotary Club) showing every field |
| `interview-to-payload-map.md` | Maps each interview question → setup API field |

### Framework folder (`community-platform-framework/`)

| File | What It Does |
|------|-------------|
| `BUILDER-INSTRUCTIONS.md` | Master build guide: feature decision matrix, conditional pages/sections, crawl-first workflow, what to customize, security patterns, tech stack |
| `INTAKE-QUESTIONS.ts` | All interview questions + which config field each answer maps to + org type color palettes |
| `org-config.ts` | OrgConfig TypeScript interface + full example config (IBPA) |
| `schema.ts` | Complete Drizzle ORM database schema — all tables |
| `storage-interface.ts` | Full IStorage interface — every CRUD method |
| `api-routes-pattern.ts` | All Express routes: public, auth, admin |
| `frontend-patterns.tsx` | Every major UI component: Hero, Stats, EventCard, Footer, Nav, etc. |
| `theme-variables.css` | CSS custom properties for light/dark mode theming |
| `content-hooks.ts` | Webhook system for Pillar autopilot (social media automation) |
| `registration-window-engine.ts` | Auto open/close logic for vendor/sponsor registration windows |

## What To Tell Pillar

> "Here is the complete framework for building community organization websites. There are two ways to use it:
>
> **Option 1 (Fastest):** We already have a deployed copy of the platform. Run the interview questions from `INTAKE-QUESTIONS.ts`, then call `POST /api/pillar/setup` with the answers mapped to the payload format in `SETUP-API-SPEC.md`. The site rebrands instantly — no code generation needed.
>
> **Option 2 (Custom build):** Follow `BUILDER-INSTRUCTIONS.md` to generate a new codebase. Use the interview to decide which features to include (business directory, blog, ticketing, vendors, sponsors, newsletter). Copy the code patterns from the framework files. Deploy.
>
> For either option, the interview is the same — `INTAKE-QUESTIONS.ts` has every question plus what config field each answer maps to."

## Interview Flow Summary

The AI interview collects:

1. **Org identity** — name, short name, tagline, type (Rotary, Chamber, Main Street org, etc.)
2. **Location & contact** — address, phone, email, social media links
3. **Features** — sponsors? vendors? ticketed events? blog? newsletter?
4. **Content** — stats (4 numbers), partners, event categories
5. **Branding** — logo initials, colors (auto-selected by org type, can override)

If the org has an existing website, Pillar should crawl it first and pre-fill answers — only ask what the crawl missed.

## Setup API Quick Reference

```
POST /api/pillar/setup
Header: X-Pillar-Key: <PILLAR_SERVICE_KEY>
Content-Type: application/json

{
  "orgName": "Norwin Rotary Club",
  "shortName": "NRC",
  "orgType": "civic",
  "primaryColor": "#003DA5",
  "accentColor": "#F7A823",
  ...see SETUP-API-SPEC.md for full payload
}

Response:
{
  "ok": true,
  "orgConfig": { "id": 1, "orgName": "Norwin Rotary Club", "shortName": "NRC" },
  "seeded": { "events": 2, "sponsors": 2, "siteContent": 4 }
}
```

## Environment Variables Pillar Needs To Set

On each deployed site:

| Variable | Required | Purpose |
|----------|----------|---------|
| `PILLAR_SERVICE_KEY` | Yes | Auth key for the setup API |
| `DATABASE_URL` | Yes | PostgreSQL connection |
| `SESSION_SECRET` | Yes | Express session encryption |
| `SENDGRID_API_KEY` | If newsletter or ticketed events | Email delivery |
| `SQUARE_ACCESS_TOKEN` | If payment provider = Square | Payment processing |
| `SQUARE_LOCATION_ID` | If payment provider = Square | Square location |
| `SQUARE_WEBHOOK_SIGNATURE_KEY` | If payment provider = Square | Webhook verification |
