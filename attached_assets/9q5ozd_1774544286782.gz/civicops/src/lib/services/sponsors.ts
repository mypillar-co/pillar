import { db } from "@/lib/db";
import { sponsors, eventSponsors, sponsorTiers, contacts } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { nanoid } from "nanoid";

export async function getSponsors(orgId: string) {
  return db.query.sponsors.findMany({
    where: eq(sponsors.orgId, orgId),
    with: { contact: true },
  });
}

export async function getSponsor(orgId: string, sponsorId: string) {
  return db.query.sponsors.findFirst({
    where: and(eq(sponsors.id, sponsorId), eq(sponsors.orgId, orgId)),
    with: {
      contact: true,
      eventSponsors: { with: { event: true } },
    },
  });
}

export async function createSponsor(orgId: string, data: {
  name: string;
  email?: string;
  phone?: string;
  website?: string;
  logoUrl?: string;
  contactName?: string;
  notes?: string;
}) {
  const sponsorId = nanoid();

  let contactId: string | undefined;
  if (data.contactName || data.email) {
    const cId = nanoid();
    const nameParts = (data.contactName || "").split(" ");
    await db.insert(contacts).values({
      id: cId,
      orgId,
      firstName: nameParts[0] || "Unknown",
      lastName: nameParts.slice(1).join(" ") || undefined,
      email: data.email,
      phone: data.phone,
      contactType: "sponsor_rep",
    });
    contactId = cId;
  }

  await db.insert(sponsors).values({
    id: sponsorId,
    orgId,
    name: data.name,
    email: data.email,
    phone: data.phone,
    website: data.website,
    logoUrl: data.logoUrl,
    contactId,
    notes: data.notes,
    status: "active",
  });

  return { id: sponsorId };
}

export async function assignSponsorToEvent(orgId: string, data: {
  sponsorId: string;
  eventId: string;
  tier?: string;
  amountPledged?: number;
  benefits?: string;
}) {
  const id = nanoid();
  await db.insert(eventSponsors).values({
    id,
    orgId,
    ...data,
    status: "pending",
    amountReceived: 0,
  });
  return { id };
}

export async function updateEventSponsor(orgId: string, eventSponsorId: string, data: Partial<typeof eventSponsors.$inferInsert>) {
  await db.update(eventSponsors)
    .set({ ...data, updatedAt: new Date().toISOString() })
    .where(and(eq(eventSponsors.id, eventSponsorId), eq(eventSponsors.orgId, orgId)));
}

export async function approveSponsor(orgId: string, eventSponsorId: string) {
  await updateEventSponsor(orgId, eventSponsorId, { status: "confirmed" });
}

export async function getEventSponsors(orgId: string, eventId: string) {
  return db.query.eventSponsors.findMany({
    where: and(eq(eventSponsors.eventId, eventId), eq(eventSponsors.orgId, orgId)),
    with: { sponsor: true },
  });
}

export async function getApprovedEventSponsors(orgId: string, eventId: string) {
  return db.query.eventSponsors.findMany({
    where: and(
      eq(eventSponsors.eventId, eventId),
      eq(eventSponsors.orgId, orgId),
      eq(eventSponsors.status, "confirmed")
    ),
    with: { sponsor: true },
  });
}

// Sponsor tiers management
export async function getSponsorTiers(orgId: string) {
  return db.query.sponsorTiers.findMany({
    where: eq(sponsorTiers.orgId, orgId),
    orderBy: (t, { asc }) => [asc(t.sortOrder)],
  });
}

export async function createDefaultSponsorTiers(orgId: string) {
  const defaults = [
    { name: "presenting", amount: 600, sortOrder: 0 },
    { name: "gold", amount: 400, sortOrder: 1 },
    { name: "silver", amount: 200, sortOrder: 2 },
    { name: "supporting", amount: 100, sortOrder: 3 },
  ];
  for (const tier of defaults) {
    await db.insert(sponsorTiers).values({
      id: nanoid(),
      orgId,
      ...tier,
    });
  }
}
