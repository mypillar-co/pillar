import { db } from "@/lib/db";
import { vendors, eventVendors, contacts } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { nanoid } from "nanoid";

export async function getVendors(orgId: string) {
  return db.query.vendors.findMany({
    where: eq(vendors.orgId, orgId),
    with: { contact: true },
  });
}

export async function getVendor(orgId: string, vendorId: string) {
  return db.query.vendors.findFirst({
    where: and(eq(vendors.id, vendorId), eq(vendors.orgId, orgId)),
    with: {
      contact: true,
      eventVendors: { with: { event: true } },
    },
  });
}

export async function createVendor(orgId: string, data: {
  name: string;
  vendorType?: string;
  email?: string;
  phone?: string;
  contactName?: string;
  notes?: string;
}) {
  const vendorId = nanoid();

  // Create or find contact
  let contactId: string | undefined;
  if (data.contactName || data.email) {
    const cId = nanoid();
    const nameParts = (data.contactName || "").split(" ");
    await db.insert(contacts).values({
      id: cId,
      orgId,
      firstName: nameParts[0] || "Unknown",
      lastName: nameParts.slice(1).join(" ") || undefined,
      email: data.email,
      phone: data.phone,
      contactType: "vendor_rep",
    });
    contactId = cId;
  }

  await db.insert(vendors).values({
    id: vendorId,
    orgId,
    name: data.name,
    vendorType: data.vendorType,
    email: data.email,
    phone: data.phone,
    contactId,
    notes: data.notes,
    status: "active",
  });

  return { id: vendorId };
}

export async function assignVendorToEvent(orgId: string, data: {
  vendorId: string;
  eventId: string;
  boothNumber?: string;
  boothLocation?: string;
  feeAmount?: number;
}) {
  const id = nanoid();
  await db.insert(eventVendors).values({
    id,
    orgId,
    ...data,
    status: "pending",
    feeStatus: "pending",
  });
  return { id };
}

export async function updateEventVendor(orgId: string, eventVendorId: string, data: Partial<typeof eventVendors.$inferInsert>) {
  await db.update(eventVendors)
    .set({ ...data, updatedAt: new Date().toISOString() })
    .where(and(eq(eventVendors.id, eventVendorId), eq(eventVendors.orgId, orgId)));
}

export async function getEventVendors(orgId: string, eventId: string) {
  return db.query.eventVendors.findMany({
    where: and(eq(eventVendors.eventId, eventId), eq(eventVendors.orgId, orgId)),
    with: { vendor: true },
  });
}

export async function getPendingVendors(orgId: string, eventId?: string) {
  const conditions = [eq(eventVendors.orgId, orgId), eq(eventVendors.status, "pending")];
  if (eventId) conditions.push(eq(eventVendors.eventId, eventId));
  return db.query.eventVendors.findMany({
    where: and(...conditions),
    with: { vendor: true, event: true },
  });
}

export async function approveVendor(orgId: string, eventVendorId: string) {
  await updateEventVendor(orgId, eventVendorId, { status: "confirmed" });
}

export async function rejectVendor(orgId: string, eventVendorId: string) {
  await updateEventVendor(orgId, eventVendorId, { status: "declined" });
}
