import { db } from "@/lib/db";
import { payments } from "@/db/schema";
import { eq, and, desc, sql } from "drizzle-orm";
import { nanoid } from "nanoid";

export async function getPayments(orgId: string, filters?: {
  eventId?: string;
  paymentType?: string;
  status?: string;
  paymentCategory?: string;
}) {
  const conditions = [eq(payments.orgId, orgId)];
  if (filters?.eventId) conditions.push(eq(payments.eventId, filters.eventId));
  if (filters?.paymentType) conditions.push(eq(payments.paymentType, filters.paymentType));
  if (filters?.status) conditions.push(eq(payments.status, filters.status));
  if (filters?.paymentCategory) conditions.push(eq(payments.paymentCategory, filters.paymentCategory));

  return db.query.payments.findMany({
    where: and(...conditions),
    orderBy: [desc(payments.createdAt)],
  });
}

export async function createPayment(orgId: string, data: {
  description: string;
  amount: number;
  paymentType: "income" | "expense";
  paymentCategory?: string;
  paymentMethod?: string;
  status?: string;
  eventId?: string;
  eventVendorId?: string;
  eventSponsorId?: string;
  registrationId?: string;
  dueDate?: string;
  paidDate?: string;
  referenceNumber?: string;
  externalId?: string;
  notes?: string;
}) {
  const id = nanoid();
  await db.insert(payments).values({
    id,
    orgId,
    ...data,
    status: data.status || "pending",
  });
  return { id };
}

export async function updatePayment(orgId: string, paymentId: string, data: Partial<typeof payments.$inferInsert>) {
  await db.update(payments)
    .set({ ...data, updatedAt: new Date().toISOString() })
    .where(and(eq(payments.id, paymentId), eq(payments.orgId, orgId)));
}

export async function markPaymentReceived(orgId: string, paymentId: string) {
  await updatePayment(orgId, paymentId, {
    status: "received",
    paidDate: new Date().toISOString(),
  });
}

export async function getPaymentSummary(orgId: string, eventId?: string) {
  const allPayments = await getPayments(orgId, { eventId });

  const income = allPayments
    .filter(p => p.paymentType === "income")
    .reduce((sum, p) => sum + p.amount, 0);

  const expenses = allPayments
    .filter(p => p.paymentType === "expense")
    .reduce((sum, p) => sum + p.amount, 0);

  const received = allPayments
    .filter(p => p.status === "received")
    .reduce((sum, p) => sum + p.amount, 0);

  const pending = allPayments
    .filter(p => p.status === "pending")
    .reduce((sum, p) => sum + p.amount, 0);

  const overdue = allPayments
    .filter(p => p.status === "overdue")
    .reduce((sum, p) => sum + p.amount, 0);

  const byCategory = allPayments.reduce((acc, p) => {
    const cat = p.paymentCategory || "other";
    acc[cat] = (acc[cat] || 0) + p.amount;
    return acc;
  }, {} as Record<string, number>);

  return {
    totalIncome: income,
    totalExpenses: expenses,
    totalReceived: received,
    totalPending: pending,
    totalOverdue: overdue,
    netRevenue: income - expenses,
    byCategory,
    count: allPayments.length,
  };
}
