import { db } from "@/lib/db";
import { sites, sitePages, siteBlocks, siteNavItems } from "@/db/schema";
import { eq, and, asc } from "drizzle-orm";
import { nanoid } from "nanoid";

export async function getSite(orgId: string) {
  return db.query.sites.findFirst({
    where: eq(sites.orgId, orgId),
    with: {
      pages: {
        orderBy: [asc(sitePages.sortOrder)],
        with: {
          blocks: {
            orderBy: [asc(siteBlocks.sortOrder)],
          },
        },
      },
      navItems: {
        orderBy: [asc(siteNavItems.sortOrder)],
      },
    },
  });
}

export async function getSiteBySubdomain(subdomain: string) {
  return db.query.sites.findFirst({
    where: eq(sites.subdomain, subdomain),
    with: {
      pages: {
        orderBy: [asc(sitePages.sortOrder)],
        with: {
          blocks: {
            orderBy: [asc(siteBlocks.sortOrder)],
          },
        },
      },
      navItems: {
        orderBy: [asc(siteNavItems.sortOrder)],
      },
    },
  });
}

export async function getPage(orgId: string, pageSlug: string) {
  const site = await getSite(orgId);
  if (!site) return null;
  return site.pages.find(p => p.slug === pageSlug) || null;
}

export async function createSite(orgId: string, data: {
  subdomain: string;
  theme?: typeof sites.$inferInsert["theme"];
  metaTitle?: string;
  metaDescription?: string;
}) {
  const id = nanoid();
  await db.insert(sites).values({
    id,
    orgId,
    subdomain: data.subdomain,
    theme: data.theme || {
      primaryColor: "#2563eb",
      secondaryColor: "#1e40af",
      accentColor: "#f59e0b",
      fontHeading: "Inter",
      fontBody: "Inter",
    },
    metaTitle: data.metaTitle,
    metaDescription: data.metaDescription,
    status: "draft",
  });
  return { id };
}

export async function createPage(orgId: string, siteId: string, data: {
  title: string;
  slug: string;
  pageType: string;
  sortOrder?: number;
}) {
  const id = nanoid();
  await db.insert(sitePages).values({
    id,
    orgId,
    siteId,
    ...data,
    isPublished: true,
  });
  return { id };
}

export async function createBlock(orgId: string, pageId: string, data: {
  blockType: string;
  content: Record<string, unknown>;
  sortOrder?: number;
  settings?: Record<string, unknown>;
}) {
  const id = nanoid();
  await db.insert(siteBlocks).values({
    id,
    orgId,
    pageId,
    ...data,
    isVisible: true,
  });
  return { id };
}

export async function updateBlock(orgId: string, blockId: string, data: Partial<typeof siteBlocks.$inferInsert>) {
  await db.update(siteBlocks)
    .set({ ...data, updatedAt: new Date().toISOString() })
    .where(and(eq(siteBlocks.id, blockId), eq(siteBlocks.orgId, orgId)));
}

export async function deleteBlock(orgId: string, blockId: string) {
  await db.delete(siteBlocks)
    .where(and(eq(siteBlocks.id, blockId), eq(siteBlocks.orgId, orgId)));
}

export async function publishSite(orgId: string) {
  const site = await getSite(orgId);
  if (!site) throw new Error("No site found");
  await db.update(sites)
    .set({ status: "published", publishedAt: new Date().toISOString() })
    .where(eq(sites.orgId, orgId));
}

export async function createNavItem(orgId: string, siteId: string, data: {
  label: string;
  url?: string;
  pageId?: string;
  sortOrder?: number;
}) {
  const id = nanoid();
  await db.insert(siteNavItems).values({
    id,
    orgId,
    siteId,
    ...data,
    isVisible: true,
  });
  return { id };
}

// Scaffold a default site for a new org
export async function scaffoldDefaultSite(orgId: string, orgName: string, orgSlug: string) {
  // Create the site
  const site = await createSite(orgId, {
    subdomain: orgSlug,
    metaTitle: orgName,
    metaDescription: `Welcome to ${orgName}`,
  });

  // Create default pages
  const homePage = await createPage(orgId, site.id, {
    title: "Home",
    slug: "home",
    pageType: "home",
    sortOrder: 0,
  });

  const eventsPage = await createPage(orgId, site.id, {
    title: "Events",
    slug: "events",
    pageType: "events",
    sortOrder: 1,
  });

  const sponsorsPage = await createPage(orgId, site.id, {
    title: "Sponsors",
    slug: "sponsors",
    pageType: "sponsors",
    sortOrder: 2,
  });

  const contactPage = await createPage(orgId, site.id, {
    title: "Contact",
    slug: "contact",
    pageType: "contact",
    sortOrder: 3,
  });

  // Add default blocks to home page
  await createBlock(orgId, homePage.id, {
    blockType: "hero",
    content: {
      heading: `Welcome to ${orgName}`,
      subheading: "Building community, one event at a time.",
      backgroundImage: null,
      ctaText: "View Events",
      ctaUrl: "/events",
    },
    sortOrder: 0,
  });

  await createBlock(orgId, homePage.id, {
    blockType: "text",
    content: {
      body: `${orgName} is dedicated to strengthening our community through events, partnerships, and shared experiences. Join us in making our community a better place.`,
    },
    sortOrder: 1,
  });

  await createBlock(orgId, homePage.id, {
    blockType: "events_list",
    content: {
      display: "upcoming",
      limit: 3,
      layout: "cards",
    },
    sortOrder: 2,
  });

  // Add blocks to events page
  await createBlock(orgId, eventsPage.id, {
    blockType: "hero",
    content: {
      heading: "Our Events",
      subheading: "See what's coming up in the community.",
    },
    sortOrder: 0,
  });

  await createBlock(orgId, eventsPage.id, {
    blockType: "events_list",
    content: {
      display: "upcoming",
      limit: 20,
      layout: "cards",
    },
    sortOrder: 1,
  });

  // Add blocks to sponsors page
  await createBlock(orgId, sponsorsPage.id, {
    blockType: "hero",
    content: {
      heading: "Our Sponsors",
      subheading: "Thank you to our generous sponsors who make our events possible.",
    },
    sortOrder: 0,
  });

  await createBlock(orgId, sponsorsPage.id, {
    blockType: "sponsors_grid",
    content: {
      tiers: "all",
      layout: "grid",
    },
    sortOrder: 1,
  });

  // Add blocks to contact page
  await createBlock(orgId, contactPage.id, {
    blockType: "hero",
    content: {
      heading: "Contact Us",
      subheading: "We'd love to hear from you.",
    },
    sortOrder: 0,
  });

  await createBlock(orgId, contactPage.id, {
    blockType: "contact_form",
    content: {
      fields: ["name", "email", "message"],
      successMessage: "Thank you for reaching out! We'll get back to you soon.",
    },
    sortOrder: 1,
  });

  // Create nav items
  await createNavItem(orgId, site.id, { label: "Home", pageId: homePage.id, sortOrder: 0 });
  await createNavItem(orgId, site.id, { label: "Events", pageId: eventsPage.id, sortOrder: 1 });
  await createNavItem(orgId, site.id, { label: "Sponsors", pageId: sponsorsPage.id, sortOrder: 2 });
  await createNavItem(orgId, site.id, { label: "Contact", pageId: contactPage.id, sortOrder: 3 });

  return site;
}
