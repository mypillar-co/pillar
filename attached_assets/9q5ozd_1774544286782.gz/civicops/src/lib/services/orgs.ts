import { db } from "@/lib/db";
import { organizations, orgMemberships, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { nanoid } from "nanoid";
import { slugify } from "@/lib/utils";

export async function createOrganization(data: {
  name: string;
  orgType?: string;
  userId: string;
}) {
  const orgId = nanoid();
  const slug = slugify(data.name);

  await db.insert(organizations).values({
    id: orgId,
    name: data.name,
    slug,
    orgType: data.orgType || "other",
    status: "active",
    plan: "free",
  });

  // Make the creator an admin
  await db.insert(orgMemberships).values({
    id: nanoid(),
    orgId,
    userId: data.userId,
    role: "admin",
  });

  return { id: orgId, slug };
}

export async function getOrganization(orgId: string) {
  return db.query.organizations.findFirst({
    where: eq(organizations.id, orgId),
  });
}

export async function getOrganizationBySlug(slug: string) {
  return db.query.organizations.findFirst({
    where: eq(organizations.slug, slug),
  });
}

export async function getUserOrganizations(userId: string) {
  const memberships = await db.query.orgMemberships.findMany({
    where: eq(orgMemberships.userId, userId),
    with: {
      organization: true,
    },
  });
  return memberships.map((m) => ({
    ...m.organization,
    role: m.role,
  }));
}

export async function getUserRole(orgId: string, userId: string) {
  const membership = await db.query.orgMemberships.findFirst({
    where: and(
      eq(orgMemberships.orgId, orgId),
      eq(orgMemberships.userId, userId)
    ),
  });
  return membership?.role || null;
}
