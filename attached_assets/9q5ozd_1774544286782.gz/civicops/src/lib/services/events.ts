import { db } from "@/lib/db";
import { events } from "@/db/schema";
import { eq, and, desc, asc } from "drizzle-orm";
import { nanoid } from "nanoid";
import { slugify } from "@/lib/utils";

export async function getEvents(orgId: string, options?: { includeInactive?: boolean }) {
  const conditions = [eq(events.orgId, orgId)];
  if (!options?.includeInactive) {
    conditions.push(eq(events.isActive, true));
  }
  return db.query.events.findMany({
    where: and(...conditions),
    orderBy: [asc(events.startDate)],
  });
}

export async function getEvent(orgId: string, eventId: string) {
  return db.query.events.findFirst({
    where: and(eq(events.id, eventId), eq(events.orgId, orgId)),
    with: {
      eventVendors: { with: { vendor: true } },
      eventSponsors: { with: { sponsor: true } },
      registrations: { with: { contact: true } },
    },
  });
}

export async function getEventBySlug(orgId: string, slug: string) {
  return db.query.events.findFirst({
    where: and(eq(events.slug, slug), eq(events.orgId, orgId)),
  });
}

export async function createEvent(orgId: string, data: {
  name: string;
  description?: string;
  eventType?: string;
  startDate?: string;
  endDate?: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  maxCapacity?: number;
  isTicketed?: boolean;
  ticketPrice?: number;
  ticketCapacity?: number;
}) {
  const id = nanoid();
  const slug = slugify(data.name);

  await db.insert(events).values({
    id,
    orgId,
    slug,
    ...data,
    status: "draft",
    isActive: true,
  });

  return { id, slug };
}

export async function updateEvent(orgId: string, eventId: string, data: Partial<typeof events.$inferInsert>) {
  await db.update(events)
    .set({ ...data, updatedAt: new Date().toISOString() })
    .where(and(eq(events.id, eventId), eq(events.orgId, orgId)));
}

export async function deleteEvent(orgId: string, eventId: string) {
  await db.delete(events)
    .where(and(eq(events.id, eventId), eq(events.orgId, orgId)));
}

export async function getEventStats(orgId: string, eventId: string) {
  const event = await getEvent(orgId, eventId);
  if (!event) return null;

  const vendorCount = event.eventVendors?.length || 0;
  const confirmedVendors = event.eventVendors?.filter(ev => ev.status === "confirmed").length || 0;
  const sponsorCount = event.eventSponsors?.length || 0;
  const confirmedSponsors = event.eventSponsors?.filter(es => es.status === "confirmed").length || 0;
  const registrationCount = event.registrations?.length || 0;
  const totalSponsorRevenue = event.eventSponsors
    ?.reduce((sum, es) => sum + (es.amountReceived || 0), 0) || 0;
  const totalVendorRevenue = event.eventVendors
    ?.filter(ev => ev.feeStatus === "paid")
    .reduce((sum, ev) => sum + (ev.feeAmount || 0), 0) || 0;

  return {
    vendorCount,
    confirmedVendors,
    sponsorCount,
    confirmedSponsors,
    registrationCount,
    totalSponsorRevenue,
    totalVendorRevenue,
    totalRevenue: totalSponsorRevenue + totalVendorRevenue,
  };
}
