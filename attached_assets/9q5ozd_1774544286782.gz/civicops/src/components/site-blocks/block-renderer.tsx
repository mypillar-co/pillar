type Block = {
  id: string;
  blockType: string;
  content: Record<string, any>;
  settings?: Record<string, any> | null;
};

type Event = {
  id: string;
  name: string;
  slug: string;
  description?: string | null;
  eventType?: string | null;
  startDate?: string | null;
  startTime?: string | null;
  location?: string | null;
  imageUrl?: string | null;
  isTicketed?: boolean | null;
  ticketPrice?: number | null;
  featured?: boolean | null;
};

type EventSponsor = {
  id: string;
  tier?: string | null;
  sponsor: {
    id: string;
    name: string;
    logoUrl?: string | null;
    website?: string | null;
  };
  event?: {
    id: string;
    name: string;
  } | null;
};

export function BlockRenderer({
  block,
  events,
  eventSponsors,
  theme,
  orgSlug,
}: {
  block: Block;
  events: Event[];
  eventSponsors: EventSponsor[];
  theme: Record<string, string>;
  orgSlug: string;
}) {
  const primaryColor = theme.primaryColor || "#2563eb";
  const accentColor = theme.accentColor || "#f59e0b";

  switch (block.blockType) {
    case "hero":
      return <HeroBlock content={block.content} primaryColor={primaryColor} orgSlug={orgSlug} />;
    case "text":
      return <TextBlock content={block.content} />;
    case "events_list":
      return <EventsListBlock content={block.content} events={events} orgSlug={orgSlug} primaryColor={primaryColor} />;
    case "sponsors_grid":
      return <SponsorsGridBlock content={block.content} eventSponsors={eventSponsors} />;
    case "contact_form":
      return <ContactFormBlock content={block.content} primaryColor={primaryColor} />;
    case "cta_banner":
      return <CtaBannerBlock content={block.content} primaryColor={primaryColor} />;
    case "divider":
      return <div className="py-8"><hr className="border-gray-200" /></div>;
    default:
      return (
        <div className="py-8 px-4 text-center text-gray-400 text-sm">
          Block type "{block.blockType}" — rendering coming soon
        </div>
      );
  }
}

function HeroBlock({ content, primaryColor, orgSlug }: { content: Record<string, any>; primaryColor: string; orgSlug: string }) {
  return (
    <section
      className="relative py-24 px-4"
      style={{
        background: content.background_image
          ? `url(${content.background_image}) center/cover`
          : `linear-gradient(135deg, ${primaryColor}15 0%, ${primaryColor}05 100%)`,
      }}
    >
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4" style={{ color: content.background_image ? "white" : undefined }}>
          {content.heading || "Welcome"}
        </h1>
        {content.subheading && (
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            {content.subheading}
          </p>
        )}
        {content.ctaText && (
          <a
            href={content.ctaUrl?.startsWith("/") ? `/o/${orgSlug}${content.ctaUrl}` : content.ctaUrl || "#"}
            className="inline-block px-6 py-3 rounded-lg text-white font-medium hover:opacity-90 transition-opacity"
            style={{ backgroundColor: primaryColor }}
          >
            {content.ctaText}
          </a>
        )}
      </div>
    </section>
  );
}

function TextBlock({ content }: { content: Record<string, any> }) {
  return (
    <section className="py-12 px-4">
      <div className="max-w-3xl mx-auto prose prose-gray">
        <p>{content.body}</p>
      </div>
    </section>
  );
}

function EventsListBlock({ content, events, orgSlug, primaryColor }: { content: Record<string, any>; events: Event[]; orgSlug: string; primaryColor: string }) {
  const display = content.display || "upcoming";
  const limit = content.limit || 10;
  const layout = content.layout || "cards";
  const now = new Date().toISOString().split("T")[0];

  let filtered = events;
  if (display === "upcoming") {
    filtered = events.filter(e => !e.startDate || e.startDate >= now);
  } else if (display === "past") {
    filtered = events.filter(e => e.startDate && e.startDate < now);
  }
  filtered = filtered.slice(0, limit);

  if (filtered.length === 0) {
    return (
      <section className="py-12 px-4">
        <div className="max-w-5xl mx-auto text-center text-gray-500">
          No upcoming events — check back soon!
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 px-4">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold mb-8 text-center">
          {display === "upcoming" ? "Upcoming Events" : display === "past" ? "Past Events" : "Events"}
        </h2>
        <div className={`grid gap-6 ${layout === "cards" ? "md:grid-cols-2 lg:grid-cols-3" : ""}`}>
          {filtered.map((event) => (
            <div key={event.id} className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow">
              {event.imageUrl && (
                <img src={event.imageUrl} alt={event.name} className="w-full h-48 object-cover" />
              )}
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  {event.eventType && (
                    <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">
                      {event.eventType}
                    </span>
                  )}
                  {event.featured && (
                    <span className="text-xs font-medium px-2 py-0.5 rounded-full text-white" style={{ backgroundColor: primaryColor }}>
                      Featured
                    </span>
                  )}
                </div>
                <h3 className="font-semibold text-lg mb-2">{event.name}</h3>
                {event.startDate && (
                  <p className="text-sm text-gray-500 mb-1">
                    📅 {new Date(event.startDate + "T00:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
                    {event.startTime && ` at ${event.startTime}`}
                  </p>
                )}
                {event.location && (
                  <p className="text-sm text-gray-500 mb-3">📍 {event.location}</p>
                )}
                {event.description && (
                  <p className="text-sm text-gray-600 line-clamp-2">{event.description}</p>
                )}
                {event.isTicketed && event.ticketPrice && (
                  <p className="text-sm font-medium mt-3" style={{ color: primaryColor }}>
                    🎟️ Tickets: ${event.ticketPrice}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SponsorsGridBlock({ content, eventSponsors }: { content: Record<string, any>; eventSponsors: EventSponsor[] }) {
  const tierFilter = content.tiers || "all";

  let filtered = eventSponsors;
  if (tierFilter !== "all" && Array.isArray(tierFilter)) {
    filtered = eventSponsors.filter(es => tierFilter.includes(es.tier));
  }

  // Group by tier
  const byTier: Record<string, EventSponsor[]> = {};
  for (const es of filtered) {
    const tier = es.tier || "sponsor";
    if (!byTier[tier]) byTier[tier] = [];
    byTier[tier].push(es);
  }

  // Deduplicate sponsors (same sponsor might sponsor multiple events)
  const tierOrder = ["presenting", "gold", "silver", "bronze", "supporting", "in-kind", "sponsor"];

  const sortedTiers = Object.entries(byTier).sort(([a], [b]) => {
    return tierOrder.indexOf(a) - tierOrder.indexOf(b);
  });

  if (sortedTiers.length === 0) {
    return (
      <section className="py-12 px-4">
        <div className="max-w-5xl mx-auto text-center text-gray-500">
          Sponsor information coming soon.
        </div>
      </section>
    );
  }

  return (
    <section className="py-12 px-4 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <h2 className="text-2xl font-bold mb-8 text-center">Our Sponsors</h2>
        {sortedTiers.map(([tier, sponsors]) => {
          // Deduplicate by sponsor name
          const seen = new Set<string>();
          const unique = sponsors.filter(es => {
            if (seen.has(es.sponsor.name)) return false;
            seen.add(es.sponsor.name);
            return true;
          });

          const sizeClass = tier === "presenting"
            ? "h-20 md:h-24"
            : tier === "gold"
            ? "h-14 md:h-16"
            : "h-10 md:h-12";

          return (
            <div key={tier} className="mb-10">
              <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider text-center mb-4">
                {tier} Sponsors
              </h3>
              <div className="flex flex-wrap justify-center items-center gap-8">
                {unique.map((es) => (
                  <div key={es.id} className="flex items-center">
                    {es.sponsor.logoUrl ? (
                      <a href={es.sponsor.website || "#"} target="_blank" rel="noopener noreferrer">
                        <img
                          src={es.sponsor.logoUrl}
                          alt={es.sponsor.name}
                          className={`${sizeClass} object-contain`}
                        />
                      </a>
                    ) : (
                      <span className="text-sm text-gray-600 font-medium">{es.sponsor.name}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

function ContactFormBlock({ content, primaryColor }: { content: Record<string, any>; primaryColor: string }) {
  return (
    <section className="py-12 px-4">
      <div className="max-w-lg mx-auto">
        <form className="space-y-4">
          {(content.fields || ["name", "email", "message"]).map((field: string) => (
            <div key={field}>
              <label className="block text-sm font-medium text-gray-700 mb-1 capitalize">{field}</label>
              {field === "message" ? (
                <textarea
                  name={field}
                  rows={4}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2"
                  style={{ "--tw-ring-color": primaryColor } as React.CSSProperties}
                  placeholder={`Your ${field}...`}
                />
              ) : (
                <input
                  type={field === "email" ? "email" : "text"}
                  name={field}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2"
                  style={{ "--tw-ring-color": primaryColor } as React.CSSProperties}
                  placeholder={`Your ${field}...`}
                />
              )}
            </div>
          ))}
          <button
            type="submit"
            className="w-full py-2.5 rounded-lg text-white font-medium hover:opacity-90 transition-opacity"
            style={{ backgroundColor: primaryColor }}
          >
            Send Message
          </button>
        </form>
      </div>
    </section>
  );
}

function CtaBannerBlock({ content, primaryColor }: { content: Record<string, any>; primaryColor: string }) {
  return (
    <section className="py-16 px-4" style={{ backgroundColor: `${primaryColor}10` }}>
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-2xl font-bold mb-3">{content.heading}</h2>
        {content.body && <p className="text-gray-600 mb-6">{content.body}</p>}
        {content.button_text && (
          <a
            href={content.button_url || "#"}
            className="inline-block px-6 py-3 rounded-lg text-white font-medium"
            style={{ backgroundColor: primaryColor }}
          >
            {content.button_text}
          </a>
        )}
      </div>
    </section>
  );
}
