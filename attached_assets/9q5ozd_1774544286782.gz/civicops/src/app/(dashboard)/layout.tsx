"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";

type Org = { id: string; name: string; slug: string; orgType: string; plan: string; role: string };
type User = { id: string; email: string; firstName: string; lastName: string; organizations: Org[] };

const navItems = [
  { label: "Overview", href: "/dashboard", icon: "📊" },
  { label: "Events", href: "/dashboard/events", icon: "🎪" },
  { label: "Vendors", href: "/dashboard/vendors", icon: "🏪" },
  { label: "Sponsors", href: "/dashboard/sponsors", icon: "🤝" },
  { label: "Payments", href: "/dashboard/payments", icon: "💰" },
  { label: "Contacts", href: "/dashboard/contacts", icon: "👤" },
  { label: "Site Builder", href: "/dashboard/site-builder", icon: "🤖" },
  { label: "Settings", href: "/dashboard/settings", icon: "⚙️" },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [currentOrg, setCurrentOrg] = useState<Org | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) { router.push("/login"); return; }
    const u = JSON.parse(stored);
    setUser(u);
    if (u.organizations?.length > 0) setCurrentOrg(u.organizations[0]);
  }, []);

  function handleLogout() {
    localStorage.removeItem("civicops_user");
    localStorage.removeItem("civicops_token");
    router.push("/login");
  }

  if (!user) return <div className="min-h-screen flex items-center justify-center"><p>Loading...</p></div>;

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? "w-56" : "w-0 overflow-hidden"} bg-white border-r flex-shrink-0 transition-all duration-200`}>
        <div className="p-4 border-b">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xs">CO</span>
            </div>
            <span className="font-bold">CivicOps</span>
          </Link>
        </div>
        {currentOrg && (
          <div className="p-3 border-b">
            <select
              value={currentOrg.id}
              onChange={(e) => {
                const org = user.organizations.find(o => o.id === e.target.value);
                if (org) setCurrentOrg(org);
              }}
              className="w-full text-sm font-medium border rounded-lg px-2 py-1.5 bg-gray-50"
            >
              {user.organizations.map((org) => (
                <option key={org.id} value={org.id}>{org.name}</option>
              ))}
            </select>
          </div>
        )}
        <nav className="p-2">
          {navItems.map((item) => {
            const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm mb-0.5 transition-colors ${active ? "bg-blue-50 text-blue-700 font-medium" : "text-gray-600 hover:bg-gray-100"}`}
              >
                <span>{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white border-b sticky top-0 z-50">
          <div className="px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-500 hover:text-gray-700">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
              </button>
              {currentOrg && (
                <a href={`/o/${currentOrg.slug}`} target="_blank" className="text-xs text-blue-600 hover:underline">
                  View Public Site →
                </a>
              )}
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-500">{user.email}</span>
              <button onClick={handleLogout} className="text-sm text-gray-500 hover:text-gray-700">Logout</button>
            </div>
          </div>
        </header>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  );
}
