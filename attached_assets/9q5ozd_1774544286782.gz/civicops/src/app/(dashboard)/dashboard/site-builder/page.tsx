"use client";

import { useState } from "react";

type Message = { role: "user" | "assistant"; content: string };

export default function SiteBuilderPage() {
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: "Hey! I'm your AI site builder. Tell me what you'd like to change about your website — colors, layout, content, new pages — and I'll make it happen.\n\n⚠️ AI integration is coming soon. For now, this is a preview of the chat interface." },
  ]);
  const [input, setInput] = useState("");

  function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", content: input };
    const botMsg: Message = { role: "assistant", content: "Thanks for the input! AI-powered site editing is coming soon. For now, you can manage your site pages and blocks through the settings page." };
    setMessages([...messages, userMsg, botMsg]);
    setInput("");
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <h1 className="text-2xl font-bold mb-4">AI Site Builder</h1>
      <div className="flex-1 bg-white rounded-lg border flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-md px-4 py-2.5 rounded-2xl text-sm whitespace-pre-wrap ${
                m.role === "user" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-800"
              }`}>{m.content}</div>
            </div>
          ))}
        </div>
        <form onSubmit={handleSend} className="border-t p-3 flex gap-2">
          <input type="text" value={input} onChange={e => setInput(e.target.value)}
            placeholder="Tell me what to change on your site..."
            className="flex-1 border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">Send</button>
        </form>
      </div>
    </div>
  );
}
