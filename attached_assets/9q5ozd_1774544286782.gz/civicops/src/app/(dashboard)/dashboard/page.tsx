"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function DashboardPage() {
  const [events, setEvents] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [orgSlug, setOrgSlug] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const user = JSON.parse(stored);
    const org = user.organizations?.[0];
    if (!org) return;
    setOrgSlug(org.slug);
    Promise.all([
      fetch(`/api/orgs/${org.id}/events`).then(r => r.json()),
      fetch(`/api/orgs/${org.id}/stats`).then(r => r.json()),
    ]).then(([ev, st]) => { setEvents(ev); setStats(st); });
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard label="Active Events" value={stats.activeEvents || 0} icon="🎪" />
          <StatCard label="Total Vendors" value={stats.totalVendors || 0} icon="🏪" />
          <StatCard label="Total Sponsors" value={stats.totalSponsors || 0} icon="🤝" />
          <StatCard label="Revenue" value={`$${(stats.totalRevenue || 0).toLocaleString()}`} icon="💰" />
        </div>
      )}

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <QuickAction title="Create Event" desc="Add a new event" icon="📅" href="/dashboard/events/new" />
        <QuickAction title="AI Site Builder" desc="Chat with AI to update your site" icon="🤖" href="/dashboard/site-builder" />
        <QuickAction title="View Public Site" desc={orgSlug ? `${orgSlug}.civicops.com` : ""} icon="🌐" href={orgSlug ? `/o/${orgSlug}` : "#"} external />
      </div>

      <div className="bg-white rounded-lg border">
        <div className="px-6 py-4 border-b flex items-center justify-between">
          <h2 className="font-semibold text-lg">Upcoming Events</h2>
          <Link href="/dashboard/events" className="text-sm text-blue-600 hover:underline">View all →</Link>
        </div>
        <div className="divide-y">
          {events.length === 0 ? (
            <div className="p-6 text-center text-gray-500">No events yet.</div>
          ) : events.slice(0, 5).map((event: any) => (
            <div key={event.id} className="px-6 py-4 flex items-center justify-between hover:bg-gray-50">
              <div>
                <Link href={`/dashboard/events/${event.id}`} className="font-medium hover:text-blue-600">{event.name}</Link>
                <div className="flex items-center gap-3 mt-1">
                  {event.startDate && <span className="text-xs text-gray-500">📅 {new Date(event.startDate + "T00:00:00").toLocaleDateString()}</span>}
                  {event.location && <span className="text-xs text-gray-500">📍 {event.location}</span>}
                  <span className={`text-xs px-2 py-0.5 rounded-full ${event.status === "published" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{event.status}</span>
                </div>
              </div>
              {event.featured && <span className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">Featured</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon }: { label: string; value: string | number; icon: string }) {
  return (
    <div className="bg-white rounded-lg border p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm text-gray-500">{label}</span>
        <span className="text-xl">{icon}</span>
      </div>
      <p className="text-2xl font-bold">{value}</p>
    </div>
  );
}

function QuickAction({ title, desc, icon, href, external }: { title: string; desc: string; icon: string; href: string; external?: boolean }) {
  const props = external ? { target: "_blank" as const, rel: "noopener noreferrer" } : {};
  return (
    <a href={href} {...props} className="bg-white rounded-lg border p-5 hover:border-blue-300 hover:shadow-sm transition-all block">
      <span className="text-2xl mb-2 block">{icon}</span>
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-gray-500">{desc}</p>
    </a>
  );
}
