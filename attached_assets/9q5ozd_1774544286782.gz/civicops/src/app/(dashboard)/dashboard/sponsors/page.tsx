"use client";

import { useEffect, useState } from "react";

export default function SponsorsPage() {
  const [sponsors, setSponsors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const orgId = JSON.parse(stored).organizations?.[0]?.id;
    if (!orgId) return;
    fetch(`/api/orgs/${orgId}/sponsors`).then(r => r.json()).then(setSponsors).finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Loading sponsors...</p>;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Sponsors</h1>
      <div className="bg-white rounded-lg border">
        {sponsors.length === 0 ? (
          <div className="p-8 text-center text-gray-500">No sponsors yet.</div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b text-left text-sm text-gray-500">
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Website</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {sponsors.map((s: any) => (
                <tr key={s.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {s.logoUrl ? <img src={s.logoUrl} alt={s.name} className="h-8 w-auto" /> : null}
                      <span className="font-medium">{s.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{s.email || "—"}</td>
                  <td className="px-4 py-3 text-sm">
                    {s.website ? <a href={s.website} target="_blank" className="text-blue-600 hover:underline">{s.website}</a> : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${s.status === "active" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>{s.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
