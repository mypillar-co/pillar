"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";

export default function EventDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [event, setEvent] = useState<any>(null);
  const [vendors, setVendors] = useState<any[]>([]);
  const [sponsors, setSponsors] = useState<any[]>([]);
  const [tab, setTab] = useState("details");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<any>({});

  const orgId = (() => {
    if (typeof window === "undefined") return null;
    const s = localStorage.getItem("civicops_user");
    return s ? JSON.parse(s).organizations?.[0]?.id : null;
  })();

  useEffect(() => {
    if (!orgId) return;
    Promise.all([
      fetch(`/api/orgs/${orgId}/events`).then(r => r.json()),
      fetch(`/api/orgs/${orgId}/vendors`).then(r => r.json()),
      fetch(`/api/orgs/${orgId}/sponsors`).then(r => r.json()),
    ]).then(([evts, vends, spons]) => {
      const ev = evts.find((e: any) => e.id === id);
      if (ev) { setEvent(ev); setForm(ev); }
      setVendors(vends);
      setSponsors(spons);
      setLoading(false);
    });
  }, [orgId, id]);

  async function handleSave() {
    if (!orgId) return;
    setSaving(true);
    await fetch(`/api/orgs/${orgId}/events`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
  }

  if (loading) return <p>Loading...</p>;
  if (!event) return <div className="text-center py-12"><p className="text-gray-500">Event not found</p><Link href="/dashboard/events" className="text-blue-600 text-sm">← Back to events</Link></div>;

  const tabs = [
    { key: "details", label: "Details" },
    { key: "vendors", label: "Vendors" },
    { key: "sponsors", label: "Sponsors" },
  ];

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <Link href="/dashboard/events" className="text-gray-400 hover:text-gray-600">← Events</Link>
        <span className="text-gray-300">/</span>
        <h1 className="text-2xl font-bold">{event.name}</h1>
        <span className={`text-xs px-2 py-0.5 rounded-full ${event.status === "published" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>{event.status}</span>
      </div>

      <div className="flex gap-1 border-b mb-6">
        {tabs.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${tab === t.key ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "details" && (
        <div className="bg-white rounded-lg border p-6 max-w-2xl">
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Name", key: "name", type: "text" },
              { label: "Slug", key: "slug", type: "text" },
              { label: "Event Type", key: "eventType", type: "text" },
              { label: "Status", key: "status", type: "select", options: ["draft", "published", "active", "completed", "cancelled"] },
              { label: "Start Date", key: "startDate", type: "date" },
              { label: "End Date", key: "endDate", type: "date" },
              { label: "Start Time", key: "startTime", type: "text" },
              { label: "End Time", key: "endTime", type: "text" },
              { label: "Location", key: "location", type: "text" },
              { label: "Max Capacity", key: "maxCapacity", type: "number" },
            ].map(f => (
              <div key={f.key}>
                <label className="block text-sm font-medium text-gray-700 mb-1">{f.label}</label>
                {f.type === "select" ? (
                  <select value={form[f.key] || ""} onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                    className="w-full border rounded-lg px-3 py-2 text-sm">
                    {f.options!.map(o => <option key={o} value={o}>{o}</option>)}
                  </select>
                ) : (
                  <input type={f.type} value={form[f.key] || ""} onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                    className="w-full border rounded-lg px-3 py-2 text-sm" />
                )}
              </div>
            ))}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <textarea value={form.description || ""} onChange={e => setForm({ ...form, description: e.target.value })}
                rows={3} className="w-full border rounded-lg px-3 py-2 text-sm" />
            </div>
          </div>
          <div className="mt-4 flex gap-2">
            <button onClick={handleSave} disabled={saving} className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50">
              {saving ? "Saving..." : "Save Changes"}
            </button>
          </div>
        </div>
      )}

      {tab === "vendors" && (
        <div className="bg-white rounded-lg border">
          <div className="px-4 py-3 border-b"><h3 className="font-semibold">Event Vendors</h3></div>
          {vendors.length === 0 ? (
            <div className="p-6 text-center text-gray-500">No vendors assigned to this event yet.</div>
          ) : (
            <div className="divide-y">
              {vendors.map((v: any) => (
                <div key={v.id} className="px-4 py-3 flex items-center justify-between">
                  <div>
                    <span className="font-medium">{v.name}</span>
                    <span className="text-sm text-gray-500 ml-2">{v.vendorType}</span>
                  </div>
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{v.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === "sponsors" && (
        <div className="bg-white rounded-lg border">
          <div className="px-4 py-3 border-b"><h3 className="font-semibold">Event Sponsors</h3></div>
          {sponsors.length === 0 ? (
            <div className="p-6 text-center text-gray-500">No sponsors assigned to this event yet.</div>
          ) : (
            <div className="divide-y">
              {sponsors.map((s: any) => (
                <div key={s.id} className="px-4 py-3 flex items-center justify-between">
                  <div>
                    <span className="font-medium">{s.name}</span>
                    {s.website && <a href={s.website} target="_blank" className="text-xs text-blue-600 ml-2">↗</a>}
                  </div>
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{s.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
