"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function EventsPage() {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const user = JSON.parse(stored);
    const orgId = user.organizations?.[0]?.id;
    if (!orgId) return;
    fetch(`/api/orgs/${orgId}/events?includeInactive=1`)
      .then(r => r.json()).then(setEvents).finally(() => setLoading(false));
  }, []);

  if (loading) return <p>Loading events...</p>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Events</h1>
        <Link href="/dashboard/events/new" className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700">
          + New Event
        </Link>
      </div>
      <div className="bg-white rounded-lg border">
        {events.length === 0 ? (
          <div className="p-8 text-center text-gray-500">No events yet. Create your first one!</div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b text-left text-sm text-gray-500">
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Location</th>
                <th className="px-4 py-3 font-medium">Type</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {events.map((e: any) => (
                <tr key={e.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <Link href={`/dashboard/events/${e.id}`} className="font-medium text-blue-600 hover:underline">
                      {e.name}
                    </Link>
                    {e.featured ? <span className="ml-2 text-xs bg-yellow-100 text-yellow-700 px-1.5 py-0.5 rounded-full">Featured</span> : null}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {e.startDate ? new Date(e.startDate + "T00:00:00").toLocaleDateString() : "TBD"}
                    {e.startTime ? ` ${e.startTime}` : ""}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{e.location || "—"}</td>
                  <td className="px-4 py-3 text-sm text-gray-600 capitalize">{e.eventType || "—"}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      e.status === "published" ? "bg-green-100 text-green-700" :
                      e.status === "draft" ? "bg-yellow-100 text-yellow-700" :
                      e.status === "cancelled" ? "bg-red-100 text-red-700" :
                      "bg-gray-100 text-gray-600"
                    }`}>{e.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
