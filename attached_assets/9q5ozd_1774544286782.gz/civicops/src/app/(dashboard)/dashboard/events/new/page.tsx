"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewEventPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    name: "", slug: "", eventType: "festival", status: "draft",
    startDate: "", endDate: "", startTime: "", endTime: "",
    location: "", description: "", maxCapacity: "",
  });

  function slugify(s: string) { return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, ""); }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const orgId = JSON.parse(stored).organizations?.[0]?.id;
    if (!orgId) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/events`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, maxCapacity: form.maxCapacity ? Number(form.maxCapacity) : null }),
      });
      if (!res.ok) { setError("Failed to create event"); return; }
      router.push("/dashboard/events");
    } catch { setError("Something went wrong"); }
    finally { setSaving(false); }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Create Event</h1>
      <form onSubmit={handleSubmit} className="bg-white rounded-lg border p-6 max-w-2xl">
        {error && <div className="bg-red-50 text-red-600 text-sm px-3 py-2 rounded mb-4">{error}</div>}
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Event Name *</label>
            <input type="text" required value={form.name}
              onChange={e => setForm({ ...form, name: e.target.value, slug: slugify(e.target.value) })}
              className="w-full border rounded-lg px-3 py-2 text-sm" placeholder="Summer Street Market" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Slug</label>
            <input type="text" value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
            <select value={form.eventType} onChange={e => setForm({ ...form, eventType: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm">
              {["festival","market","mixer","fundraiser","meeting","dinner","other"].map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
            <input type="date" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
            <input type="date" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
            <input type="text" value={form.startTime} onChange={e => setForm({ ...form, startTime: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" placeholder="10:00" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
            <input type="text" value={form.endTime} onChange={e => setForm({ ...form, endTime: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" placeholder="16:00" />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <input type="text" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" placeholder="Main Street, Irwin PA" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Max Capacity</label>
            <input type="number" value={form.maxCapacity} onChange={e => setForm({ ...form, maxCapacity: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })}
              rows={3} className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
        </div>
        <div className="mt-4 flex gap-2">
          <button type="submit" disabled={saving} className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50">
            {saving ? "Creating..." : "Create Event"}
          </button>
          <button type="button" onClick={() => router.back()} className="border px-4 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50">Cancel</button>
        </div>
      </form>
    </div>
  );
}
