"use client";

import { useEffect, useState } from "react";

export default function ContactsPage() {
  const [contacts, setContacts] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const orgId = JSON.parse(stored).organizations?.[0]?.id;
    if (!orgId) return;
    // Contacts don't have a dedicated API yet — show empty state
    setLoading(false);
  }, []);

  if (loading) return <p>Loading contacts...</p>;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Contacts</h1>
      <div className="mb-4">
        <input type="text" placeholder="Search contacts..." value={search} onChange={e => setSearch(e.target.value)}
          className="border rounded-lg px-3 py-2 text-sm w-64" />
      </div>
      <div className="bg-white rounded-lg border">
        <div className="p-8 text-center text-gray-500">
          <p className="text-lg mb-2">📇</p>
          <p>Contact management coming soon.</p>
          <p className="text-sm mt-1">Contacts are auto-created when vendors and sponsors are added.</p>
        </div>
      </div>
    </div>
  );
}
