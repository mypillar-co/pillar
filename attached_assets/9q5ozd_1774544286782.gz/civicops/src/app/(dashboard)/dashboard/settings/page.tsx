"use client";

import { useEffect, useState } from "react";

export default function SettingsPage() {
  const [org, setOrg] = useState<any>(null);
  const [form, setForm] = useState({ name: "", orgType: "", plan: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const user = JSON.parse(stored);
    const o = user.organizations?.[0];
    if (o) { setOrg(o); setForm({ name: o.name, orgType: o.orgType || "", plan: o.plan || "free" }); }
  }, []);

  if (!org) return <p>Loading...</p>;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      <div className="bg-white rounded-lg border p-6 max-w-2xl">
        <h2 className="font-semibold mb-4">Organization</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Organization Name</label>
            <input type="text" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
            <select value={form.orgType} onChange={e => setForm({ ...form, orgType: e.target.value })}
              className="w-full border rounded-lg px-3 py-2 text-sm">
              {["chamber","downtown_assoc","nonprofit","lodge","festival_committee","other"].map(t =>
                <option key={t} value={t}>{t.replace(/_/g, " ")}</option>
              )}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Plan</label>
            <div className="flex items-center gap-2">
              <span className="text-sm bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full capitalize">{org.plan || "free"}</span>
              <span className="text-xs text-gray-500">Contact us to upgrade</span>
            </div>
          </div>
        </div>
        <div className="mt-6 pt-4 border-t">
          <button disabled={saving} className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50">
            {saving ? "Saving..." : "Save Settings"}
          </button>
        </div>
      </div>
      <div className="bg-white rounded-lg border p-6 max-w-2xl mt-6">
        <h2 className="font-semibold mb-4">Danger Zone</h2>
        <p className="text-sm text-gray-500 mb-3">Permanently delete this organization and all its data.</p>
        <button className="border border-red-300 text-red-600 px-4 py-2 rounded-lg text-sm hover:bg-red-50">Delete Organization</button>
      </div>
    </div>
  );
}
