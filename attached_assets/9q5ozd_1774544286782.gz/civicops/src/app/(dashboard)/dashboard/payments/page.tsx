"use client";

import { useEffect, useState } from "react";

export default function PaymentsPage() {
  const [payments, setPayments] = useState<any[]>([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("civicops_user");
    if (!stored) return;
    const orgId = JSON.parse(stored).organizations?.[0]?.id;
    if (!orgId) return;
    fetch(`/api/orgs/${orgId}/payments`).then(r => r.json()).then(setPayments).finally(() => setLoading(false));
  }, []);

  const filtered = filter === "all" ? payments :
    filter === "income" ? payments.filter(p => p.paymentType === "income") :
    filter === "expense" ? payments.filter(p => p.paymentType === "expense") :
    payments.filter(p => p.status === filter);

  const totalIncome = payments.filter(p => p.paymentType === "income" && p.status === "received").reduce((s, p) => s + p.amount, 0);
  const totalPending = payments.filter(p => p.status === "pending").reduce((s, p) => s + p.amount, 0);

  if (loading) return <p>Loading payments...</p>;

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Payments</h1>
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg border p-4">
          <p className="text-sm text-gray-500">Total Received</p>
          <p className="text-2xl font-bold text-green-600">${totalIncome.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg border p-4">
          <p className="text-sm text-gray-500">Pending</p>
          <p className="text-2xl font-bold text-yellow-600">${totalPending.toLocaleString()}</p>
        </div>
        <div className="bg-white rounded-lg border p-4">
          <p className="text-sm text-gray-500">Total Transactions</p>
          <p className="text-2xl font-bold">{payments.length}</p>
        </div>
      </div>
      <div className="flex gap-2 mb-4">
        {["all", "income", "expense", "pending", "received"].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-sm ${filter === f ? "bg-blue-600 text-white" : "bg-white border text-gray-600 hover:bg-gray-50"}`}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>
      <div className="bg-white rounded-lg border">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-gray-500">No payments found.</div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b text-left text-sm text-gray-500">
                <th className="px-4 py-3 font-medium">Description</th>
                <th className="px-4 py-3 font-medium">Amount</th>
                <th className="px-4 py-3 font-medium">Type</th>
                <th className="px-4 py-3 font-medium">Method</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((p: any) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-sm">{p.description}</td>
                  <td className={`px-4 py-3 text-sm font-medium ${p.paymentType === "income" ? "text-green-600" : "text-red-600"}`}>
                    {p.paymentType === "income" ? "+" : "-"}${p.amount.toLocaleString()}
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600 capitalize">{p.paymentType}</td>
                  <td className="px-4 py-3 text-sm text-gray-600 capitalize">{p.paymentMethod || "—"}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      p.status === "received" ? "bg-green-100 text-green-700" :
                      p.status === "pending" ? "bg-yellow-100 text-yellow-700" :
                      "bg-gray-100 text-gray-600"
                    }`}>{p.status}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{p.paidDate ? new Date(p.paidDate).toLocaleDateString() : "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
