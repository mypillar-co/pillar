import Link from "next/link";

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Nav */}
      <nav className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">CO</span>
            </div>
            <span className="font-bold text-xl">CivicOps</span>
          </div>
          <div className="flex items-center gap-6">
            <Link href="#features" className="text-sm text-muted-foreground hover:text-foreground">Features</Link>
            <Link href="#pricing" className="text-sm text-muted-foreground hover:text-foreground">Pricing</Link>
            <Link href="/login" className="text-sm font-medium text-primary hover:text-primary/80">Log in</Link>
            <Link href="/signup" className="text-sm font-medium bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90">Get Started Free</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-block bg-primary/10 text-primary text-sm font-medium px-3 py-1 rounded-full mb-6">
            Built by people who actually run events
          </div>
          <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
            Your organization deserves better than{" "}
            <span className="text-primary">spreadsheets</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Tell our AI what you need. Get a professional website and management dashboard in minutes.
            Events, vendors, sponsors, payments — all in one place.
          </p>
          <div className="flex gap-4 justify-center">
            <Link
              href="/signup"
              className="bg-primary text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-primary/90 transition-colors"
            >
              Start Free
            </Link>
            <Link
              href="/o/irwin-downtown"
              className="border border-border px-8 py-3 rounded-lg text-lg font-medium hover:bg-secondary transition-colors"
            >
              See Demo →
            </Link>
          </div>
          <p className="text-sm text-muted-foreground mt-4">
            No credit card required. Free tier available forever.
          </p>
        </div>
      </section>

      {/* Problem */}
      <section className="py-16 px-4 bg-secondary/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Sound familiar?</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[
              { icon: "📊", text: "Vendor tracking lives in Google Sheets that three people edit simultaneously" },
              { icon: "📧", text: "Sponsor commitments are buried in email threads nobody can find" },
              { icon: "💳", text: "Payment reconciliation means exporting Square CSVs and squinting at rows" },
              { icon: "🌐", text: "Your website hasn't been updated since someone's nephew built it in 2019" },
              { icon: "📋", text: "Event details are in 4 different places and none of them agree" },
              { icon: "😤", text: "You spend more time on admin than on actually running events" },
            ].map((item, i) => (
              <div key={i} className="bg-white rounded-lg p-6 border border-border flex gap-4">
                <span className="text-2xl flex-shrink-0">{item.icon}</span>
                <p className="text-muted-foreground">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">How it works</h2>
          <p className="text-lg text-muted-foreground mb-12">Three steps. No tech skills needed.</p>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">💬</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">1. Talk to the AI</h3>
              <p className="text-muted-foreground">
                Tell it about your organization. It asks smart questions and builds your site as you chat.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">🎨</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">2. Preview & launch</h3>
              <p className="text-muted-foreground">
                See your site come together in real time. Tweak anything. Hit publish when you're ready.
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📋</span>
              </div>
              <h3 className="font-semibold text-lg mb-2">3. Manage everything</h3>
              <p className="text-muted-foreground">
                Events, vendors, sponsors, payments — one dashboard. Your site updates automatically.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-4 bg-secondary/50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-4">Everything you need. Nothing you don't.</h2>
          <p className="text-lg text-muted-foreground text-center mb-12">Built for chambers, downtown associations, nonprofits, lodges, and festival committees.</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: "🤖", title: "AI Website Builder", desc: "Describe what you want. The AI builds it. No coding, no drag-and-drop — just conversation." },
              { icon: "🎪", title: "Event Management", desc: "Create events, manage registrations, track capacity, and publish to your site automatically." },
              { icon: "🏪", title: "Vendor Tracking", desc: "Applications, approvals, booth assignments, document tracking, fee collection — all in one place." },
              { icon: "🤝", title: "Sponsor Management", desc: "Tiers, pledges, payments, logo management. Know exactly where every sponsor stands." },
              { icon: "💰", title: "Payment Tracking", desc: "Track every dollar in and out. Vendor fees, sponsor payments, ticket revenue. No more Square CSV exports." },
              { icon: "📧", title: "Email Automation", desc: "Templates, bulk sends, document reminders. Stop copy-pasting the same email to 40 vendors." },
              { icon: "📄", title: "Document Management", desc: "Contracts, permits, insurance certificates, logos — attached to the right vendor, sponsor, or event." },
              { icon: "📊", title: "Dashboard", desc: "One screen that shows everything: upcoming events, outstanding payments, pending approvals." },
            ].map((feature, i) => (
              <div key={i} className="bg-white rounded-lg p-6 border border-border">
                <span className="text-3xl mb-3 block">{feature.icon}</span>
                <h3 className="font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8">Built from real experience</h2>
          <div className="bg-secondary/30 rounded-xl p-8 border border-border">
            <p className="text-lg italic text-muted-foreground mb-6">
              "We built CivicOps because we needed it ourselves. We run car cruises, street markets, night markets,
              and community dinners in Downtown Irwin, PA. We were drowning in Google Sheets, JotForm submissions,
              and Square exports. So we built the tool we wished existed."
            </p>
            <div className="flex items-center justify-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">DI</span>
              </div>
              <div className="text-left">
                <p className="font-semibold">Discover Irwin Team</p>
                <p className="text-sm text-muted-foreground">Downtown Irwin, PA — Running on CivicOps since Day 1</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-4 bg-secondary/50">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-4">Simple pricing</h2>
          <p className="text-lg text-muted-foreground text-center mb-12">Start free. Upgrade when you need more.</p>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              {
                name: "Free", price: "$0", period: "forever", desc: "Just need a website",
                features: ["AI-built website", "1 active event", "50 contacts", "Community subdomain"],
                cta: "Get Started", highlight: false,
              },
              {
                name: "Starter", price: "$39", period: "/month", desc: "Running a few events",
                features: ["Everything in Free", "Unlimited events", "Vendor tracking", "Sponsor tracking", "Custom domain", "Up to 3 users"],
                cta: "Start Free Trial", highlight: false,
              },
              {
                name: "Pro", price: "$89", period: "/month", desc: "Full operations",
                features: ["Everything in Starter", "Payment tracking", "Email automation", "Document management", "Reporting", "Unlimited users"],
                cta: "Start Free Trial", highlight: true,
              },
              {
                name: "Organization", price: "$149", period: "/month", desc: "Large-scale events",
                features: ["Everything in Pro", "API access", "Advanced reporting", "Priority support", "White-label option"],
                cta: "Contact Us", highlight: false,
              },
            ].map((plan, i) => (
              <div key={i} className={`rounded-lg p-6 border ${plan.highlight ? "border-primary bg-primary/5 ring-2 ring-primary" : "border-border bg-white"}`}>
                {plan.highlight && (
                  <div className="text-xs font-medium text-primary mb-2">MOST POPULAR</div>
                )}
                <h3 className="font-bold text-lg">{plan.name}</h3>
                <div className="mt-2 mb-1">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground text-sm">{plan.period}</span>
                </div>
                <p className="text-sm text-muted-foreground mb-4">{plan.desc}</p>
                <Link
                  href="/signup"
                  className={`block text-center py-2 rounded-lg text-sm font-medium mb-4 ${plan.highlight ? "bg-primary text-white hover:bg-primary/90" : "border border-border hover:bg-secondary"}`}
                >
                  {plan.cta}
                </Link>
                <ul className="space-y-2">
                  {plan.features.map((f, j) => (
                    <li key={j} className="text-sm text-muted-foreground flex gap-2">
                      <span className="text-primary">✓</span>
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to ditch the spreadsheets?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join organizations across the country who are managing events the right way.
          </p>
          <Link
            href="/signup"
            className="bg-primary text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-primary/90 transition-colors"
          >
            Start Building — It's Free
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12 px-4">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
              <span className="text-white font-bold text-xs">CO</span>
            </div>
            <span className="font-semibold">CivicOps</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2026 CivicOps. Built in Irwin, PA.
          </p>
        </div>
      </footer>
    </div>
  );
}
