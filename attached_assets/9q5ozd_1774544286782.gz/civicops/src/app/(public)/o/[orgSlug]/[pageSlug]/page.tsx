import { db } from "@/lib/db";
import { organizations, sites, sitePages, siteBlocks, siteNavItems, events, eventSponsors } from "@/db/schema";
import { eq, and, asc } from "drizzle-orm";
import { notFound } from "next/navigation";
import { BlockRenderer } from "@/components/site-blocks/block-renderer";

export default async function OrgDynamicPage({ params }: { params: { orgSlug: string; pageSlug: string } }) {
  const org = await db.query.organizations.findFirst({
    where: eq(organizations.slug, params.orgSlug),
  });
  if (!org) notFound();

  const site = await db.query.sites.findFirst({
    where: eq(sites.orgId, org.id),
    with: {
      pages: {
        orderBy: [asc(sitePages.sortOrder)],
        with: {
          blocks: { orderBy: [asc(siteBlocks.sortOrder)] },
        },
      },
      navItems: { orderBy: [asc(siteNavItems.sortOrder)] },
    },
  });
  if (!site || site.status !== "published") notFound();

  const page = site.pages.find(p => p.slug === params.pageSlug);
  if (!page || !page.isPublished) notFound();

  // Fetch dynamic data
  const orgEvents = await db.query.events.findMany({
    where: and(eq(events.orgId, org.id), eq(events.isActive, true)),
    orderBy: [asc(events.startDate)],
  });

  const orgEventSponsors = await db.query.eventSponsors.findMany({
    where: and(eq(eventSponsors.orgId, org.id), eq(eventSponsors.status, "confirmed")),
    with: { sponsor: true, event: true },
  });

  const theme = (site.theme || {}) as Record<string, string>;
  const primaryColor = theme.primaryColor || "#2563eb";

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <a href={`/o/${org.slug}`} className="flex items-center gap-3">
            {org.logoUrl && <img src={org.logoUrl} alt={org.name} className="h-8" />}
            <span className="font-bold text-lg" style={{ color: primaryColor }}>{org.name}</span>
          </a>
          <nav className="flex items-center gap-6">
            {site.navItems?.filter((n: any) => n.isVisible).map((item: any) => {
              const p = site.pages.find((pg: any) => pg.id === item.pageId);
              const href = p ? `/o/${org.slug}${p.slug === "home" ? "" : `/${p.slug}`}` : item.url || "#";
              const isActive = p?.slug === params.pageSlug;
              return (
                <a key={item.id} href={href}
                  className={`text-sm transition-colors ${isActive ? "font-medium" : "text-gray-600 hover:text-gray-900"}`}
                  style={isActive ? { color: primaryColor } : undefined}
                >
                  {item.label}
                </a>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Page Content */}
      <main>
        {page.blocks.filter(b => b.isVisible).map((block) => (
          <BlockRenderer
            key={block.id}
            block={{ ...block, content: block.content || {} }}
            events={orgEvents}
            eventSponsors={orgEventSponsors as any}
            theme={theme}
            orgSlug={org.slug}
          />
        ))}
      </main>

      {/* Footer */}
      <footer className="border-t bg-gray-50 py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-gray-500">© {new Date().getFullYear()} {org.name}</p>
          <p className="text-xs text-gray-400 mt-1">
            Powered by <a href="/" className="hover:text-gray-600">CivicOps</a>
          </p>
        </div>
      </footer>
    </div>
  );
}
