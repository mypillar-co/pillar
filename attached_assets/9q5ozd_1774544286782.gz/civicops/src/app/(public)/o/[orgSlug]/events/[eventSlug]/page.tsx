import { db } from "@/lib/db";
import { organizations, events, sites } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { notFound } from "next/navigation";
import Link from "next/link";

export default async function EventDetailPublicPage({ params }: { params: { orgSlug: string; eventSlug: string } }) {
  const org = await db.query.organizations.findFirst({
    where: eq(organizations.slug, params.orgSlug),
  });
  if (!org) notFound();

  const site = await db.query.sites.findFirst({ where: eq(sites.orgId, org.id) });

  const event = await db.query.events.findFirst({
    where: and(eq(events.orgId, org.id), eq(events.slug, params.eventSlug), eq(events.isActive, true)),
  });
  if (!event) notFound();

  const theme = ((site?.theme || {}) as Record<string, string>);
  const primaryColor = theme.primaryColor || "#2563eb";

  return (
    <div className="min-h-screen">
      <header className="border-b bg-white sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href={`/o/${org.slug}`} className="font-bold text-lg" style={{ color: primaryColor }}>{org.name}</Link>
          <nav className="flex items-center gap-6">
            <Link href={`/o/${org.slug}`} className="text-sm text-gray-600 hover:text-gray-900">Home</Link>
            <Link href={`/o/${org.slug}/events`} className="text-sm text-gray-600 hover:text-gray-900">Events</Link>
          </nav>
        </div>
      </header>
      <main className="max-w-3xl mx-auto px-4 py-12">
        <Link href={`/o/${org.slug}/events`} className="text-sm text-gray-500 hover:text-gray-700 mb-4 inline-block">← All Events</Link>
        {event.imageUrl && <img src={event.imageUrl} alt={event.name} className="w-full h-64 object-cover rounded-lg mb-6" />}
        <div className="flex items-center gap-3 mb-2">
          {event.eventType && <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 capitalize">{event.eventType}</span>}
          {event.featured && <span className="text-xs font-medium px-2 py-0.5 rounded-full text-white" style={{ backgroundColor: primaryColor }}>Featured</span>}
        </div>
        <h1 className="text-4xl font-bold mb-4">{event.name}</h1>
        <div className="flex flex-wrap gap-4 text-gray-600 mb-6">
          {event.startDate && (
            <span>📅 {new Date(event.startDate + "T00:00:00").toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
              {event.startTime ? ` at ${event.startTime}` : ""}</span>
          )}
          {event.location && <span>📍 {event.location}</span>}
          {event.maxCapacity && <span>👥 Capacity: {event.maxCapacity}</span>}
        </div>
        {event.isTicketed && event.ticketPrice && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p className="font-medium" style={{ color: primaryColor }}>🎟️ Tickets: ${event.ticketPrice}</p>
          </div>
        )}
        {event.description && <div className="prose prose-gray max-w-none"><p>{event.description}</p></div>}
      </main>
      <footer className="border-t bg-gray-50 py-8 px-4 mt-12">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-sm text-gray-500">© {new Date().getFullYear()} {org.name}</p>
          <p className="text-xs text-gray-400 mt-1">Powered by <a href="/" className="hover:text-gray-600">CivicOps</a></p>
        </div>
      </footer>
    </div>
  );
}
