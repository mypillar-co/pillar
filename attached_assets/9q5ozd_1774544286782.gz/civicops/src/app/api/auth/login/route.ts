import { NextRequest, NextResponse } from "next/server";
import { authenticateUser } from "@/lib/services/auth";
import { getUserOrganizations } from "@/lib/services/orgs";

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();

    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 });
    }

    const user = await authenticateUser(email, password);
    if (!user) {
      return NextResponse.json({ error: "Invalid email or password" }, { status: 401 });
    }

    const orgs = await getUserOrganizations(user.id);

    // Simple token (in production, use JWT)
    const token = Buffer.from(JSON.stringify({ userId: user.id, ts: Date.now() })).toString("base64");

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        isSuperAdmin: user.isSuperAdmin,
        organizations: orgs,
      },
      token,
    });
  } catch (error) {
    console.error("Login error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
