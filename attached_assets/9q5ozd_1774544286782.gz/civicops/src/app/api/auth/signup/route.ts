import { NextRequest, NextResponse } from "next/server";
import { createUser, getUserByEmail } from "@/lib/services/auth";
import { createOrganization, getUserOrganizations } from "@/lib/services/orgs";
import { createDefaultSponsorTiers } from "@/lib/services/sponsors";
import { scaffoldDefaultSite } from "@/lib/services/site";
import { slugify } from "@/lib/utils";

export async function POST(req: NextRequest) {
  try {
    const { email, password, firstName, lastName, orgName, orgType } = await req.json();

    if (!email || !password || !orgName) {
      return NextResponse.json({ error: "Email, password, and organization name required" }, { status: 400 });
    }

    if (password.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters" }, { status: 400 });
    }

    // Check if user exists
    const existing = await getUserByEmail(email);
    if (existing) {
      return NextResponse.json({ error: "An account with this email already exists" }, { status: 409 });
    }

    // Create user
    const user = await createUser({ email, password, firstName, lastName });

    // Create org
    const org = await createOrganization({
      name: orgName,
      orgType: orgType || "other",
      userId: user.id,
    });

    // Set up defaults
    await createDefaultSponsorTiers(org.id);
    await scaffoldDefaultSite(org.id, orgName, org.slug);

    const orgs = await getUserOrganizations(user.id);

    const token = Buffer.from(JSON.stringify({ userId: user.id, ts: Date.now() })).toString("base64");

    return NextResponse.json({
      user: {
        id: user.id,
        email,
        firstName,
        lastName,
        isSuperAdmin: false,
        organizations: orgs,
      },
      token,
    });
  } catch (error: any) {
    console.error("Signup error:", error);
    if (error?.message?.includes("UNIQUE")) {
      return NextResponse.json({ error: "This email or organization name is already taken" }, { status: 409 });
    }
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
