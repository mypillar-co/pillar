import { NextRequest, NextResponse } from "next/server";
import { getSponsors, createSponsor } from "@/lib/services/sponsors";

export async function GET(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const sponsors = await getSponsors(params.orgId);
    return NextResponse.json(sponsors);
  } catch (error) {
    console.error("Error fetching sponsors:", error);
    return NextResponse.json({ error: "Failed to fetch sponsors" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const data = await req.json();
    const result = await createSponsor(params.orgId, data);
    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    console.error("Error creating sponsor:", error);
    return NextResponse.json({ error: "Failed to create sponsor" }, { status: 500 });
  }
}
