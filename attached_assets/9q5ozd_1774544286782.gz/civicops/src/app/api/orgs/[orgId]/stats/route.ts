import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { events, vendors, sponsors, payments, eventVendors, eventSponsors } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function GET(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const orgId = params.orgId;

    const allEvents = await db.query.events.findMany({
      where: eq(events.orgId, orgId),
    });

    const allVendors = await db.query.vendors.findMany({
      where: eq(vendors.orgId, orgId),
    });

    const allSponsors = await db.query.sponsors.findMany({
      where: eq(sponsors.orgId, orgId),
    });

    const allPayments = await db.query.payments.findMany({
      where: eq(payments.orgId, orgId),
    });

    const activeEvents = allEvents.filter(e => e.isActive);
    const totalRevenue = allPayments
      .filter(p => p.paymentType === "income" && p.status === "received")
      .reduce((sum, p) => sum + p.amount, 0);

    const pendingPayments = allPayments
      .filter(p => p.status === "pending")
      .reduce((sum, p) => sum + p.amount, 0);

    return NextResponse.json({
      activeEvents: activeEvents.length,
      totalEvents: allEvents.length,
      totalVendors: allVendors.length,
      totalSponsors: allSponsors.length,
      totalPayments: allPayments.length,
      totalRevenue,
      pendingPayments,
    });
  } catch (error) {
    console.error("Error fetching stats:", error);
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}
