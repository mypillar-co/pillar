import { NextRequest, NextResponse } from "next/server";
import { getEvents, createEvent } from "@/lib/services/events";

export async function GET(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const url = new URL(req.url);
    const includeInactive = url.searchParams.get("includeInactive") === "1";
    const events = await getEvents(params.orgId, { includeInactive });
    return NextResponse.json(events);
  } catch (error) {
    console.error("Error fetching events:", error);
    return NextResponse.json({ error: "Failed to fetch events" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const data = await req.json();
    const result = await createEvent(params.orgId, data);
    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    console.error("Error creating event:", error);
    return NextResponse.json({ error: "Failed to create event" }, { status: 500 });
  }
}
