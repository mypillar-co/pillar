import { NextRequest, NextResponse } from "next/server";
import { getPayments, createPayment, getPaymentSummary } from "@/lib/services/payments";

export async function GET(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const url = new URL(req.url);
    const eventId = url.searchParams.get("eventId") || undefined;
    const summary = url.searchParams.get("summary") === "1";

    if (summary) {
      const result = await getPaymentSummary(params.orgId, eventId);
      return NextResponse.json(result);
    }

    const payments = await getPayments(params.orgId, { eventId });
    return NextResponse.json(payments);
  } catch (error) {
    console.error("Error fetching payments:", error);
    return NextResponse.json({ error: "Failed to fetch payments" }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: { orgId: string } }) {
  try {
    const data = await req.json();
    const result = await createPayment(params.orgId, data);
    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    console.error("Error creating payment:", error);
    return NextResponse.json({ error: "Failed to create payment" }, { status: 500 });
  }
}
