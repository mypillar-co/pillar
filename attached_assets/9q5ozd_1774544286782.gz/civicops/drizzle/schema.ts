import { sqliteTable, text, integer, real, uniqueIndex, index } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";
import { nanoid } from "nanoid";

// Helper for generating IDs
const id = () => text("id").primaryKey().$defaultFn(() => nanoid());
const orgId = () => text("org_id").notNull();
const timestamps = () => ({
  createdAt: text("created_at").$defaultFn(() => new Date().toISOString()),
  updatedAt: text("updated_at").$defaultFn(() => new Date().toISOString()),
});

// ============================================================
// TIER 1: TENANT
// ============================================================

export const organizations = sqliteTable("organizations", {
  id: id(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  orgType: text("org_type"), // chamber, downtown_assoc, nonprofit, lodge, festival_committee
  status: text("status").default("active"), // active, suspended, trial
  plan: text("plan").default("free"), // free, starter, pro, organization
  logoUrl: text("logo_url"),
  brandColors: text("brand_colors", { mode: "json" }).$type<{
    primary?: string;
    secondary?: string;
    accent?: string;
  }>(),
  settings: text("settings", { mode: "json" }).$type<Record<string, unknown>>(),
  ...timestamps(),
});

// ============================================================
// TIER 2: USERS & ACCESS
// ============================================================

export const users = sqliteTable("users", {
  id: id(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  isSuperAdmin: integer("is_super_admin", { mode: "boolean" }).default(false),
  lastLoginAt: text("last_login_at"),
  ...timestamps(),
});

export const orgMemberships = sqliteTable("org_memberships", {
  id: id(),
  orgId: orgId(),
  userId: text("user_id").notNull(),
  role: text("role").notNull().default("viewer"), // admin, staff, viewer
  ...timestamps(),
}, (table) => ({
  orgUserIdx: uniqueIndex("org_user_idx").on(table.orgId, table.userId),
}));

// ============================================================
// TIER 3: CORE OPERATIONS
// ============================================================

export const events = sqliteTable("events", {
  id: id(),
  orgId: orgId(),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  description: text("description"),
  eventType: text("event_type"), // festival, mixer, fundraiser, meeting, market
  status: text("status").default("draft"), // draft, published, active, completed, cancelled
  startDate: text("start_date"),
  endDate: text("end_date"),
  startTime: text("start_time"),
  endTime: text("end_time"),
  location: text("location"),
  maxCapacity: integer("max_capacity"),
  isTicketed: integer("is_ticketed", { mode: "boolean" }).default(false),
  ticketPrice: real("ticket_price"),
  ticketCapacity: integer("ticket_capacity"),
  hasRegistration: integer("has_registration", { mode: "boolean" }).default(false),
  isActive: integer("is_active", { mode: "boolean" }).default(true),
  featured: integer("featured", { mode: "boolean" }).default(false),
  imageUrl: text("image_url"),
  settings: text("settings", { mode: "json" }).$type<Record<string, unknown>>(),
  ...timestamps(),
}, (table) => ({
  orgSlugIdx: uniqueIndex("event_org_slug_idx").on(table.orgId, table.slug),
  orgIdx: index("event_org_idx").on(table.orgId),
}));

export const contacts = sqliteTable("contacts", {
  id: id(),
  orgId: orgId(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name"),
  email: text("email"),
  phone: text("phone"),
  company: text("company"),
  contactType: text("contact_type"), // general, vendor_rep, sponsor_rep, attendee
  notes: text("notes"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("contact_org_idx").on(table.orgId),
  emailIdx: index("contact_email_idx").on(table.orgId, table.email),
}));

export const vendors = sqliteTable("vendors", {
  id: id(),
  orgId: orgId(),
  name: text("name").notNull(),
  contactId: text("contact_id"),
  vendorType: text("vendor_type"), // food, merchandise, entertainment, service
  email: text("email"),
  phone: text("phone"),
  status: text("status").default("active"), // active, inactive, blacklisted
  notes: text("notes"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("vendor_org_idx").on(table.orgId),
}));

export const sponsors = sqliteTable("sponsors", {
  id: id(),
  orgId: orgId(),
  name: text("name").notNull(),
  contactId: text("contact_id"),
  email: text("email"),
  phone: text("phone"),
  website: text("website"),
  logoUrl: text("logo_url"),
  status: text("status").default("active"), // active, inactive
  notes: text("notes"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("sponsor_org_idx").on(table.orgId),
}));

// ============================================================
// JUNCTION TABLES: Per-Event Relationships
// ============================================================

export const eventVendors = sqliteTable("event_vendors", {
  id: id(),
  orgId: orgId(),
  eventId: text("event_id").notNull(),
  vendorId: text("vendor_id").notNull(),
  boothNumber: text("booth_number"),
  boothLocation: text("booth_location"),
  feeAmount: real("fee_amount"),
  feeStatus: text("fee_status").default("pending"), // pending, paid, waived, overdue
  status: text("status").default("pending"), // pending, invited, confirmed, declined, cancelled
  servSafeStatus: text("servsafe_status").default("missing"), // missing, uploaded, received
  insuranceStatus: text("insurance_status").default("missing"),
  notes: text("notes"),
  settings: text("settings", { mode: "json" }).$type<Record<string, unknown>>(),
  ...timestamps(),
}, (table) => ({
  eventVendorIdx: uniqueIndex("ev_event_vendor_idx").on(table.eventId, table.vendorId),
  orgIdx: index("ev_org_idx").on(table.orgId),
}));

export const eventSponsors = sqliteTable("event_sponsors", {
  id: id(),
  orgId: orgId(),
  eventId: text("event_id").notNull(),
  sponsorId: text("sponsor_id").notNull(),
  tier: text("tier"), // presenting, gold, silver, bronze, in-kind, custom
  amountPledged: real("amount_pledged"),
  amountReceived: real("amount_received").default(0),
  benefits: text("benefits"),
  status: text("status").default("pending"), // pending, confirmed, declined, fulfilled
  notes: text("notes"),
  ...timestamps(),
}, (table) => ({
  eventSponsorIdx: uniqueIndex("es_event_sponsor_idx").on(table.eventId, table.sponsorId),
  orgIdx: index("es_org_idx").on(table.orgId),
}));

export const registrations = sqliteTable("registrations", {
  id: id(),
  orgId: orgId(),
  eventId: text("event_id").notNull(),
  contactId: text("contact_id").notNull(),
  registrationType: text("registration_type"), // general, vip, volunteer, speaker
  status: text("status").default("registered"), // registered, confirmed, attended, cancelled, no_show
  feeAmount: real("fee_amount"),
  feeStatus: text("fee_status").default("pending"), // pending, paid, waived, refunded
  registeredAt: text("registered_at").$defaultFn(() => new Date().toISOString()),
  notes: text("notes"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("reg_org_idx").on(table.orgId),
  eventIdx: index("reg_event_idx").on(table.eventId),
}));

// ============================================================
// TIER 4: TRACKING
// ============================================================

export const payments = sqliteTable("payments", {
  id: id(),
  orgId: orgId(),
  // Polymorphic parent links
  eventVendorId: text("event_vendor_id"),
  eventSponsorId: text("event_sponsor_id"),
  registrationId: text("registration_id"),
  eventId: text("event_id"), // Direct event link for simple cases
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  paymentMethod: text("payment_method"), // cash, check, square, paypal, invoice, other
  paymentType: text("payment_type").notNull(), // income, expense
  paymentCategory: text("payment_category"), // participant, sponsor, vendor, ticket
  status: text("status").default("pending"), // pending, received, sent, overdue, cancelled
  dueDate: text("due_date"),
  paidDate: text("paid_date"),
  referenceNumber: text("reference_number"),
  externalId: text("external_id"), // Square/Stripe transaction ID
  notes: text("notes"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("pay_org_idx").on(table.orgId),
  eventIdx: index("pay_event_idx").on(table.eventId),
}));

export const documents = sqliteTable("documents", {
  id: id(),
  orgId: orgId(),
  // Polymorphic parent links
  eventId: text("event_id"),
  vendorId: text("vendor_id"),
  sponsorId: text("sponsor_id"),
  contactId: text("contact_id"),
  name: text("name").notNull(),
  fileUrl: text("file_url"),
  fileType: text("file_type"),
  fileSize: integer("file_size"),
  docCategory: text("doc_category"), // contract, permit, invoice, logo, insurance, other
  notes: text("notes"),
  uploadedBy: text("uploaded_by"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("doc_org_idx").on(table.orgId),
}));

export const emailTemplates = sqliteTable("email_templates", {
  id: id(),
  orgId: orgId(),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  templateType: text("template_type"), // vendor_invite, sponsor_thank_you, registration_confirm
  ...timestamps(),
});

export const emailLogs = sqliteTable("email_logs", {
  id: id(),
  orgId: orgId(),
  templateId: text("template_id"),
  sentToEmail: text("sent_to_email").notNull(),
  sentToContact: text("sent_to_contact"),
  subject: text("subject"),
  body: text("body"),
  status: text("status").default("sent"), // sent, failed, bounced
  eventId: text("event_id"),
  sentBy: text("sent_by"),
  sentAt: text("sent_at").$defaultFn(() => new Date().toISOString()),
  ...timestamps(),
});

// ============================================================
// SPONSOR TIERS (per-org configurable)
// ============================================================

export const sponsorTiers = sqliteTable("sponsor_tiers", {
  id: id(),
  orgId: orgId(),
  name: text("name").notNull(),
  amount: real("amount"),
  sortOrder: integer("sort_order").default(0),
  benefits: text("benefits"),
  ...timestamps(),
}, (table) => ({
  orgNameIdx: uniqueIndex("st_org_name_idx").on(table.orgId, table.name),
}));

// ============================================================
// WEBSITE BUILDER
// ============================================================

export const sites = sqliteTable("sites", {
  id: id(),
  orgId: orgId(),
  subdomain: text("subdomain").unique(),
  customDomain: text("custom_domain"),
  theme: text("theme", { mode: "json" }).$type<{
    primaryColor?: string;
    secondaryColor?: string;
    accentColor?: string;
    fontHeading?: string;
    fontBody?: string;
    logoUrl?: string;
  }>(),
  status: text("status").default("draft"), // draft, published, maintenance
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  faviconUrl: text("favicon_url"),
  settings: text("settings", { mode: "json" }).$type<Record<string, unknown>>(),
  publishedAt: text("published_at"),
  ...timestamps(),
}, (table) => ({
  orgIdx: uniqueIndex("site_org_idx").on(table.orgId),
}));

export const sitePages = sqliteTable("site_pages", {
  id: id(),
  orgId: orgId(),
  siteId: text("site_id").notNull(),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  pageType: text("page_type").notNull(), // home, about, events, events_detail, sponsors, contact, gallery, custom, vendor_application
  isPublished: integer("is_published", { mode: "boolean" }).default(false),
  sortOrder: integer("sort_order").default(0),
  metaTitle: text("meta_title"),
  metaDescription: text("meta_description"),
  settings: text("settings", { mode: "json" }).$type<Record<string, unknown>>(),
  ...timestamps(),
}, (table) => ({
  siteSlugIdx: uniqueIndex("sp_site_slug_idx").on(table.siteId, table.slug),
}));

export const siteBlocks = sqliteTable("site_blocks", {
  id: id(),
  orgId: orgId(),
  pageId: text("page_id").notNull(),
  blockType: text("block_type").notNull(), // hero, text, image, gallery, events_list, sponsors_grid, contact_form, registration_form, vendor_app_form, map, video, social_links, cta_banner, divider
  content: text("content", { mode: "json" }).$type<Record<string, unknown>>().default({}),
  sortOrder: integer("sort_order").default(0),
  isVisible: integer("is_visible", { mode: "boolean" }).default(true),
  settings: text("settings", { mode: "json" }).$type<Record<string, unknown>>(),
  ...timestamps(),
});

export const siteNavItems = sqliteTable("site_nav_items", {
  id: id(),
  orgId: orgId(),
  siteId: text("site_id").notNull(),
  label: text("label").notNull(),
  url: text("url"),
  pageId: text("page_id"),
  parentId: text("parent_id"),
  sortOrder: integer("sort_order").default(0),
  isVisible: integer("is_visible", { mode: "boolean" }).default(true),
  ...timestamps(),
});

// ============================================================
// AI CONVERSATIONS
// ============================================================

export const aiConversations = sqliteTable("ai_conversations", {
  id: id(),
  orgId: orgId(),
  userId: text("user_id").notNull(),
  provider: text("provider").default("openai"), // openai, anthropic, google
  model: text("model"),
  purpose: text("purpose").default("site_builder"), // site_builder, content_edit, support
  ...timestamps(),
});

export const aiMessages = sqliteTable("ai_messages", {
  id: id(),
  conversationId: text("conversation_id").notNull(),
  role: text("role").notNull(), // user, assistant, system
  content: text("content").notNull(),
  structuredOutput: text("structured_output", { mode: "json" }).$type<Record<string, unknown>>(),
  tokensUsed: integer("tokens_used"),
  ...timestamps(),
});

// ============================================================
// MEDIA LIBRARY
// ============================================================

export const media = sqliteTable("media", {
  id: id(),
  orgId: orgId(),
  filename: text("filename").notNull(),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type"),
  fileSize: integer("file_size"),
  altText: text("alt_text"),
  uploadedBy: text("uploaded_by"),
  ...timestamps(),
}, (table) => ({
  orgIdx: index("media_org_idx").on(table.orgId),
}));

// ============================================================
// TAGS & CUSTOM FIELDS
// ============================================================

export const tags = sqliteTable("tags", {
  id: id(),
  orgId: orgId(),
  name: text("name").notNull(),
  color: text("color"),
}, (table) => ({
  orgNameIdx: uniqueIndex("tag_org_name_idx").on(table.orgId, table.name),
}));

export const taggings = sqliteTable("taggings", {
  id: id(),
  tagId: text("tag_id").notNull(),
  taggableType: text("taggable_type").notNull(), // event, vendor, sponsor, contact
  taggableId: text("taggable_id").notNull(),
}, (table) => ({
  uniqueTagging: uniqueIndex("tagging_unique_idx").on(table.tagId, table.taggableType, table.taggableId),
}));

// ============================================================
// RELATIONS
// ============================================================

export const organizationsRelations = relations(organizations, ({ many }) => ({
  memberships: many(orgMemberships),
  events: many(events),
  vendors: many(vendors),
  sponsors: many(sponsors),
  contacts: many(contacts),
  payments: many(payments),
  documents: many(documents),
  sponsorTiers: many(sponsorTiers),
  sites: many(sites),
}));

export const usersRelations = relations(users, ({ many }) => ({
  memberships: many(orgMemberships),
}));

export const orgMembershipsRelations = relations(orgMemberships, ({ one }) => ({
  organization: one(organizations, {
    fields: [orgMemberships.orgId],
    references: [organizations.id],
  }),
  user: one(users, {
    fields: [orgMemberships.userId],
    references: [users.id],
  }),
}));

export const eventsRelations = relations(events, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [events.orgId],
    references: [organizations.id],
  }),
  eventVendors: many(eventVendors),
  eventSponsors: many(eventSponsors),
  registrations: many(registrations),
}));

export const vendorsRelations = relations(vendors, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [vendors.orgId],
    references: [organizations.id],
  }),
  contact: one(contacts, {
    fields: [vendors.contactId],
    references: [contacts.id],
  }),
  eventVendors: many(eventVendors),
}));

export const sponsorsRelations = relations(sponsors, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [sponsors.orgId],
    references: [organizations.id],
  }),
  contact: one(contacts, {
    fields: [sponsors.contactId],
    references: [contacts.id],
  }),
  eventSponsors: many(eventSponsors),
}));

export const eventVendorsRelations = relations(eventVendors, ({ one }) => ({
  event: one(events, {
    fields: [eventVendors.eventId],
    references: [events.id],
  }),
  vendor: one(vendors, {
    fields: [eventVendors.vendorId],
    references: [vendors.id],
  }),
}));

export const eventSponsorsRelations = relations(eventSponsors, ({ one }) => ({
  event: one(events, {
    fields: [eventSponsors.eventId],
    references: [events.id],
  }),
  sponsor: one(sponsors, {
    fields: [eventSponsors.sponsorId],
    references: [sponsors.id],
  }),
}));

export const registrationsRelations = relations(registrations, ({ one }) => ({
  event: one(events, {
    fields: [registrations.eventId],
    references: [events.id],
  }),
  contact: one(contacts, {
    fields: [registrations.contactId],
    references: [contacts.id],
  }),
}));

export const sitesRelations = relations(sites, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [sites.orgId],
    references: [organizations.id],
  }),
  pages: many(sitePages),
  navItems: many(siteNavItems),
}));

export const sitePagesRelations = relations(sitePages, ({ one, many }) => ({
  site: one(sites, {
    fields: [sitePages.siteId],
    references: [sites.id],
  }),
  blocks: many(siteBlocks),
}));

export const siteBlocksRelations = relations(siteBlocks, ({ one }) => ({
  page: one(sitePages, {
    fields: [siteBlocks.pageId],
    references: [sitePages.id],
  }),
}));
