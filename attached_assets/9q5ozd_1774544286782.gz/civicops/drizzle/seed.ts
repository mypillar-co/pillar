import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import * as schema from "./schema";
import { nanoid } from "nanoid";
import bcrypt from "bcryptjs";
import path from "path";

const dbPath = process.env.DATABASE_URL?.replace("file:", "") ||
  path.join(process.cwd(), "civicops.db");

console.log(`Seeding database at ${dbPath}...`);

const sqlite = new Database(dbPath);
sqlite.pragma("journal_mode = WAL");
sqlite.pragma("foreign_keys = ON");

const db = drizzle(sqlite, { schema });

async function seed() {
  console.log("Creating tables...");

  sqlite.exec(`
    CREATE TABLE IF NOT EXISTS organizations (
      id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
      org_type TEXT, status TEXT DEFAULT 'active', plan TEXT DEFAULT 'free',
      logo_url TEXT, brand_colors TEXT, settings TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT,
      first_name TEXT, last_name TEXT, is_super_admin INTEGER DEFAULT 0,
      last_login_at TEXT, created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS org_memberships (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, user_id TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'viewer', created_at TEXT, updated_at TEXT,
      UNIQUE(org_id, user_id)
    );
    CREATE TABLE IF NOT EXISTS events (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL, slug TEXT NOT NULL,
      description TEXT, event_type TEXT, status TEXT DEFAULT 'draft',
      start_date TEXT, end_date TEXT, start_time TEXT, end_time TEXT,
      location TEXT, max_capacity INTEGER,
      is_ticketed INTEGER DEFAULT 0, ticket_price REAL, ticket_capacity INTEGER,
      has_registration INTEGER DEFAULT 0, is_active INTEGER DEFAULT 1, featured INTEGER DEFAULT 0,
      image_url TEXT, settings TEXT, created_at TEXT, updated_at TEXT,
      UNIQUE(org_id, slug)
    );
    CREATE TABLE IF NOT EXISTS contacts (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, first_name TEXT NOT NULL, last_name TEXT,
      email TEXT, phone TEXT, company TEXT, contact_type TEXT, notes TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS vendors (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL, contact_id TEXT,
      vendor_type TEXT, email TEXT, phone TEXT, status TEXT DEFAULT 'active', notes TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sponsors (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL, contact_id TEXT,
      email TEXT, phone TEXT, website TEXT, logo_url TEXT, status TEXT DEFAULT 'active', notes TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS event_vendors (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, event_id TEXT NOT NULL, vendor_id TEXT NOT NULL,
      booth_number TEXT, booth_location TEXT, fee_amount REAL,
      fee_status TEXT DEFAULT 'pending', status TEXT DEFAULT 'pending',
      servsafe_status TEXT DEFAULT 'missing', insurance_status TEXT DEFAULT 'missing',
      notes TEXT, settings TEXT, created_at TEXT, updated_at TEXT,
      UNIQUE(event_id, vendor_id)
    );
    CREATE TABLE IF NOT EXISTS event_sponsors (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, event_id TEXT NOT NULL, sponsor_id TEXT NOT NULL,
      tier TEXT, amount_pledged REAL, amount_received REAL DEFAULT 0,
      benefits TEXT, status TEXT DEFAULT 'pending', notes TEXT,
      created_at TEXT, updated_at TEXT,
      UNIQUE(event_id, sponsor_id)
    );
    CREATE TABLE IF NOT EXISTS registrations (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, event_id TEXT NOT NULL, contact_id TEXT NOT NULL,
      registration_type TEXT, status TEXT DEFAULT 'registered',
      fee_amount REAL, fee_status TEXT DEFAULT 'pending', registered_at TEXT, notes TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL,
      event_vendor_id TEXT, event_sponsor_id TEXT, registration_id TEXT, event_id TEXT,
      description TEXT NOT NULL, amount REAL NOT NULL,
      payment_method TEXT, payment_type TEXT NOT NULL, payment_category TEXT,
      status TEXT DEFAULT 'pending', due_date TEXT, paid_date TEXT,
      reference_number TEXT, external_id TEXT, notes TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL,
      event_id TEXT, vendor_id TEXT, sponsor_id TEXT, contact_id TEXT,
      name TEXT NOT NULL, file_url TEXT, file_type TEXT, file_size INTEGER,
      doc_category TEXT, notes TEXT, uploaded_by TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS email_templates (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL,
      subject TEXT NOT NULL, body TEXT NOT NULL, template_type TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS email_logs (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, template_id TEXT,
      sent_to_email TEXT NOT NULL, sent_to_contact TEXT, subject TEXT, body TEXT,
      status TEXT DEFAULT 'sent', event_id TEXT, sent_by TEXT, sent_at TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS sponsor_tiers (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL,
      amount REAL, sort_order INTEGER DEFAULT 0, benefits TEXT,
      created_at TEXT, updated_at TEXT,
      UNIQUE(org_id, name)
    );
    CREATE TABLE IF NOT EXISTS sites (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL UNIQUE, subdomain TEXT UNIQUE,
      custom_domain TEXT, theme TEXT, status TEXT DEFAULT 'draft',
      meta_title TEXT, meta_description TEXT, favicon_url TEXT, settings TEXT,
      published_at TEXT, created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS site_pages (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, site_id TEXT NOT NULL,
      title TEXT NOT NULL, slug TEXT NOT NULL, page_type TEXT NOT NULL,
      is_published INTEGER DEFAULT 0, sort_order INTEGER DEFAULT 0,
      meta_title TEXT, meta_description TEXT, settings TEXT,
      created_at TEXT, updated_at TEXT,
      UNIQUE(site_id, slug)
    );
    CREATE TABLE IF NOT EXISTS site_blocks (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, page_id TEXT NOT NULL,
      block_type TEXT NOT NULL, content TEXT DEFAULT '{}',
      sort_order INTEGER DEFAULT 0, is_visible INTEGER DEFAULT 1, settings TEXT,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS site_nav_items (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, site_id TEXT NOT NULL,
      label TEXT NOT NULL, url TEXT, page_id TEXT, parent_id TEXT,
      sort_order INTEGER DEFAULT 0, is_visible INTEGER DEFAULT 1,
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ai_conversations (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, user_id TEXT NOT NULL,
      provider TEXT DEFAULT 'openai', model TEXT, purpose TEXT DEFAULT 'site_builder',
      created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ai_messages (
      id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, role TEXT NOT NULL,
      content TEXT NOT NULL, structured_output TEXT, tokens_used INTEGER, created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS media (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, filename TEXT NOT NULL,
      file_url TEXT NOT NULL, file_type TEXT, file_size INTEGER, alt_text TEXT,
      uploaded_by TEXT, created_at TEXT, updated_at TEXT
    );
    CREATE TABLE IF NOT EXISTS tags (
      id TEXT PRIMARY KEY, org_id TEXT NOT NULL, name TEXT NOT NULL, color TEXT,
      UNIQUE(org_id, name)
    );
    CREATE TABLE IF NOT EXISTS taggings (
      id TEXT PRIMARY KEY, tag_id TEXT NOT NULL, taggable_type TEXT NOT NULL,
      taggable_id TEXT NOT NULL,
      UNIQUE(tag_id, taggable_type, taggable_id)
    );
  `);

  console.log("Tables created. Inserting demo data...");
  const now = new Date().toISOString();
  const passwordHash = await bcrypt.hash("demo1234", 10);

  // Demo User
  const userId = nanoid();
  sqlite.prepare(`INSERT OR IGNORE INTO users VALUES (?,?,?,?,?,?,?,?,?)`).run(
    userId, "demo@civicops.com", passwordHash, "Demo", "Admin", 1, null, now, now
  );

  // Org 1: Irwin Downtown Association
  const org1Id = nanoid();
  sqlite.prepare(`INSERT OR IGNORE INTO organizations VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(
    org1Id, "Irwin Downtown Association", "irwin-downtown", "downtown_assoc", "active", "pro",
    null, JSON.stringify({ primary: "#1e40af", secondary: "#3b82f6", accent: "#f59e0b" }),
    null, now, now
  );
  sqlite.prepare(`INSERT OR IGNORE INTO org_memberships VALUES (?,?,?,?,?,?)`).run(
    nanoid(), org1Id, userId, "admin", now, now
  );

  // Events
  const evData = [
    ["Irwin Car Cruise", "irwin-car-cruise", "festival", "2026-06-14", "10:00", "Main Street, Irwin PA", 500, 1, 0],
    ["Summer Street Market", "summer-street-market", "market", "2026-07-19", "09:00", "Pennsylvania Ave, Irwin PA", 200, 1, 0],
    ["Night Market", "night-market", "market", "2026-08-23", "18:00", "3rd Street, Irwin PA", 300, 0, 0],
    ["Meet Your Neighbor Dinner", "meet-your-neighbor-dinner", "dinner", "2026-09-20", "17:30", "Irwin Community Center", 100, 1, 1],
  ] as const;

  const eventIds: Record<string, string> = {};
  for (const [name, slug, type, date, time, loc, cap, feat, tick] of evData) {
    const eid = nanoid();
    eventIds[slug] = eid;
    sqlite.prepare(`INSERT OR IGNORE INTO events (id,org_id,name,slug,event_type,status,start_date,start_time,location,max_capacity,is_active,featured,is_ticketed,ticket_price,ticket_capacity,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      eid, org1Id, name, slug, type, "published", date, time, loc, cap, 1, feat, tick, tick ? 25 : null, tick ? cap : null, now, now
    );
  }

  // Vendors
  const vendorData = [
    ["Tony's BBQ Pit", "food", "tony@bbqpit.com"],
    ["Mountain Craft Co", "merchandise", "info@mountaincraft.com"],
    ["Sweet Treats Bakery", "food", "hello@sweettreats.com"],
    ["Vintage Vinyl Records", "merchandise", "shop@vintagevinyl.com"],
    ["Green Thumb Gardens", "merchandise", "grow@greenthumb.com"],
    ["Steel City Kettle Corn", "food", "pop@steelcitykettle.com"],
  ];
  const vendorIds: string[] = [];
  for (const [name, type, email] of vendorData) {
    const vid = nanoid();
    vendorIds.push(vid);
    sqlite.prepare(`INSERT OR IGNORE INTO vendors (id,org_id,name,vendor_type,email,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)`).run(
      vid, org1Id, name, type, email, "active", now, now
    );
  }

  // Assign vendors to Car Cruise
  const ccId = eventIds["irwin-car-cruise"];
  const statuses = ["confirmed", "confirmed", "pending", "confirmed"];
  const feeStatuses = ["paid", "paid", "pending", "paid"];
  for (let i = 0; i < 4; i++) {
    sqlite.prepare(`INSERT OR IGNORE INTO event_vendors (id,org_id,event_id,vendor_id,booth_number,fee_amount,fee_status,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
      nanoid(), org1Id, ccId, vendorIds[i], `B${i + 1}`, 75, feeStatuses[i], statuses[i], now, now
    );
  }

  // Sponsors
  const sponsorData = [
    ["First National Bank", "community@fnb.com", "https://fnb.com", "https://placehold.co/200x80/1e40af/white?text=FNB"],
    ["Irwin Auto Group", "sponsor@irwinauto.com", "https://irwinauto.com", "https://placehold.co/200x80/dc2626/white?text=Irwin+Auto"],
    ["Community Health Systems", "outreach@chs.org", "https://chs.org", "https://placehold.co/200x80/059669/white?text=CHS"],
    ["PA Power Co", "sponsors@papower.com", "https://papower.com", "https://placehold.co/200x80/7c3aed/white?text=PA+Power"],
    ["Downtown Realty", "info@downtownrealty.com", "https://downtownrealty.com", "https://placehold.co/200x80/ea580c/white?text=Downtown+Realty"],
  ];
  const sponsorIds: string[] = [];
  for (const [name, email, web, logo] of sponsorData) {
    const sid = nanoid();
    sponsorIds.push(sid);
    sqlite.prepare(`INSERT OR IGNORE INTO sponsors (id,org_id,name,email,website,logo_url,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
      sid, org1Id, name, email, web, logo, "active", now, now
    );
  }

  // Event sponsors with tiers
  const tierAssign = [
    { idx: 0, tier: "presenting", amount: 600, confirmed: true },
    { idx: 1, tier: "gold", amount: 400, confirmed: true },
    { idx: 2, tier: "gold", amount: 400, confirmed: true },
    { idx: 3, tier: "silver", amount: 200, confirmed: false },
    { idx: 4, tier: "silver", amount: 200, confirmed: false },
  ];
  for (const t of tierAssign) {
    const esId = nanoid();
    sqlite.prepare(`INSERT OR IGNORE INTO event_sponsors (id,org_id,event_id,sponsor_id,tier,amount_pledged,amount_received,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
      esId, org1Id, ccId, sponsorIds[t.idx], t.tier, t.amount, t.confirmed ? t.amount : 0, t.confirmed ? "confirmed" : "pending", now, now
    );
    if (t.confirmed) {
      sqlite.prepare(`INSERT OR IGNORE INTO payments (id,org_id,event_sponsor_id,event_id,description,amount,payment_method,payment_type,payment_category,status,paid_date,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        nanoid(), org1Id, esId, ccId, `${sponsorData[t.idx][0]} - ${t.tier} sponsorship`, t.amount, "check", "income", "sponsor", "received", now, now, now
      );
    }
  }

  // Sponsor tiers
  for (const [name, amt, ord, ben] of [
    ["presenting", 600, 0, "Logo on all materials, stage announcement, VIP area"],
    ["gold", 400, 1, "Logo on all materials, stage announcement"],
    ["silver", 200, 2, "Logo on event signage"],
    ["supporting", 100, 3, "Name in program"],
  ] as const) {
    sqlite.prepare(`INSERT OR IGNORE INTO sponsor_tiers (id,org_id,name,amount,sort_order,benefits,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)`).run(
      nanoid(), org1Id, name, amt, ord, ben, now, now
    );
  }

  // Site for Org 1
  const siteId = nanoid();
  sqlite.prepare(`INSERT OR IGNORE INTO sites (id,org_id,subdomain,theme,status,meta_title,meta_description,published_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
    siteId, org1Id, "irwin-downtown",
    JSON.stringify({ primaryColor: "#1e40af", secondaryColor: "#3b82f6", accentColor: "#f59e0b", fontHeading: "Inter", fontBody: "Inter" }),
    "published", "Irwin Downtown Association", "Bringing community together in Downtown Irwin, PA", now, now, now
  );

  // Pages + blocks
  const pages = [
    { title: "Home", slug: "home", type: "home", order: 0, blocks: [
      { type: "hero", content: { heading: "Welcome to Downtown Irwin", subheading: "Car cruises, street markets, community dinners — right here on Main Street.", ctaText: "View Events", ctaUrl: "/events" } },
      { type: "events_list", content: { display: "upcoming", limit: 3, layout: "cards" } },
      { type: "sponsors_grid", content: { tiers: "all", layout: "grid" } },
    ]},
    { title: "Events", slug: "events", type: "events", order: 1, blocks: [
      { type: "events_list", content: { display: "all", limit: 20, layout: "cards" } },
    ]},
    { title: "Sponsors", slug: "sponsors", type: "sponsors", order: 2, blocks: [
      { type: "sponsors_grid", content: { tiers: "all", layout: "grid" } },
    ]},
    { title: "Contact", slug: "contact", type: "contact", order: 3, blocks: [
      { type: "contact_form", content: { fields: ["name", "email", "message"], successMessage: "Thanks! We'll be in touch." } },
    ]},
  ];

  for (const page of pages) {
    const pageId = nanoid();
    sqlite.prepare(`INSERT OR IGNORE INTO site_pages (id,org_id,site_id,title,slug,page_type,is_published,sort_order,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
      pageId, org1Id, siteId, page.title, page.slug, page.type, 1, page.order, now, now
    );
    for (let i = 0; i < page.blocks.length; i++) {
      sqlite.prepare(`INSERT OR IGNORE INTO site_blocks (id,org_id,page_id,block_type,content,sort_order,is_visible,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
        nanoid(), org1Id, pageId, page.blocks[i].type, JSON.stringify(page.blocks[i].content), i, 1, now, now
      );
    }
    sqlite.prepare(`INSERT OR IGNORE INTO site_nav_items (id,org_id,site_id,label,page_id,sort_order,is_visible,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
      nanoid(), org1Id, siteId, page.title, pageId, page.order, 1, now, now
    );
  }

  // ---- Org 2: Light Up Norwin ----
  const org2Id = nanoid();
  sqlite.prepare(`INSERT OR IGNORE INTO organizations VALUES (?,?,?,?,?,?,?,?,?,?,?)`).run(
    org2Id, "Light Up Norwin", "light-up-norwin", "festival_committee", "active", "starter",
    null, JSON.stringify({ primary: "#dc2626", secondary: "#b91c1c", accent: "#22c55e" }),
    null, now, now
  );
  sqlite.prepare(`INSERT OR IGNORE INTO org_memberships VALUES (?,?,?,?,?,?)`).run(
    nanoid(), org2Id, userId, "admin", now, now
  );

  sqlite.prepare(`INSERT OR IGNORE INTO events (id,org_id,name,slug,event_type,status,start_date,start_time,location,max_capacity,is_active,featured,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    nanoid(), org2Id, "Light Up Norwin Festival", "light-up-norwin-festival", "festival", "published", "2026-12-05", "17:00", "Norwin Town Center", 1000, 1, 1, now, now
  );

  const site2Id = nanoid();
  sqlite.prepare(`INSERT OR IGNORE INTO sites (id,org_id,subdomain,theme,status,meta_title,published_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
    site2Id, org2Id, "light-up-norwin",
    JSON.stringify({ primaryColor: "#dc2626", secondaryColor: "#b91c1c", accentColor: "#22c55e", fontHeading: "Inter", fontBody: "Inter" }),
    "published", "Light Up Norwin", now, now, now
  );

  const home2Id = nanoid();
  sqlite.prepare(`INSERT OR IGNORE INTO site_pages (id,org_id,site_id,title,slug,page_type,is_published,sort_order,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)`).run(
    home2Id, org2Id, site2Id, "Home", "home", "home", 1, 0, now, now
  );
  sqlite.prepare(`INSERT OR IGNORE INTO site_blocks (id,org_id,page_id,block_type,content,sort_order,is_visible,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
    nanoid(), org2Id, home2Id, "hero",
    JSON.stringify({ heading: "Light Up Norwin", subheading: "Celebrating the holiday season with light, music, and community.", ctaText: "Learn More", ctaUrl: "/events" }),
    0, 1, now, now
  );
  sqlite.prepare(`INSERT OR IGNORE INTO site_blocks (id,org_id,page_id,block_type,content,sort_order,is_visible,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
    nanoid(), org2Id, home2Id, "events_list",
    JSON.stringify({ display: "upcoming", limit: 5, layout: "cards" }),
    1, 1, now, now
  );
  sqlite.prepare(`INSERT OR IGNORE INTO site_nav_items (id,org_id,site_id,label,page_id,sort_order,is_visible,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)`).run(
    nanoid(), org2Id, site2Id, "Home", home2Id, 0, 1, now, now
  );

  console.log("\n✅ Database seeded successfully!");
  console.log("\n  Demo login:  demo@civicops.com / demo1234");
  console.log("  Org 1:       Irwin Downtown Association (irwin-downtown)");
  console.log("  Org 2:       Light Up Norwin (light-up-norwin)");
  console.log("  Public:      /o/irwin-downtown  |  /o/light-up-norwin");
}

seed().catch(console.error);
