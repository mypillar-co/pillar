# Phase 1: SaaS Architecture Design
## Discover Irwin → Multi-Tenant Operations Platform

---

## 1. CORE DATA OBJECTS

These are the fundamental entities the system manages. Everything hangs off an **Organization**.

### Tier 1 — Tenant Root
| Object | Purpose |
|---|---|
| **Organization** | The tenant. A chamber, nonprofit, festival committee, etc. |

### Tier 2 — People & Access
| Object | Purpose |
|---|---|
| **User** | A person with login credentials. Can belong to multiple orgs. |
| **OrgMembership** | Links a User to an Organization with a specific role. |

### Tier 3 — Core Operations
| Object | Purpose |
|---|---|
| **Event** | A thing that happens — festival, mixer, fundraiser, meeting. |
| **Vendor** | A business or individual that provides goods/services to events. |
| **Sponsor** | A business or individual that provides funding/support. |
| **Contact** | A person record (attendee, vendor rep, sponsor contact, general). Shared across modules within an org. |

### Tier 4 — Transactional / Tracking
| Object | Purpose |
|---|---|
| **Registration** | Someone signed up for an event (links Contact → Event). |
| **Payment** | A record of money expected, received, or outstanding. Not processing — just tracking. |
| **Document** | A file or link attached to any entity (contracts, permits, invoices, logos). |
| **EmailTemplate** | Reusable email content tied to an org. |
| **EmailLog** | Record of emails sent (who, when, what template, which entity). |

### Tier 5 — Configuration
| Object | Purpose |
|---|---|
| **Tag** | Flexible labeling system for any entity (e.g., "2025", "Food Vendor", "Gold Sponsor"). |
| **CustomField** | Org-defined extra fields on core objects (keeps schema clean while allowing flexibility). |

---

## 2. RELATIONSHIPS BETWEEN OBJECTS

```
Organization (tenant root)
├── Users (via OrgMembership)
├── Events
│   ├── Registrations → Contact
│   ├── EventVendors → Vendor (with booth/assignment details)
│   ├── EventSponsors → Sponsor (with tier/benefits details)
│   ├── Payments (event-scoped)
│   ├── Documents (event-scoped)
│   └── EmailLogs
├── Vendors (org-level pool)
│   ├── Contacts (vendor reps)
│   ├── Documents
│   └── Payments
├── Sponsors (org-level pool)
│   ├── Contacts (sponsor reps)
│   ├── Documents
│   └── Payments
├── Contacts (org-level people directory)
├── Documents (org-level, or attached to specific entities)
├── EmailTemplates
├── Tags
└── CustomFields
```

### Key Relationship Patterns

**Organization scopes everything.** Every query includes `org_id`. No data leaks between tenants.

**Vendors and Sponsors are org-level pools.** They exist independent of events — you might work with the same food truck vendor across 10 events. The `EventVendor` and `EventSponsor` junction tables track the per-event relationship (booth number, sponsorship tier, amount, status).

**Contacts are shared within an org.** One person might be a vendor rep AND a sponsor contact AND an event registrant. One Contact record, multiple relationships.

**Payments attach to multiple parent types.** A payment can be linked to a Registration (attendee fee), an EventVendor (booth fee), an EventSponsor (sponsorship pledge), or standalone. Uses a polymorphic `payment_type` + `parent_id` pattern — or better, explicit nullable FKs for clarity.

**Documents are polymorphic.** Can attach to Events, Vendors, Sponsors, Contacts, or be org-level. Same pattern as Payments.

---

## 3. REQUIRED DATABASE TABLES

### Tenant & Access

```sql
-- The tenant
organizations
  id              UUID PRIMARY KEY
  name            VARCHAR(255) NOT NULL
  slug            VARCHAR(100) UNIQUE NOT NULL  -- subdomain or URL slug
  status          VARCHAR(20) DEFAULT 'active'  -- active, suspended, trial
  plan            VARCHAR(50) DEFAULT 'free'    -- for future billing tiers
  settings        JSONB DEFAULT '{}'            -- org-level config
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- People who can log in
users
  id              UUID PRIMARY KEY
  email           VARCHAR(255) UNIQUE NOT NULL
  password_hash   VARCHAR(255) NOT NULL
  first_name      VARCHAR(100)
  last_name       VARCHAR(100)
  is_superadmin   BOOLEAN DEFAULT FALSE         -- platform-level admin (you)
  last_login_at   TIMESTAMPTZ
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Links users to orgs with roles
org_memberships
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  user_id         UUID NOT NULL REFERENCES users(id)
  role            VARCHAR(20) NOT NULL          -- 'admin', 'staff', 'viewer'
  created_at      TIMESTAMPTZ DEFAULT NOW()
  UNIQUE(org_id, user_id)
```

### Core Operations

```sql
-- Events
events
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  name            VARCHAR(255) NOT NULL
  description     TEXT
  event_type      VARCHAR(50)                   -- festival, mixer, fundraiser, meeting, etc.
  status          VARCHAR(20) DEFAULT 'draft'   -- draft, published, active, completed, cancelled
  start_date      DATE
  end_date        DATE
  start_time      TIME
  end_time        TIME
  location        VARCHAR(255)
  max_capacity    INTEGER
  settings        JSONB DEFAULT '{}'
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Contacts (shared people directory within an org)
contacts
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  first_name      VARCHAR(100) NOT NULL
  last_name       VARCHAR(100)
  email           VARCHAR(255)
  phone           VARCHAR(50)
  company         VARCHAR(255)
  contact_type    VARCHAR(20)                   -- general, vendor_rep, sponsor_rep, attendee (informational)
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Vendors (org-level pool)
vendors
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  name            VARCHAR(255) NOT NULL
  contact_id      UUID REFERENCES contacts(id)  -- primary contact person
  vendor_type     VARCHAR(50)                   -- food, merchandise, entertainment, service, etc.
  email           VARCHAR(255)
  phone           VARCHAR(50)
  status          VARCHAR(20) DEFAULT 'active'  -- active, inactive, blacklisted
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Sponsors (org-level pool)
sponsors
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  name            VARCHAR(255) NOT NULL
  contact_id      UUID REFERENCES contacts(id)  -- primary contact person
  email           VARCHAR(255)
  phone           VARCHAR(50)
  status          VARCHAR(20) DEFAULT 'active'
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()
```

### Junction / Per-Event Relationships

```sql
-- Vendor assigned to a specific event
event_vendors
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  event_id        UUID NOT NULL REFERENCES events(id)
  vendor_id       UUID NOT NULL REFERENCES vendors(id)
  booth_number    VARCHAR(50)
  booth_location  VARCHAR(255)
  fee_amount      DECIMAL(10,2)
  fee_status      VARCHAR(20) DEFAULT 'pending' -- pending, paid, waived, overdue
  status          VARCHAR(20) DEFAULT 'invited' -- invited, confirmed, declined, cancelled
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()
  UNIQUE(event_id, vendor_id)

-- Sponsor supporting a specific event
event_sponsors
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  event_id        UUID NOT NULL REFERENCES events(id)
  sponsor_id      UUID NOT NULL REFERENCES sponsors(id)
  tier            VARCHAR(50)                   -- gold, silver, bronze, in-kind, custom
  amount_pledged  DECIMAL(10,2)
  amount_received DECIMAL(10,2) DEFAULT 0
  benefits        TEXT                          -- what they get (logo placement, booth, etc.)
  status          VARCHAR(20) DEFAULT 'pending' -- pending, confirmed, declined, fulfilled
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()
  UNIQUE(event_id, sponsor_id)

-- Event registrations
registrations
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  event_id        UUID NOT NULL REFERENCES events(id)
  contact_id      UUID NOT NULL REFERENCES contacts(id)
  registration_type VARCHAR(50)                 -- general, vip, volunteer, speaker
  status          VARCHAR(20) DEFAULT 'registered' -- registered, confirmed, attended, cancelled, no-show
  fee_amount      DECIMAL(10,2)
  fee_status      VARCHAR(20) DEFAULT 'pending' -- pending, paid, waived, refunded
  registered_at   TIMESTAMPTZ DEFAULT NOW()
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()
```

### Tracking Tables

```sql
-- Payment tracking (not processing)
payments
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  -- Polymorphic parent: exactly one of these should be set
  event_vendor_id UUID REFERENCES event_vendors(id)
  event_sponsor_id UUID REFERENCES event_sponsors(id)
  registration_id UUID REFERENCES registrations(id)
  -- If none of the above, it's a standalone org-level payment
  description     VARCHAR(255) NOT NULL
  amount          DECIMAL(10,2) NOT NULL
  payment_method  VARCHAR(50)                   -- cash, check, square, paypal, invoice, other
  payment_type    VARCHAR(20) NOT NULL          -- income, expense
  status          VARCHAR(20) DEFAULT 'pending' -- pending, received, sent, overdue, cancelled
  due_date        DATE
  paid_date       DATE
  reference_number VARCHAR(100)                 -- check #, Square transaction ID, invoice #
  notes           TEXT
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Documents (files attached to any entity)
documents
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  -- Polymorphic parent
  event_id        UUID REFERENCES events(id)
  vendor_id       UUID REFERENCES vendors(id)
  sponsor_id      UUID REFERENCES sponsors(id)
  contact_id      UUID REFERENCES contacts(id)
  -- If all null, it's an org-level document
  name            VARCHAR(255) NOT NULL
  file_url        VARCHAR(500)                  -- S3 URL or similar
  file_type       VARCHAR(50)                   -- pdf, docx, png, etc.
  file_size       INTEGER                       -- bytes
  doc_category    VARCHAR(50)                   -- contract, permit, invoice, logo, insurance, other
  notes           TEXT
  uploaded_by     UUID REFERENCES users(id)
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Email templates (per org)
email_templates
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  name            VARCHAR(255) NOT NULL
  subject         VARCHAR(255) NOT NULL
  body            TEXT NOT NULL                  -- supports merge tags like {{contact.first_name}}
  template_type   VARCHAR(50)                   -- vendor_invite, sponsor_thank_you, registration_confirm, etc.
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Email send log
email_logs
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  template_id     UUID REFERENCES email_templates(id)
  sent_to_email   VARCHAR(255) NOT NULL
  sent_to_contact UUID REFERENCES contacts(id)
  subject         VARCHAR(255)
  body            TEXT
  status          VARCHAR(20) DEFAULT 'sent'    -- sent, failed, bounced
  -- Context: what entity triggered this email
  event_id        UUID REFERENCES events(id)
  sent_by         UUID REFERENCES users(id)
  sent_at         TIMESTAMPTZ DEFAULT NOW()
  created_at      TIMESTAMPTZ DEFAULT NOW()
```

### Flexibility Layer

```sql
-- Tags (flexible labeling)
tags
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  name            VARCHAR(100) NOT NULL
  color           VARCHAR(7)                    -- hex color for UI
  UNIQUE(org_id, name)

-- Tag assignments (polymorphic)
taggings
  id              UUID PRIMARY KEY
  tag_id          UUID NOT NULL REFERENCES tags(id)
  taggable_type   VARCHAR(50) NOT NULL          -- 'event', 'vendor', 'sponsor', 'contact'
  taggable_id     UUID NOT NULL
  UNIQUE(tag_id, taggable_type, taggable_id)

-- Custom fields (org-defined extra fields)
custom_fields
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  entity_type     VARCHAR(50) NOT NULL          -- 'event', 'vendor', 'sponsor', 'contact', 'registration'
  field_name      VARCHAR(100) NOT NULL
  field_type      VARCHAR(20) NOT NULL          -- text, number, date, boolean, select
  options         JSONB                         -- for select type: ["Option A", "Option B"]
  is_required     BOOLEAN DEFAULT FALSE
  sort_order      INTEGER DEFAULT 0
  UNIQUE(org_id, entity_type, field_name)

-- Custom field values
custom_field_values
  id              UUID PRIMARY KEY
  custom_field_id UUID NOT NULL REFERENCES custom_fields(id)
  entity_id       UUID NOT NULL                 -- the record this value belongs to
  value           TEXT                          -- stored as text, cast by field_type
  UNIQUE(custom_field_id, entity_id)
```

---

## 4. MVP FEATURE SCOPE

### Must Have (Phase 1 — Launch)

| Module | Features |
|---|---|
| **Auth & Tenancy** | Sign up, login, org creation, org switching, invite users to org |
| **Org Settings** | Name, slug, basic config |
| **Roles** | Admin (full access), Staff (create/edit), Viewer (read-only) |
| **Events** | CRUD events, list/filter, status management |
| **Contacts** | CRUD contacts, search, basic dedup |
| **Vendors** | CRUD vendors, assign to events, track booth/fees/status |
| **Sponsors** | CRUD sponsors, assign to events, track tier/amount/status |
| **Registrations** | CRUD registrations per event, link to contacts |
| **Payments** | Log payments against vendors/sponsors/registrations, track status |
| **Documents** | Upload/attach files to any entity |
| **Dashboard** | Org-level: upcoming events, outstanding payments, recent activity |

### Should Have (Phase 2)

| Module | Features |
|---|---|
| **Email Templates** | Create/manage templates with merge tags |
| **Email Sending** | Send from templates to contacts, log history |
| **Event Dashboard** | Per-event: vendor status, sponsor status, registration count, financials |
| **Reporting** | Payment summaries, event financials, vendor/sponsor history |
| **Tags** | Flexible tagging on all entities |
| **Custom Fields** | Org-defined fields on core entities |

### Nice to Have (Phase 3+)

| Module | Features |
|---|---|
| **Public Registration Forms** | Shareable event registration (replaces Jotform) |
| **Vendor Applications** | Public vendor application forms per event |
| **Sponsor Packages** | Defined tiers with benefits tracking |
| **Audit Log** | Who changed what, when |
| **Billing/Plans** | Subscription management for orgs |
| **API** | Public API for integrations |

---

## 5. REFACTORING FROM EXISTING IBPA PLATFORM

### What to Keep
- **Domain knowledge**: Your understanding of the workflow (event → vendor → sponsor → payment cycle) is the product. The schema above is modeled on exactly how these orgs actually work.
- **Existing data**: Plan a migration script. Map current tables → new schema with `org_id` injected everywhere.
- **Business logic**: Any validation rules, status flows, or automation you've built — port it.

### What to Change

| Current (Single-Tenant) | SaaS (Multi-Tenant) |
|---|---|
| No org concept — data is global | Every table has `org_id`, every query filters by it |
| Users are system-wide | Users exist globally but access is scoped via `org_memberships` |
| Probably shared vendor/sponsor lists | Vendors/sponsors are per-org (orgs don't see each other's data) |
| Direct DB access patterns | All access goes through org-scoped service layer |
| Single admin model | Role-based: admin/staff/viewer per org |
| Hardcoded config | Org-level settings (JSONB `settings` column) |

### Migration Strategy

1. **Create the Organization**: Your current IBPA becomes `org_id = 1` (or a UUID).
2. **Add `org_id` to all existing tables**: Backfill with your org's ID.
3. **Add `org_memberships`**: Existing users get `admin` role on your org.
4. **Enforce org scoping**: Middleware/service layer that injects `org_id` into every query.
5. **Test isolation**: Create a second test org, verify zero data leakage.

### Architecture Pattern

```
Request → Auth Middleware → Org Resolution → Service Layer → Database
                              ↓
                    (from JWT claim, subdomain,
                     or session — sets org_id
                     for entire request lifecycle)
```

Every service method signature looks like:
```
getEvents(orgId, filters)
createVendor(orgId, data)
getPayments(orgId, eventId?, filters)
```

No method ever operates without `orgId`. This is the **single most important architectural rule**.

---

## ARCHITECTURE PRINCIPLES

1. **Org ID everywhere.** It's the partition key for the entire system.
2. **Explicit nullable FKs over polymorphic strings** where practical. The payments and documents tables use nullable FKs — more verbose but the database enforces integrity.
3. **JSONB for settings, not for core data.** Org settings, event config = JSONB. Vendor names, payment amounts = real columns.
4. **Status fields are enums in code, varchars in DB.** Easier to evolve without migrations.
5. **Soft conventions over hard abstractions.** No inheritance, no complex type systems. Just tables with clear relationships.
6. **UUID primary keys.** Safe for multi-tenant, no sequential ID leakage, merge-friendly.
