# Shark Tank Analysis
## Would This Get Funded? What Would They Ask? What Should You Charge?

---

## THE PITCH (60 Seconds)

> "There are over 7,000 chambers of commerce, 15,000 downtown associations, 1.5 million nonprofits, and tens of thousands of festival committees, lodges, and civic organizations in America. Almost all of them manage events. Almost none of them have real software.
>
> They use Google Sheets for vendor tracking, JotForm for applications, Square exports they manually reconcile, and a website from 2017 they can't update. I know because I built exactly that system for my own organization — and it works. But it took me a year and 3,200 lines of custom code.
>
> Our platform lets any local organization talk to an AI, build their website in 15 minutes, and manage their events, vendors, sponsors, and payments from one dashboard. No spreadsheets. No JotForm. No calling a web designer.
>
> We're Wix meets Monday.com, built specifically for local civic organizations. And we have a working prototype running real events in Downtown Irwin, Pennsylvania right now."

---

## THE SHARKS' QUESTIONS (And Your Answers)

### Mark Cuban: "What's your revenue?"

**Honest answer:** Zero. This is pre-revenue. The existing system runs one organization (yours) for free.

**What he actually wants to hear:** You have a working product managing real events with real vendors and real money flowing through it. That's more than most Shark Tank pitches. The gap is: have you sold it to anyone else?

**Your counter:** "We haven't charged anyone yet, but we've run [X] events, tracked [Y] vendors, processed [Z] in payment tracking, and managed [N] sponsors through the system. We know it works because we use it every day. The SaaS version is what we're building now."

**Verdict:** Cuban would be skeptical on zero revenue but interested in the AI angle and the market gap. He'd want to see you sign 10 paying customers before he'd write a check.

---

### Barbara Corcoran: "How do you get customers?"

**This is your strongest and weakest point simultaneously.**

**Strong:** Your customers literally meet each other. Chambers of commerce attend state chamber conferences. Downtown associations have a national organization (NMSC). Festival committees talk to neighboring festival committees. **Word of mouth in this market is nuclear** — one chamber tells another, who tells another. The ACCE (Association of Chamber of Commerce Executives) has conferences where every chamber in the country sends people.

**Weak:** You're one person. You don't have a sales team. These organizations make decisions by committee. Sales cycles can be slow.

**Your play:**
1. Free tier gets them in the door (AI builds their site in 15 minutes — instant value)
2. They upgrade when they need vendor/sponsor/payment tracking
3. You present at state chamber conferences and downtown association meetings
4. Your existing Discover Irwin becomes the demo: "Look at what this does for us in Irwin"

**Barbara would say:** "I love that your customers are all in the same rooms together. But you need to get 10 of them using it before you can sell the story."

---

### Kevin O'Leary: "What's my return? What would you charge?"

Here's the competitive landscape and pricing analysis:

#### The Competition

| Competitor | What They Do | Price | Weakness |
|---|---|---|---|
| **ChamberMaster/GrowthZone** | Chamber management (member directories, dues, CRM) | $300-600/mo+ (enterprise sales, demo required) | Expensive, complex, focused on MEMBER management not EVENT operations. 3,000+ chambers use it. |
| **MemberClicks** | Association management | $3,500-4,500/year ($290-375/mo) | Same problem — built for membership orgs, not event operations. No AI. |
| **WildApricot** | Membership + website builder | $60-150/mo (by contact count) | 15,000 orgs use it. Closest competitor. But website builder is dated, no AI, no vendor/sponsor management. |
| **Eventbrite** | Ticketing + discovery | 3.7% + $1.79/ticket | Great for ticketing, terrible for operations. No vendor tracking, no sponsor management, no org dashboard. |
| **Monday.com** | General project management | $36-72/mo (3+ seats) | Too generic. Orgs have to build their own workflows from scratch. |
| **Wix** | Website builder | $17-159/mo | Website only. No event ops, no vendor management, no org-specific features. |
| **Squarespace** | Website builder | $16-52/mo | Same as Wix. Pretty sites, zero operations. |

#### The Gap You're Filling

Nobody does **website + event operations** for **small local civic orgs** at **an affordable price** with **AI-driven setup**.

- ChamberMaster/GrowthZone = right market, wrong product (member management, not event ops), wrong price ($300-600/mo)
- WildApricot = right price range, partially right product, but no AI and weak on event operations
- Eventbrite = right on events, but ticketing only — no vendor/sponsor/payment operations
- Wix/Squarespace = right on website, zero on operations

**You're filling the gap between WildApricot (membership-focused, no AI) and Monday.com (powerful but generic).** Website builder + event operations + AI setup, purpose-built for civic orgs.

#### What To Charge

| Tier | Price | Target | Justification |
|---|---|---|---|
| **Free** | $0 | Tiny orgs just wanting a basic site | 1 event, basic site, no custom domain. Gets them in. Limits: 50 contacts, 1 active event. |
| **Starter** | **$39/mo** ($29/mo annual) | Small chamber or downtown association | Unlimited events, full AI site builder, vendor tracking, sponsor tracking, custom domain. Up to 3 users. |
| **Pro** | **$89/mo** ($69/mo annual) | Active festival committee or larger chamber | Everything in Starter + payment tracking, email automation, document management, reporting, unlimited users. |
| **Organization** | **$149/mo** ($119/mo annual) | Multi-event orgs running 10+ events/year | Everything in Pro + API access, advanced reporting, priority support, custom branding removal. |

**Why this pricing:**
- WildApricot charges $60-150/mo and has 15,000 customers. You're in that range but offer more (AI builder, event ops).
- ChamberMaster charges $300-600/mo. You're dramatically cheaper and more accessible.
- MemberClicks charges $290-375/mo. Same — you're the affordable alternative.
- These orgs typically have annual budgets of $50K-500K. $39-149/mo is a rounding error in their budget. It's less than their JotForm subscription + website hosting + email tool combined.

**O'Leary's math:**
- 500 paying customers at avg $65/mo = $390,000 ARR
- 2,000 customers at avg $65/mo = $1.56M ARR
- 5,000 customers at avg $65/mo = $3.9M ARR
- SaaS valuations at 5-10x revenue = $7.5M-$39M company at 5,000 customers

---

### Lori Greiner: "Is this a product or a business?"

**This is the real question.**

Right now it's a project. One person, one org, zero revenue. To be a business it needs:

1. **10 paying customers** — Proves people will pay for this
2. **Repeatable onboarding** — The AI does the work, not you personally
3. **Low churn** — Once an org sets up their events, vendors, and site, they're locked in (data gravity)
4. **Clear unit economics** — Cost per org < revenue per org

**Good news:** SaaS for civic orgs has excellent unit economics.

| Cost Item | Per Org / Month |
|---|---|
| Hosting (Vercel/Railway) | ~$0.50-2.00 |
| Database (Postgres) | ~$0.10-1.00 |
| File storage (R2/S3) | ~$0.10-0.50 |
| Email (SendGrid) | ~$0.50-2.00 |
| AI tokens (site builder) | ~$0.50-3.00 (heavy at setup, minimal ongoing) |
| **Total cost per org** | **~$2-8/mo** |
| **Revenue per org** | **$39-149/mo** |
| **Gross margin** | **~90-95%** |

That's SaaS-standard gross margins. The AI cost is front-loaded (building the site) and drops to near-zero once they're set up.

---

### Robert Herjavec: "Who are you and why can you do this?"

**Your unfair advantages:**

1. **You ARE the customer.** You run a real civic org. You know exactly what they need because you need it yourself. This isn't some Silicon Valley team guessing what a chamber of commerce wants.

2. **You built a working system.** 3,200 lines of backend, 4,750 lines of frontend, running real events in production. This isn't a pitch deck — it's a product.

3. **The "Replicating for Another Organization" section of your own docs lists 16 manual steps.** That IS the product spec. You've already identified exactly what needs to be automated.

4. **AI timing.** Two years ago, "talk to an AI and it builds your website" was science fiction. Today it's buildable. You're hitting the market at exactly the right moment.

**Your disadvantage:** You're one person. Sharks want to know who's building this with you and whether you can scale.

---

## HONEST ASSESSMENT: IS THIS VIABLE?

### YES, but with caveats.

**Why it's viable:**

1. **The market exists and it's huge.** ~7,000 chambers of commerce, ~15,000+ downtown/main street organizations, ~1.5M nonprofits (many run events), plus lodges (Elks: 1,800 lodges, Moose: 1,600, Eagles: 1,500, VFW: 6,000), festival committees (thousands). Even the narrow slice — civic orgs that run public events — is 50,000+ organizations in the US.

2. **The competition is either too expensive or too generic.** ChamberMaster/GrowthZone own the chamber market but charge $300-600/mo for member management, not event ops. WildApricot is affordable but dated and not event-focused. Eventbrite is ticketing only. Nobody does what you're describing at your price point.

3. **The pain is real and quantifiable.** These orgs currently spend:
   - $30-50/mo on JotForm
   - $15-45/mo on website hosting (Wix/Squarespace/GoDaddy)
   - $20-50/mo on email tools (Mailchimp/Constant Contact)
   - ~$0 on "vendor tracking" because they use free Google Sheets
   - ~$0 on "payment tracking" because they manually check Square
   - 10-20 hours/month of admin time reconciling all of this
   - Total: $65-145/mo in tools + massive time waste
   - Your $39-89/mo replaces ALL of it. That's an easy sell.

4. **AI is the differentiator that makes this possible now.** Without AI, you'd need to build a Wix-like drag-and-drop editor — that's a $10M product. With AI, you need a block system and a good prompt. The AI does the design work. The cost of the core feature just dropped 100x.

5. **Data gravity = low churn.** Once an org puts their 40 vendors, 15 sponsors, and 8 events into your system, they're not leaving. This is their operational backbone. SaaS churn in this segment is typically 3-5% monthly for bad products, <1% for good ones. You'd be in the <2% range because the switching cost is high.

**Why it's risky:**

1. **You're one person.** Building a SaaS product, doing sales, doing support, doing marketing — that's 4 full-time jobs. You need help or you need to be very focused on what you build first.

2. **Sales cycle with committees.** These orgs often make decisions by board vote. That can mean 30-90 day sales cycles. Free tier + AI onboarding helps — they can try it without a board vote, then upgrade when they're hooked.

3. **"Good enough" inertia.** Google Sheets works for them. It's free. It's painful but familiar. You have to show them the pain before they'll pay for the cure. Your existing Irwin dashboard is the "before/after" demo.

4. **AI hype fatigue.** "AI builds your website" might sound like every other AI product claim in 2026. You need to show it actually working, not just talk about it.

---

## WHAT THE SHARKS WOULD WANT BEFORE WRITING A CHECK

| # | Requirement | Why |
|---|---|---|
| 1 | **10 paying customers** | Proves someone other than you will pay for this |
| 2 | **Working multi-tenant product** | Not just architecture docs — a real product |
| 3 | **AI site builder demo** | The "wow moment" — watch an org get built in real-time |
| 4 | **Customer acquisition cost (CAC)** | How much does it cost to get one org signed up? |
| 5 | **Monthly churn rate** | Are they staying? |
| 6 | **Your first 100 target list** | Named orgs you're going to sell to, with a plan for each |

**The realistic ask:** $150K-250K for 15-20% equity. Use it for: 6 months of runway to get to 50 paying customers, one part-time developer, and conference circuit marketing.

**The realistic valuation:** Pre-revenue SaaS with a working prototype and domain expertise = $500K-$1M pre-money. After 50 customers at $65/mo avg = ~$39K ARR, you could reasonably value at $1.5-3M.

---

## THE 90-DAY PLAN TO BE "SHARK TANK READY"

| Week | Action | Goal |
|---|---|---|
| 1-2 | Build marketing site + waitlist | Start collecting leads |
| 3-4 | Build MVP platform (auth, events, vendors, sponsors, basic dashboard) | Functional product |
| 5-6 | Build AI site builder | The demo-able "wow" feature |
| 7-8 | Migrate IBPA as first tenant | Prove it works in production |
| 9-10 | Sign up 5 orgs (free tier) from your network | Real users, real feedback |
| 11-12 | Convert 3+ to paid, collect testimonials | Revenue + social proof |

**Your cheat code:** You already know people in this world. Every chamber you've worked with, every downtown association you've coordinated events with, every org that saw Discover Irwin and said "I wish we had that" — that's your first 10 customers.

---

## BOTTOM LINE

**Is this a $100M company?** Probably not. The market is large but fragmented, and these orgs don't spend a lot on software.

**Is this a $5-20M ARR company?** Absolutely. 3,000-10,000 orgs at $50-100/mo average is $1.8M-$12M ARR. ChamberMaster has 3,000+ chambers. WildApricot has 15,000+ orgs. The market supports this.

**Is it fundable?** Yes, but not at the pitch-deck stage. Build the product, get 10 paying customers, then you have a real story. The good news: you can build this for nearly zero dollars (your time is the cost) and start charging within 90 days.

**What a Shark would actually say:**

> *Cuban:* "I like that you built this for yourself and it works. But you're pre-revenue and you're one person. Come back when you have 50 paying customers and I'll write you a check."
>
> *Barbara:* "I LOVE this market. These organizations are desperate and they all know each other. But honey, you need to actually sell it to 10 of them before I'd invest."
>
> *O'Leary:* "Here's what I'd offer — $200K as a royalty deal. I get $2 per org per month until I recoup $400K, then $1 per org per month in perpetuity. Because you haven't proven you can sell this yet."
>
> *Lori:* "This isn't a product I can put on QVC." *Goes out.*
>
> *Robert:* "I've built SaaS companies. The economics work. But the question is whether you can sell to committees that take 90 days to make a decision. I'll do $200K for 20%, and I'll open doors to every chamber of commerce in my network."

**The honest Shark Tank outcome:** You'd get interest from 2-3 sharks, the deal would hinge on you proving sales traction within 6 months, and the valuation would be modest ($750K-$1.5M) because you're pre-revenue. That's fine. The point isn't to maximize valuation on day one — it's to build something real.
