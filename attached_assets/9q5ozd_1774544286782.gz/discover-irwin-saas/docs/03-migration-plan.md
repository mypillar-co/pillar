# Existing System Analysis & Migration Plan
## From: Single-Tenant Google Sheets Dashboard → Multi-Tenant SaaS Platform

---

## CURRENT STATE SUMMARY

### What You Actually Built

A **3,200-line Express server** + **4,750-line monolithic HTML SPA** that uses Google Sheets as a database, Google Drive as file storage, Google Apps Script as a write layer, JotForm for intake, and SendGrid for email. All hardcoded to one organization (IBPA/Discover Irwin).

It works. But it's held together with duct tape and hardcoded IDs.

### The Real Architecture (Today)

```
JotForm (vendor/sponsor intake)
    ↓ (API polling)
Google Sheets ← Apps Script (all writes)
    ↓ (GViz CSV / Sheets API reads)
Express Server (server.js — 3,200 lines)
    ↓ (serves HTML + JSON APIs)
Dashboard SPA (dashboard.html — 4,750 lines, vanilla JS)
    ↓
SendGrid (email)
Google Drive (sponsor logos)
Square (payment export — read only)
discoverirwin.com (bidirectional event/ticket sync)
```

### What Makes This Hard to Replicate

Your own "Replicating for Another Organization" section lists **16 things you'd have to manually change**. That's the problem statement right there. Every new org means:

- New Google Sheet (copy structure)
- New Drive folders (3 sponsor tiers)
- New Apps Script deployment
- New JotForm forms (3 sponsor tiers)
- New OAuth credentials
- New env vars
- Edit hardcoded values in server.js
- Edit branding in HTML

**That's not SaaS. That's a franchise kit.** The goal is: org signs up → talks to AI → site + dashboard ready. Zero manual setup.

---

## WHAT TO KEEP vs REPLACE vs REFACTOR

### KEEP (Domain Logic — This Is Your IP)

These patterns are battle-tested. They represent real workflow knowledge:

| What | Where | Why It Matters |
|---|---|---|
| Vendor approval flow | `setVendorApproval` | Pending → Approved/Rejected with email notification |
| Vendor document tracking | ServSafe + Insurance columns | Automated reminder system with urgency escalation |
| Sponsor 3-phase collection | `fetchSponsorCandidates()` | Drive scan → JotForm cross-ref → Sheet cross-ref |
| Sponsor per-event composite keys | `companyName\|\|event` | Prevents cross-event approval bleed |
| Payment categorization | `categorizePaymentServer()` | Keyword-based description parsing |
| Payment event attribution | Overrides → tags → reference_id → default | Smart fallback chain |
| Auto-archive logic | 30 days after event month | Event lifecycle management |
| Sponsor tier amounts | Presenting: 600, Gold: 400, Silver: 200 | Per-org configurable in SaaS |
| Auto check payment creation | On sponsor approval without Square payment | Reduces manual entry |
| Document reminder escalation | 7 days normal → 1 day when <7 days to event | Smart urgency |
| Ticket sync bidirectional | Dashboard ↔ Website | Real-time capacity tracking |

### REPLACE (Infrastructure — Google Sheets Is Not a Database)

| Current | Replace With | Why |
|---|---|---|
| Google Sheets (data store) | PostgreSQL | Real queries, real indexes, real constraints, multi-tenant |
| Google Apps Script (write layer) | Direct DB writes via API | Eliminate the middleman entirely |
| Google Drive (sponsor logos) | S3/R2 + media table | Per-org media library, no shared Google account needed |
| JotForm (intake forms) | Built-in form system | Public registration/vendor/sponsor forms as site blocks |
| GViz CSV export (read layer) | Direct DB queries | No more "try CSV first, fall back to API" |
| Hardcoded event map | Database events table | Dynamic, per-org |
| Hardcoded payment overrides | Database payment_rules table or payment metadata | Per-org configurable |
| In-memory caching | Redis or DB query optimization | Stateless servers for horizontal scaling |
| express-session (in-memory) | JWT or DB-backed sessions | Survives server restart, supports multiple instances |
| Single hardcoded ALLOWED_EMAIL | org_memberships + roles | Multi-user, multi-org |

### REFACTOR (Code Structure — Same Logic, Better Organization)

| Current | Refactor To | Why |
|---|---|---|
| 3,200-line server.js | Modular route files + service layer | Each module (events, vendors, sponsors, payments) gets its own file |
| 4,750-line dashboard.html | Component-based frontend (React/Vue/Svelte) | Or keep vanilla JS but split into modules |
| Hardcoded sponsor tier structure | Org-configurable sponsor_tiers table | Different orgs have different tier names/amounts |
| Hardcoded STATIC_EVENT_MAP | Seeds/defaults per org_type | Chamber gets different defaults than festival committee |
| VENDOR_LEGACY_MAP | Migration-only artifact | Import once, then use proper IDs |
| CORS allowedOrigins | Dynamic per-org domains | Each org's site domain gets CORS access |

---

## DATA MIGRATION MAP

### Google Sheets → PostgreSQL

```
Dashboard_Events (sheet tab)
    → events table
    Mapping:
      name → events.name
      abbreviation → events.event_type (or a new short_name field)
      month → derive from events.start_date
      active → events.status ('active' | 'completed' | 'cancelled')
      date → events.start_date / events.end_date
      slug → events.slug (NEW FIELD — add to events table)
      category → events.event_type
      borough_shared → events.settings.borough_shared (JSONB)

Vendor Registration (sheet tab)
    → vendors table + event_vendors table
    Mapping:
      Business Name → vendors.name
      Owner Name → contacts.first_name + contacts.last_name (create contact, link to vendor)
      Email → vendors.email + contacts.email
      What selling → event_vendors.notes (or vendors.notes)
      Food vendor flag → vendors.vendor_type = 'food'
      ServSafe → event_vendors.settings.servsafe_status (or a vendor_documents table)
      Insurance → event_vendors.settings.insurance_status
      Truck/trailer size → event_vendors.settings.vehicle_size
      Food type → event_vendors.settings.food_type
      Event column → event_vendors.event_id (lookup by slug)
      Approved? → event_vendors.status ('confirmed' | 'pending' | 'declined')
      Check Received → link to payments table
      Doc Folder Link → documents table entry

Presenting/Gold/Silver Sponsor Logos (sheet tabs)
    → sponsors table + event_sponsors table
    Mapping:
      Company Name → sponsors.name
      Email → sponsors.email + contacts.email
      Sponsoring Event → event_sponsors.event_id (lookup by slug)
      Approved → event_sponsors.status
      Logo Upload → media table (file_url) + sponsors.logo_media_id (NEW FK)
      Tier → event_sponsors.tier ('presenting' | 'gold' | 'silver')

Sponsor_Check_Payments (sheet tab)
    → payments table
    Mapping:
      Company → payment linked to event_sponsor (by sponsor name + event)
      Tier → derive amount from sponsor_tiers config
      Amount → payments.amount
      Event → payments.event_sponsor_id → event_sponsors.event_id
      Check Received → payments.status ('received' | 'pending')

square_payments (sheet tab)
    → payments table
    Mapping:
      description → payments.description
      amount → payments.amount
      payer_email → link to contacts.email (find or create)
      payer_name → contacts.first_name + last_name
      status → payments.status
      created_at → payments.created_at
      note → payments.notes
      reference_id → payments.reference_number
      payment_id → payments.external_id (NEW FIELD — Square transaction ID)
      Categorization (keyword logic) → payments.payment_category (NEW FIELD)
      Event attribution (override/tag/ref logic) → payments.event_id via event_vendors/event_sponsors/registrations

2026 Registrations (sheet tab)
    → registrations table + contacts table
    Mapping:
      Registrant info → contacts (find or create)
      Event → registrations.event_id (ICC)
      Registration details → registrations.registration_type, notes, settings
```

### New Fields Needed (Not in Doc 01)

Based on the existing system, the events and vendors tables need additions:

```sql
-- Add to events table
ALTER TABLE events ADD COLUMN slug VARCHAR(100);
ALTER TABLE events ADD COLUMN short_name VARCHAR(50);  -- abbreviation
CREATE UNIQUE INDEX idx_events_org_slug ON events(org_id, slug);

-- Add to vendors table (or use settings JSONB)
-- ServSafe and Insurance tracking lives on event_vendors since it's per-assignment
-- event_vendors.settings JSONB can hold: { servsafe_status, insurance_status, vehicle_size, food_type }

-- Add to sponsors table
ALTER TABLE sponsors ADD COLUMN logo_media_id UUID REFERENCES media(id);

-- Add to payments table
ALTER TABLE payments ADD COLUMN external_id VARCHAR(255);    -- Square/Stripe transaction ID
ALTER TABLE payments ADD COLUMN payment_category VARCHAR(50); -- participant, sponsor, vendor, ticket
ALTER TABLE payments ADD COLUMN event_id UUID REFERENCES events(id); -- direct event link for simple cases

-- New: Sponsor tiers (per-org configurable)
CREATE TABLE sponsor_tiers (
  id          UUID PRIMARY KEY,
  org_id      UUID NOT NULL REFERENCES organizations(id),
  name        VARCHAR(100) NOT NULL,   -- 'presenting', 'gold', 'silver', 'custom trophy'
  amount      DECIMAL(10,2),           -- default amount for this tier
  sort_order  INTEGER DEFAULT 0,
  benefits    TEXT,                     -- default benefits description
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(org_id, name)
);

-- New: Document reminders tracking (replaces .reminder-tracking.json)
CREATE TABLE document_reminders (
  id              UUID PRIMARY KEY,
  org_id          UUID NOT NULL REFERENCES organizations(id),
  event_vendor_id UUID NOT NULL REFERENCES event_vendors(id),
  doc_type        VARCHAR(50) NOT NULL,   -- 'servsafe', 'insurance'
  last_sent_at    TIMESTAMPTZ,
  send_count      INTEGER DEFAULT 0,
  next_send_at    TIMESTAMPTZ,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- New: Ticket tracking (replaces in-memory ticketDataCache)
CREATE TABLE ticket_sales (
  id          UUID PRIMARY KEY,
  org_id      UUID NOT NULL REFERENCES organizations(id),
  event_id    UUID NOT NULL REFERENCES events(id),
  capacity    INTEGER,
  sold        INTEGER DEFAULT 0,
  source      VARCHAR(50),            -- 'website_sync', 'square', 'manual'
  updated_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(org_id, event_id, source)
);
```

---

## REFACTORED API ROUTES

### Current → SaaS

Every route now includes `org_id` from the authenticated user's current org context.

```
CURRENT                              → SAAS EQUIVALENT
──────────────────────────────────────────────────────────────
GET  /api/stats?event={id}           → GET  /api/orgs/:orgId/events/:eventId/stats
GET  /api/events                     → GET  /api/orgs/:orgId/events
POST /api/events                     → POST /api/orgs/:orgId/events
GET  /api/vendors/all?event={id}     → GET  /api/orgs/:orgId/events/:eventId/vendors
GET  /api/vendors/pending?event={id} → GET  /api/orgs/:orgId/events/:eventId/vendors?status=pending
POST /api/vendors/approve            → PATCH /api/orgs/:orgId/event-vendors/:id { status: 'confirmed' }
POST /api/vendors/mark-doc           → PATCH /api/orgs/:orgId/event-vendors/:id/documents/:docType
GET  /api/sponsors                   → GET  /api/orgs/:orgId/sponsors
GET  /api/sponsor-candidates         → GET  /api/orgs/:orgId/events/:eventId/sponsor-candidates
POST /api/sponsor-candidates/approve → PATCH /api/orgs/:orgId/event-sponsors/:id { status: 'confirmed' }
GET  /api/sponsor-check-payments     → GET  /api/orgs/:orgId/payments?type=sponsor_check&event=:eventId
POST /api/check-received             → PATCH /api/orgs/:orgId/payments/:id { status: 'received' }
GET  /api/payments?event={id}        → GET  /api/orgs/:orgId/events/:eventId/payments
GET  /api/payments/export            → GET  /api/orgs/:orgId/events/:eventId/payments/export
GET  /api/registrations/icc          → GET  /api/orgs/:orgId/events/:eventId/registrations
POST /api/send-email                 → POST /api/orgs/:orgId/emails/send
POST /api/archive-event              → POST /api/orgs/:orgId/events/:eventId/archive
GET  /api/sponsors.json              → GET  /public/orgs/:orgSlug/sponsors (no auth)
POST /api/sync-event                 → POST /api/orgs/:orgId/events/sync (API key auth)
POST /api/sync-ticket-sale           → POST /api/orgs/:orgId/events/:eventId/tickets/sync
```

### Public Site Endpoints (No Auth — Served by Org's Public Site)

```
GET  /public/orgs/:orgSlug/events              → Upcoming events for site
GET  /public/orgs/:orgSlug/events/:slug        → Single event detail
GET  /public/orgs/:orgSlug/sponsors            → Approved sponsors with logos
GET  /public/orgs/:orgSlug/events/:slug/sponsors → Event-specific sponsors
POST /public/orgs/:orgSlug/contact             → Contact form submission
POST /public/orgs/:orgSlug/events/:slug/register → Public registration
POST /public/orgs/:orgSlug/events/:slug/vendor-apply → Public vendor application
```

---

## SERVER.JS DECOMPOSITION

### Current: 1 File, 3,200 Lines

### Target: Modular Structure

```
src/
├── server.js                    -- Express app setup, middleware, port binding (50 lines)
├── middleware/
│   ├── auth.js                  -- JWT verification, session handling
│   ├── orgContext.js            -- Resolve org_id from URL/token, inject into req
│   └── permissions.js           -- Role checking (admin/staff/viewer)
├── routes/
│   ├── auth.routes.js           -- /auth/* endpoints
│   ├── events.routes.js         -- /api/orgs/:orgId/events/*
│   ├── vendors.routes.js        -- /api/orgs/:orgId/vendors/* and event-vendors/*
│   ├── sponsors.routes.js       -- /api/orgs/:orgId/sponsors/* and event-sponsors/*
│   ├── payments.routes.js       -- /api/orgs/:orgId/payments/*
│   ├── registrations.routes.js  -- /api/orgs/:orgId/registrations/*
│   ├── documents.routes.js      -- /api/orgs/:orgId/documents/*
│   ├── emails.routes.js         -- /api/orgs/:orgId/emails/*
│   ├── site.routes.js           -- /api/orgs/:orgId/site/* (AI builder)
│   ├── public.routes.js         -- /public/orgs/:orgSlug/* (no auth)
│   └── admin.routes.js          -- /admin/* (superadmin only)
├── services/
│   ├── events.service.js        -- Event CRUD, archiving, sync
│   ├── vendors.service.js       -- Vendor CRUD, approval flow, document reminders
│   ├── sponsors.service.js      -- Sponsor CRUD, candidate resolution, tier management
│   ├── payments.service.js      -- Payment tracking, categorization, Square import
│   ├── registrations.service.js -- Registration CRUD
│   ├── documents.service.js     -- File upload, attachment
│   ├── emails.service.js        -- Template rendering, SendGrid sending, logging
│   ├── tickets.service.js       -- Ticket tracking, sync, capacity
│   └── site.service.js          -- Site/page/block CRUD for AI builder
├── ai/
│   ├── agent.js                 -- AI agent orchestration (prompt + structured output)
│   ├── providers/
│   │   ├── openai.js
│   │   ├── anthropic.js
│   │   └── google.js
│   ├── prompts/
│   │   └── site-builder.js      -- System prompt for site building
│   └── blocks/
│       └── registry.js          -- Block type definitions + content schemas
├── db/
│   ├── connection.js            -- PostgreSQL connection pool
│   ├── migrations/              -- SQL migration files
│   └── queries/                 -- Parameterized query functions (all include org_id)
└── utils/
    ├── slugify.js               -- Your eventNameToId() logic
    ├── paymentCategorizer.js    -- categorizePaymentServer() logic
    └── eventResolver.js         -- normalizeEventId() logic
```

**Line count estimate: ~3,200 lines → ~2,500 lines total** (less code because you drop the caching layer, the GViz/Sheets API fallback logic, the Apps Script proxy, and the Drive scanning — all replaced by direct DB operations).

---

## ELIMINATION LIST

Things that go away entirely in the SaaS version:

| What | Why It's Gone |
|---|---|
| `callAppsScript()` | Direct DB writes replace the Apps Script middleman |
| GViz CSV fetch + Sheets API fallback | Direct DB queries |
| All `*Cache` objects (6 caches) | DB queries are fast; add Redis later if needed |
| `STATIC_EVENT_MAP` | Events are in the database |
| `VENDOR_LEGACY_MAP` | One-time migration artifact |
| `PAYMENT_OVERRIDES` | Stored in DB as payment metadata |
| `SPONSOR_DRIVE_FOLDERS` | Media uploaded to S3/R2 per-org |
| `SPONSOR_JOTFORM_FORMS` | Built-in forms replace JotForm |
| `WEB_APP_URL` / `ICC_APP_KEY` | No more Apps Script |
| `.reminder-tracking.json` | `document_reminders` table |
| `ticketDataCache` (in-memory) | `ticket_sales` table |
| Google Drive scanning logic | Media library in DB + object storage |
| JotForm API polling | Built-in forms |
| `apps-script-archive.js` | Historical reference only |

---

## MIGRATION EXECUTION ORDER

### Step 1: Database Setup
- Create PostgreSQL database
- Run migrations (all tables from doc 01 + additions above)
- Create your org as the first tenant
- Seed sponsor_tiers for your org

### Step 2: Data Import Script
- Read each Google Sheet tab
- Map rows to new table structure (using the mapping above)
- Create contacts from vendor/sponsor/registration contact info (dedup by email)
- Import sponsor logos from Drive → S3/R2 → media table
- Import payments with categorization logic applied
- Verify row counts match

### Step 3: API Refactor
- Split server.js into modular route/service files
- Replace all Google Sheets reads with DB queries
- Replace all Apps Script calls with DB writes
- Add org_id scoping middleware
- Keep the same endpoint behavior (same responses, different backend)

### Step 4: Auth Upgrade
- Replace single ALLOWED_EMAIL with org_memberships
- Add JWT or DB-backed sessions
- Support multiple users per org with roles

### Step 5: Multi-Tenant Test
- Create a second test org
- Verify complete data isolation
- Test all endpoints with both orgs

### Step 6: AI + Site Builder
- Add site/page/block tables
- Build block renderer
- Wire up AI agent
- Connect dynamic blocks to ops data

---

## WHAT YOUR REPLIT PROTOTYPE SHOULD PROVE FIRST

In priority order:

1. **PostgreSQL replaces Google Sheets** — Can you run the same dashboard with DB backing instead of Sheets? (This is the riskiest change — everything else is additive.)

2. **Multi-tenant isolation** — Two orgs, same server, zero data leakage.

3. **AI → Site pipeline** — AI chat produces block JSON, renderer produces a page.

4. **Dynamic blocks** — Events list block pulls live data from events table.

Don't try to build all of it at once. Step 1 alone — migrating from Sheets to Postgres while keeping the same dashboard functional — is a meaningful prototype milestone.
