# Prototype Build Plan
## What We're Building Right Now

### The Product: "CivicOps" (working name — rename later)

A multi-tenant SaaS platform where local organizations:
1. Talk to an AI to build their public website
2. Manage events, vendors, sponsors, and payments from one dashboard
3. Their public site and admin dashboard share the same database (no sync gap)

### What the Prototype Proves
- Multi-tenant isolation (two orgs, zero data leakage)
- AI chat → site blocks → rendered public page
- Admin dashboard for event/vendor/sponsor/payment management
- Dynamic public site pages that pull live data
- The "bidirectional sync" gap from Discover Irwin is solved by design (same DB)

### Tech Stack
- Next.js 14 (App Router) — SSR public sites + admin dashboard + API
- TypeScript throughout
- Tailwind CSS + shadcn/ui components
- Drizzle ORM + PostgreSQL (SQLite for local dev)
- NextAuth.js (Auth.js v5) for authentication
- Vercel AI SDK for the AI site builder

### Project Structure
```
civicops/
├── package.json
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── drizzle.config.ts
├── .env.example
│
├── drizzle/
│   ├── schema.ts              # Complete database schema
│   └── seed.ts                # Demo data seeder
│
├── src/
│   ├── app/
│   │   ├── layout.tsx         # Root layout
│   │   ├── page.tsx           # Marketing landing page
│   │   │
│   │   ├── (auth)/
│   │   │   ├── login/page.tsx
│   │   │   ├── signup/page.tsx
│   │   │   └── layout.tsx
│   │   │
│   │   ├── (dashboard)/
│   │   │   ├── layout.tsx           # Dashboard shell (sidebar, topbar)
│   │   │   ├── page.tsx             # Org overview
│   │   │   ├── events/
│   │   │   │   ├── page.tsx         # Event list
│   │   │   │   └── [id]/page.tsx    # Event detail + vendors/sponsors/payments
│   │   │   ├── vendors/page.tsx
│   │   │   ├── sponsors/page.tsx
│   │   │   ├── payments/page.tsx
│   │   │   ├── contacts/page.tsx
│   │   │   ├── site-builder/page.tsx  # AI chat interface
│   │   │   └── settings/page.tsx
│   │   │
│   │   ├── (public)/
│   │   │   └── o/[orgSlug]/          # Public org sites
│   │   │       ├── page.tsx           # Org homepage (rendered from blocks)
│   │   │       ├── [pageSlug]/page.tsx # Dynamic pages
│   │   │       └── layout.tsx         # Public site layout (theme applied)
│   │   │
│   │   └── api/
│   │       ├── auth/[...nextauth]/route.ts
│   │       ├── orgs/[orgId]/
│   │       │   ├── events/route.ts
│   │       │   ├── vendors/route.ts
│   │       │   ├── sponsors/route.ts
│   │       │   ├── payments/route.ts
│   │       │   └── site/route.ts
│   │       ├── ai/chat/route.ts       # AI site builder endpoint
│   │       └── public/[orgSlug]/
│   │           ├── events/route.ts
│   │           └── sponsors/route.ts
│   │
│   ├── lib/
│   │   ├── db.ts                 # Database connection
│   │   ├── auth.ts               # NextAuth config
│   │   ├── ai/
│   │   │   ├── agent.ts          # AI orchestration
│   │   │   └── prompts.ts        # System prompts
│   │   └── services/
│   │       ├── events.ts
│   │       ├── vendors.ts
│   │       ├── sponsors.ts
│   │       ├── payments.ts
│   │       └── site.ts
│   │
│   └── components/
│       ├── ui/                    # shadcn components
│       ├── dashboard/             # Dashboard-specific components
│       ├── site-blocks/           # Public site block renderers
│       └── ai-chat/               # AI chat interface
│
└── public/
    └── logo.svg
```
