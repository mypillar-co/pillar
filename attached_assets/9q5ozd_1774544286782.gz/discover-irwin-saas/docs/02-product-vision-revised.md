# Revised Product Vision
## "Wix for Small Local Organizations" — AI-Driven Website Builder + Operations Platform

---

## THE SHIFT

The original architecture (doc 01) designed a **backend operations tool** — an admin dashboard for managing events, vendors, sponsors, and payments.

That's still the engine. But the **product** is bigger:

> Users talk to an AI agent. The AI builds their website. The website connects to operational tools (event tracking, vendor management, etc.) if they want it. If they just want a website, that's fine too.

This is two products that share a data layer:

1. **Website Builder** — AI-driven, conversational, produces a live public site
2. **Operations Platform** — The admin backend from doc 01 (events, vendors, sponsors, payments, etc.)

The key insight: **the website is the front door, the ops platform is the back office.** They share the same Organization, the same Events, the same Sponsors. A festival committee builds their site via AI chat, and the events on their site are the same events they track vendors and payments against in the admin dashboard.

---

## PRODUCT TIERS

| Tier | What They Get | Example Customer |
|---|---|---|
| **Site Only** | AI-built website with pages, events calendar, about us, contact form. No backend ops. | Small nonprofit that just needs web presence |
| **Site + Events** | Website + event management, registration tracking, public event pages | Downtown association running monthly mixers |
| **Full Platform** | Website + events + vendor management + sponsor tracking + payments + email + docs | Festival committee running a 3-day event with 50 vendors |

Users can upgrade tiers anytime. The AI agent knows what tier they're on and only offers relevant features.

---

## HOW THE AI AGENT WORKS

### The Conversation Flow

```
User signs up → Lands in AI chat interface
                    ↓
AI: "Hey! I'm here to help you build your organization's website.
     Tell me about your organization — what do you do?"
                    ↓
User describes their org (chamber of commerce, festival committee, etc.)
                    ↓
AI asks targeted questions:
  - What's your org name?
  - What kind of events do you run?
  - Do you need vendor tracking?
  - What pages do you want? (About, Events, Sponsors, Contact, etc.)
  - Do you have brand colors/logo?
  - What's the vibe? (Professional, fun, community-focused)
                    ↓
AI generates a site spec → Shows preview → User iterates
                    ↓
Site goes live at org-slug.yourplatform.com (or custom domain)
```

### What the AI Agent Controls

The AI doesn't generate raw HTML. It assembles a site from a **component/block system**:

- **Pages** — Collections of content blocks
- **Blocks** — Hero sections, text, image galleries, event lists, sponsor logos, contact forms, maps, etc.
- **Theme** — Colors, fonts, spacing (selected or generated from brand input)
- **Navigation** — Auto-generated from pages
- **Data connections** — "Show upcoming events" pulls from the events table. "Show sponsors" pulls from sponsors table.

### AI Agent Architecture

```
User (chat) → AI Agent (LLM) → Site Spec (structured JSON) → Renderer → Live Site
                  ↓
            Reads/writes to the same DB:
            - Creates pages, blocks, theme
            - Can create events, add sponsors
            - Populates initial content
```

The AI agent is a **structured output generator**. It doesn't freestyle HTML — it produces page/block definitions that the renderer turns into a site. This keeps things predictable and maintainable.

### Agent Choice

> "Users will talk to an AI agent of their choosing"

This means the platform is **LLM-agnostic**. The agent layer is an abstraction:

```
Agent Interface (chat UI)
    ↓
Agent Router (picks the LLM backend)
    ↓
├── OpenAI (GPT-4, etc.)
├── Anthropic (Claude)
├── Google (Gemini)
├── Local/Self-hosted
└── Future providers
    ↓
Structured Output → Site Spec → Platform API → Database
```

The agent prompt/system instructions are the same regardless of LLM. The output schema is fixed. Users pick their preferred AI, but the platform constrains what it can produce.

---

## REVISED ARCHITECTURE

### Three Layers

```
┌─────────────────────────────────────────────────┐
│                 PUBLIC SITES                     │
│  org-slug.platform.com                          │
│  Rendered from site_pages + site_blocks         │
│  Dynamic data: events, sponsors, galleries      │
│  Public forms: registration, contact, vendor app│
└────────────────────┬────────────────────────────┘
                     │ reads from
┌────────────────────┴────────────────────────────┐
│              SHARED DATA LAYER                   │
│  Organizations, Events, Vendors, Sponsors,       │
│  Contacts, Payments, Documents, etc.             │
│  (All tables from doc 01)                        │
└────────────────────┬────────────────────────────┘
                     │ managed by
┌────────────────────┴────────────────────────────┐
│            ADMIN / AI INTERFACE                  │
│  AI Chat Agent (builds site, manages content)    │
│  Admin Dashboard (ops management)                │
│  Both write to the same data layer               │
└─────────────────────────────────────────────────┘
```

### New Tables (Website Builder Layer)

These sit alongside the existing tables from doc 01.

```sql
-- Site configuration per org
sites
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id) UNIQUE
  domain          VARCHAR(255)                  -- custom domain if set
  subdomain       VARCHAR(100) UNIQUE           -- org-slug (auto from org.slug)
  theme           JSONB NOT NULL DEFAULT '{}'   -- colors, fonts, spacing, logo_url
  status          VARCHAR(20) DEFAULT 'draft'   -- draft, published, maintenance
  meta_title      VARCHAR(255)
  meta_description TEXT
  favicon_url     VARCHAR(500)
  settings        JSONB DEFAULT '{}'            -- analytics ID, social links, footer text
  published_at    TIMESTAMPTZ
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Pages within a site
site_pages
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  site_id         UUID NOT NULL REFERENCES sites(id)
  title           VARCHAR(255) NOT NULL
  slug            VARCHAR(100) NOT NULL         -- /about, /events, /sponsors
  page_type       VARCHAR(50) NOT NULL          -- home, about, events, events_detail, sponsors,
                                                --   contact, gallery, custom, vendor_application
  is_published    BOOLEAN DEFAULT FALSE
  sort_order      INTEGER DEFAULT 0
  meta_title      VARCHAR(255)
  meta_description TEXT
  settings        JSONB DEFAULT '{}'            -- page-level overrides
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()
  UNIQUE(site_id, slug)

-- Content blocks within pages
site_blocks
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  page_id         UUID NOT NULL REFERENCES site_pages(id)
  block_type      VARCHAR(50) NOT NULL          -- see Block Type Registry below
  content         JSONB NOT NULL DEFAULT '{}'   -- block-specific content (text, images, config)
  sort_order      INTEGER DEFAULT 0
  is_visible      BOOLEAN DEFAULT TRUE
  settings        JSONB DEFAULT '{}'            -- styling overrides for this block
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Navigation items
site_nav_items
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  site_id         UUID NOT NULL REFERENCES sites(id)
  label           VARCHAR(100) NOT NULL
  url             VARCHAR(500)                  -- internal path or external URL
  page_id         UUID REFERENCES site_pages(id) -- if linking to an internal page
  parent_id       UUID REFERENCES site_nav_items(id) -- for dropdowns
  sort_order      INTEGER DEFAULT 0
  is_visible      BOOLEAN DEFAULT TRUE
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- AI conversation history (for continuity)
ai_conversations
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  user_id         UUID NOT NULL REFERENCES users(id)
  provider        VARCHAR(50) NOT NULL          -- openai, anthropic, google, etc.
  model           VARCHAR(100)                  -- gpt-4, claude-3, etc.
  purpose         VARCHAR(50) DEFAULT 'site_builder' -- site_builder, content_edit, support
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()

-- Individual messages in AI conversations
ai_messages
  id              UUID PRIMARY KEY
  conversation_id UUID NOT NULL REFERENCES ai_conversations(id)
  role            VARCHAR(20) NOT NULL          -- user, assistant, system
  content         TEXT NOT NULL
  structured_output JSONB                       -- if the AI produced actions/specs
  tokens_used     INTEGER
  created_at      TIMESTAMPTZ DEFAULT NOW()

-- Media/asset library per org
media
  id              UUID PRIMARY KEY
  org_id          UUID NOT NULL REFERENCES organizations(id)
  filename        VARCHAR(255) NOT NULL
  file_url        VARCHAR(500) NOT NULL
  file_type       VARCHAR(50)                   -- image/png, image/jpeg, application/pdf
  file_size       INTEGER
  alt_text        VARCHAR(255)
  uploaded_by     UUID REFERENCES users(id)
  created_at      TIMESTAMPTZ DEFAULT NOW()
```

### Block Type Registry

The AI agent selects from this fixed set of block types. Each has a defined `content` JSON schema.

| Block Type | Content Schema | Data Source |
|---|---|---|
| `hero` | `{ heading, subheading, background_image, cta_text, cta_url }` | Static |
| `text` | `{ body }` (rich text / markdown) | Static |
| `image` | `{ url, alt, caption }` | Static / Media |
| `gallery` | `{ images: [{ url, alt, caption }] }` | Static / Media |
| `events_list` | `{ display: "upcoming" \| "past" \| "all", limit, layout: "cards" \| "list" }` | **Dynamic → events table** |
| `event_detail` | `{ event_id }` (or auto from URL) | **Dynamic → events table** |
| `sponsors_grid` | `{ tiers: ["gold","silver"] \| "all", layout: "grid" \| "list" }` | **Dynamic → sponsors table** |
| `contact_form` | `{ fields: [...], submit_email, success_message }` | Creates Contact on submit |
| `registration_form` | `{ event_id, fields: [...], success_message }` | Creates Registration on submit |
| `vendor_app_form` | `{ event_id, fields: [...], success_message }` | Creates Vendor application |
| `map` | `{ address, lat, lng, zoom }` | Static |
| `video` | `{ url, title }` | Static |
| `social_links` | `{ links: [{ platform, url }] }` | Static |
| `cta_banner` | `{ heading, body, button_text, button_url, background }` | Static |
| `html_embed` | `{ code }` | Static (escape/sandbox) |
| `divider` | `{ style: "line" \| "space" \| "dots" }` | Static |

**Dynamic blocks are the magic.** When the renderer hits an `events_list` block, it queries the events table for that org and renders current data. When the org admin adds an event in the dashboard (or tells the AI to add one), it automatically appears on the site.

---

## THE RENDERING SYSTEM

### How Sites Get Built

```
Browser requests org-slug.platform.com/events
    ↓
Router: resolve subdomain → org_id, find site, find page by slug
    ↓
Load: site theme + page + blocks (ordered by sort_order)
    ↓
For each block:
  - Static blocks → render content directly
  - Dynamic blocks → query org-scoped data (events, sponsors, etc.)
    ↓
Apply theme (colors, fonts) + block layout → HTML response
```

### Rendering Options (Pick One)

| Approach | Pros | Cons | Best For |
|---|---|---|---|
| **Server-rendered (SSR)** | Fast, SEO-friendly, simple | Less interactive | MVP — start here |
| **Static generation (SSG)** | Fastest, cheapest hosting | Rebuild needed on data change | Scale later |
| **Client-side SPA** | Most interactive | SEO harder, slower initial load | Not recommended for this |

**Recommendation: Server-side rendered with caching.** These are mostly content sites with some dynamic data. SSR with aggressive caching (invalidate on data change) gives you SEO + performance + simplicity.

If you're on Replit, Next.js with server components is a natural fit. Pages are server-rendered, dynamic blocks fetch data at render time, cached at the edge.

---

## REVISED ORG TABLE

The organizations table needs a few additions:

```sql
-- Updated organizations table
organizations
  id              UUID PRIMARY KEY
  name            VARCHAR(255) NOT NULL
  slug            VARCHAR(100) UNIQUE NOT NULL
  status          VARCHAR(20) DEFAULT 'active'
  plan            VARCHAR(50) DEFAULT 'free'    -- free, site_only, site_events, full
  settings        JSONB DEFAULT '{}'
  -- New fields for the website product
  org_type        VARCHAR(50)                   -- chamber, downtown_assoc, nonprofit, lodge,
                                                --   festival_committee, other
  logo_url        VARCHAR(500)
  brand_colors    JSONB DEFAULT '{}'            -- { primary, secondary, accent }
  ai_provider_pref VARCHAR(50)                  -- user's preferred AI provider
  created_at      TIMESTAMPTZ DEFAULT NOW()
  updated_at      TIMESTAMPTZ DEFAULT NOW()
```

---

## UPDATED ROLES

| Role | Admin Dashboard | AI Agent | Public Site |
|---|---|---|---|
| **Super Admin** (you) | Full access to ALL orgs | Can configure agents | Can see all sites |
| **Org Admin** | Full access to own org | Can use AI to build/edit site | Site owner |
| **Org Staff** | Create/edit within org | Can use AI for content edits | N/A |
| **Viewer** | Read-only dashboard | Read-only AI history | N/A |
| **Public** | No access | No access | Views published site, submits forms |

---

## FEATURE TIERS (REVISED)

### Phase 1 — MVP: "Site Builder That Actually Works"

| Feature | Description |
|---|---|
| AI chat onboarding | Sign up → talk to AI → site is live |
| Block-based site builder | AI assembles pages from block types |
| Theme system | AI picks/generates colors & fonts from brand input |
| Static pages | Home, About, Contact (with form) |
| Events page | Dynamic — pulls from events table |
| Sponsors page | Dynamic — pulls from sponsors table |
| Basic admin dashboard | Manage events & sponsors (creates the data the site displays) |
| Custom subdomain | org-slug.yourplatform.com |

### Phase 2 — "Operations Layer"

| Feature | Description |
|---|---|
| Vendor management | Full vendor tracking from doc 01 |
| Registration tracking | From doc 01 |
| Payment tracking | From doc 01 |
| Document management | From doc 01 |
| Email templates & sending | From doc 01 |
| Public registration forms | Dynamic block on site |

### Phase 3 — "Scale"

| Feature | Description |
|---|---|
| Custom domains | CNAME setup for orgs |
| Vendor application forms | Public block on site |
| Advanced reporting | Dashboards, exports |
| Billing/subscription | Charge for higher tiers |
| Template marketplace | Pre-built site templates by org type |
| White-label | Remove your branding for premium orgs |

---

## AI AGENT SYSTEM PROMPT STRUCTURE

The AI agent needs context about what it can do. Here's the architecture of its system prompt:

```
SYSTEM PROMPT:
├── Role: "You help organizations build and manage their website"
├── Capabilities:
│   ├── Create/edit pages
│   ├── Add/modify blocks (from Block Type Registry)
│   ├── Set theme (colors, fonts)
│   ├── Create events, sponsors (if tier allows)
│   └── Answer questions about the platform
├── Constraints:
│   ├── Only produce structured output matching block schemas
│   ├── Only use block types from the registry
│   ├── Respect org's plan tier
│   └── Never expose other orgs' data
├── Context (injected per-conversation):
│   ├── Org name, type, current site state
│   ├── Existing pages & blocks
│   ├── Current theme
│   ├── Plan tier & available features
│   └── Previous conversation history
└── Output Format:
    ├── Actions: [{ type: "create_page", ... }, { type: "add_block", ... }]
    └── Message: "Here's what I've set up for you..."
```

---

## DATA FLOW EXAMPLES

### Example 1: New Chamber of Commerce signs up

```
1. User creates account → org created (type: chamber)
2. AI chat starts:
   AI: "Welcome! Tell me about your chamber."
   User: "Irwin County Chamber, we do business mixers and annual banquet"
3. AI creates:
   - Site (theme: professional, blue/gold)
   - Pages: Home (hero + about block), Events, Members, Contact
   - 2 events: "Monthly Business Mixer", "Annual Banquet 2026"
   - Contact form block
4. Site live at irwin-county-chamber.platform.com
5. User can iterate: "Add a sponsors page" → AI adds page + sponsors_grid block
```

### Example 2: Festival Committee goes full platform

```
1. Same onboarding flow → site built
2. User upgrades to Full Platform tier
3. In admin dashboard:
   - Adds 40 vendors with booth assignments
   - Adds 15 sponsors with tiers
   - Tracks payments from each
   - Uploads vendor contracts
4. On public site:
   - Events page auto-shows festival details
   - Sponsors page auto-shows sponsor logos by tier
   - Vendor application form collects new vendor interest
5. AI agent helps throughout:
   "Add a map block to the directions page"
   "Create a new sponsor tier called 'Community Partner'"
```

---

## WHAT THIS MEANS FOR REPLIT PROTOTYPE

Your Replit prototype should focus on proving:

1. **AI → Structured Output → Rendered Site** pipeline works
2. **Block system** renders correctly with a theme
3. **Dynamic blocks** pull live data from the database
4. **Multi-tenant isolation** works (two test orgs, zero leakage)

Don't worry about:
- Perfect AI conversations (iterate on prompts later)
- All block types (start with hero, text, events_list, contact_form)
- Payment processing
- Custom domains
- Billing

Get the AI-to-live-site loop working. Everything else layers on.
